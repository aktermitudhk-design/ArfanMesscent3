import fs from 'fs';
import path from 'path';

const distDir = path.resolve(process.cwd(), 'dist');
const outDir = path.resolve(process.cwd(), 'netlify-drop');
const htmlPath = path.join(distDir, 'index.html');

if (!fs.existsSync(htmlPath)) {
  console.error('dist/index.html not found. Run `npm run build` first.');
  process.exit(1);
}

let html = fs.readFileSync(htmlPath, 'utf-8');

// Inline CSS stylesheets (<link rel="stylesheet" ... href="/assets/...">)
html = html.replace(
  /<link[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>/gi,
  (fullTag, href) => {
    const cleanRel = href.replace(/^\//, '');
    const cssPath = path.join(distDir, cleanRel);
    if (!fs.existsSync(cssPath)) return fullTag;
    const cssContent = fs.readFileSync(cssPath, 'utf-8');
    return `<style>${cssContent}</style>`;
  }
);

// Extract and remove <script type="module" ... src="/assets/..."> from head, then append inline before </body>
const inlineScripts = [];
html = html.replace(
  /<script[^>]*type=["']module["'][^>]*src=["']([^"']+)["'][^>]*><\/script>/gi,
  (fullTag, src) => {
    const cleanRel = src.replace(/^\//, '');
    const jsPath = path.join(distDir, cleanRel);
    if (!fs.existsSync(jsPath)) return fullTag;
    const jsContent = fs.readFileSync(jsPath, 'utf-8').replace(/<\/script>/gi, '<\\/script>');
    inlineScripts.push(`<script type="module">${jsContent}</script>`);
    return '';
  }
);

if (inlineScripts.length > 0) {
  const bodyCloseIdx = html.lastIndexOf('</body>');
  if (bodyCloseIdx !== -1) {
    html =
      html.slice(0, bodyCloseIdx) +
      inlineScripts.join('\n') +
      '\n  ' +
      html.slice(bodyCloseIdx);
  }
}

fs.mkdirSync(outDir, { recursive: true });
const outFile = path.join(outDir, 'index.html');
fs.writeFileSync(outFile, html, 'utf-8');

const sizeKb = (Buffer.byteLength(html, 'utf-8') / 1024).toFixed(1);
console.log(`Built single self-contained HTML file: ${outFile} (${sizeKb} KB)`);
