import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  OperationType,
  db,
  ensureAnonymousIdentity,
  getCurrentAuthUid,
  handleFirestoreError,
} from '../firebase';
import { sanitizeNickname, sanitizeUsername } from '../shared/chatRules';
import type { UserPrivacySettings, UserProfile } from '../shared/types';
import { uploadMediaFile } from '../utils/storageHelper';

interface UseUserProfileOptions {
  clientId: string;
  nickname: string | null;
  avatarColor: string;
  isGuest: boolean;
  isAdmin: boolean;
}

const DEFAULT_PRIVACY: UserPrivacySettings = {
  lastSeen: 'everyone',
  profilePhoto: 'everyone',
  status: 'everyone',
};

export function useUserProfile({
  clientId,
  nickname,
  avatarColor,
  isGuest,
  isAdmin,
}: UseUserProfileOptions) {
  const [profilesById, setProfilesById] = useState<Record<string, UserProfile>>({});
  const [authEnabled, setAuthEnabled] = useState(false);
  const [authUid, setAuthUid] = useState<string | null>(() => getCurrentAuthUid());
  const bootstrappedRef = useRef(false);

  useEffect(() => {
    void ensureAnonymousIdentity.then((info) => {
      setAuthEnabled(info.authEnabled);
      setAuthUid(info.authUid);
    });
  }, []);

  // Listen to all user profiles for avatar/bio/lastSeen/privacy rendering
  useEffect(() => {
    if (!nickname) return;
    const unsub = onSnapshot(
      collection(db, 'users'),
      (snapshot) => {
        const map: Record<string, UserProfile> = {};
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as UserProfile;
          map[data.uid || docSnap.id] = data;
        });
        setProfilesById(map);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'users');
      }
    );
    return () => unsub();
  }, [nickname]);

  const ownProfile = profilesById[clientId] || null;

  // Create/sync own profile doc and online/lastSeen heartbeat
  useEffect(() => {
    if (!nickname || !clientId) return;
    const userRef = doc(db, 'users', clientId);

    const syncOwnPresence = async (onlineState: boolean) => {
      const now = Date.now();
      const existing = profilesById[clientId];
      const currentAuth = getCurrentAuthUid();

      if (!existing && !bootstrappedRef.current) {
        bootstrappedRef.current = true;
        const fresh: UserProfile = {
          uid: clientId,
          clientId,
          authUid: currentAuth,
          displayName: nickname,
          username: '',
          bio: '',
          avatarUrl: null,
          avatarColor,
          isGuest: isGuest && !isAdmin,
          isAdmin,
          online: onlineState,
          lastSeenAt: now,
          privacy: DEFAULT_PRIVACY,
          blockedPeerIds: [],
          mutedRoomIds: [],
          updatedAt: now,
        };
        try {
          await setDoc(userRef, fresh);
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `users/${clientId}`);
        }
        return;
      }

      if (existing) {
        try {
          await updateDoc(userRef, {
            displayName: nickname,
            avatarColor,
            isGuest: isGuest && !isAdmin,
            isAdmin,
            online: onlineState,
            lastSeenAt: now,
            updatedAt: now,
          });
        } catch {
          // Ignore transient offline errors on heartbeat
        }
      }
    };

    void syncOwnPresence(true);
    const heartbeat = window.setInterval(() => {
      void syncOwnPresence(true);
    }, 25_000);

    const handleOffline = () => {
      void updateDoc(userRef, {
        online: false,
        lastSeenAt: Date.now(),
      }).catch(() => {});
    };

    window.addEventListener('pagehide', handleOffline);
    window.addEventListener('beforeunload', handleOffline);

    return () => {
      window.clearInterval(heartbeat);
      window.removeEventListener('pagehide', handleOffline);
      window.removeEventListener('beforeunload', handleOffline);
      handleOffline();
    };
  }, [avatarColor, clientId, isAdmin, isGuest, nickname]);

  const updateOwnProfile = useCallback(
    async (patch: {
      displayName?: string;
      username?: string;
      bio?: string;
      avatarColor?: string;
      avatarFile?: File | null;
      removeAvatar?: boolean;
      privacy?: UserPrivacySettings;
    }): Promise<{ error?: string; nextDisplayName?: string; nextColor?: string }> => {
      if (!clientId) return { error: 'Not signed in.' };
      const existing = profilesById[clientId];
      const now = Date.now();

      let nextDisplayName = existing?.displayName || nickname || 'User';
      if (typeof patch.displayName === 'string') {
        const check = sanitizeNickname(patch.displayName);
        if (!check.valid) return { error: check.error };
        nextDisplayName = check.nickname;
      }

      let nextUsername = existing?.username || '';
      if (typeof patch.username === 'string') {
        const uCheck = sanitizeUsername(patch.username);
        if (!uCheck.valid) return { error: uCheck.error };
        nextUsername = uCheck.username;
      }

      let nextAvatarUrl = existing?.avatarUrl ?? null;
      if (patch.removeAvatar) {
        nextAvatarUrl = null;
      } else if (patch.avatarFile) {
        const uploaded = await uploadMediaFile(
          patch.avatarFile,
          'avatars',
          clientId,
          patch.avatarFile.name
        );
        nextAvatarUrl = uploaded.url;
      }

      const nextColor = patch.avatarColor || existing?.avatarColor || avatarColor;
      const nextBio =
        typeof patch.bio === 'string'
          ? patch.bio.trim().slice(0, 180)
          : existing?.bio || '';
      const nextPrivacy = patch.privacy || existing?.privacy || DEFAULT_PRIVACY;

      const updated: UserProfile = {
        uid: clientId,
        clientId,
        authUid: existing?.authUid ?? getCurrentAuthUid(),
        displayName: nextDisplayName,
        username: nextUsername,
        bio: nextBio,
        avatarUrl: nextAvatarUrl,
        avatarColor: nextColor,
        isGuest: isGuest && !isAdmin,
        isAdmin,
        online: true,
        lastSeenAt: now,
        privacy: nextPrivacy,
        blockedPeerIds: existing?.blockedPeerIds || [],
        mutedRoomIds: existing?.mutedRoomIds || [],
        updatedAt: now,
      };

      try {
        await setDoc(doc(db, 'users', clientId), updated);
        return { nextDisplayName, nextColor };
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${clientId}`);
      }
    },
    [avatarColor, clientId, isAdmin, isGuest, nickname, profilesById]
  );

  const toggleBlockPeer = useCallback(
    async (targetPeerId: string) => {
      if (!clientId || !targetPeerId || targetPeerId === clientId) return;
      const existing = profilesById[clientId];
      const current = existing?.blockedPeerIds || [];
      const next = current.includes(targetPeerId)
        ? current.filter((id) => id !== targetPeerId)
        : [...current, targetPeerId];
      try {
        await updateDoc(doc(db, 'users', clientId), {
          blockedPeerIds: next,
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${clientId}`);
      }
    },
    [clientId, profilesById]
  );

  const toggleMuteRoom = useCallback(
    async (roomId: string) => {
      if (!clientId || !roomId) return;
      const existing = profilesById[clientId];
      const current = existing?.mutedRoomIds || [];
      const next = current.includes(roomId)
        ? current.filter((id) => id !== roomId)
        : [...current, roomId];
      try {
        await updateDoc(doc(db, 'users', clientId), {
          mutedRoomIds: next,
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${clientId}`);
      }
    },
    [clientId, profilesById]
  );

  const allProfiles = useMemo(
    () =>
      Object.values(profilesById).sort((a, b) => {
        if (a.online !== b.online) return a.online ? -1 : 1;
        return b.lastSeenAt - a.lastSeenAt;
      }),
    [profilesById]
  );

  return {
    profilesById,
    allProfiles,
    ownProfile,
    authEnabled,
    authUid,
    blockedPeerIds: ownProfile?.blockedPeerIds || [],
    mutedRoomIds: ownProfile?.mutedRoomIds || [],
    updateOwnProfile,
    toggleBlockPeer,
    toggleMuteRoom,
  };
}
