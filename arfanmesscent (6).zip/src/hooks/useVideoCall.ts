import { useCallback, useEffect, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  setDoc,
  where,
} from 'firebase/firestore';
import { MAIN_ROOM_ID, OperationType, db, handleFirestoreError } from '../firebase';
import { shouldInitiatePeerOffer } from '../shared/chatRules';
import type {
  CallAvatarId,
  CallMediaKind,
  CallMode,
  CallParticipant,
  CallSignal,
  CallSignalKind,
  ChatMessage,
  DirectPeer,
  DirectPing,
} from '../shared/types';
import {
  createAvatarVideoProcessor,
  type AvatarVideoProcessor,
} from '../utils/callAvatarFilter';

function buildRtcConfig(): RTCConfiguration {
  const iceServers: RTCIceServer[] = [
    {
      urls: [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302',
        'stun:stun3.l.google.com:19302',
        'stun:stun4.l.google.com:19302',
      ],
    },
  ];
  const turnUrl = import.meta.env.VITE_TURN_URL;
  if (turnUrl) {
    iceServers.push({
      urls: turnUrl,
      username: import.meta.env.VITE_TURN_USERNAME || undefined,
      credential: import.meta.env.VITE_TURN_CREDENTIAL || undefined,
    });
  }
  return {
    iceServers,
    iceCandidatePoolSize: 4,
  };
}

const RTC_CONFIG: RTCConfiguration = buildRtcConfig();
const CALL_STALE_MS = 45_000;
const CALL_HEARTBEAT_MS = 15_000;

interface UseVideoCallOptions {
  clientId: string;
  nickname: string | null;
  avatarColor: string;
  isBlocked: boolean;
}

interface StartCallArgs {
  roomId?: string;
  mode?: CallMode;
  callKind?: CallMediaKind;
  peer?: DirectPeer | null;
}

export interface AudioOutputDeviceInfo {
  deviceId: string;
  label: string;
}

export function useVideoCall({
  clientId,
  nickname,
  avatarColor,
  isBlocked,
}: UseVideoCallOptions) {
  const [inCall, setInCall] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [joining, setJoining] = useState(false);
  const [micEnabled, setMicEnabled] = useState(true);
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [canSwitchCamera, setCanSwitchCamera] = useState(false);
  const [audioOutputs, setAudioOutputs] = useState<AudioOutputDeviceInfo[]>([]);
  const [selectedAudioOutputId, setSelectedAudioOutputId] = useState<string>('');
  const [screenSharing, setScreenSharing] = useState(false);
  const [screenAudioActive, setScreenAudioActive] = useState(false);
  const [avatarFilter, setAvatarFilterState] = useState<CallAvatarId>('none');
  const [callDurationSec, setCallDurationSec] = useState(0);
  const [activeCallRoomId, setActiveCallRoomId] = useState<string>(MAIN_ROOM_ID);
  const [activeCallMode, setActiveCallMode] = useState<CallMode>('group');
  const [activeCallKind, setActiveCallKind] = useState<CallMediaKind>('video');
  const [activeCallPeer, setActiveCallPeer] = useState<DirectPeer | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<
    Record<string, MediaStream>
  >({});
  const [groupCallParticipants, setGroupCallParticipants] = useState<
    CallParticipant[]
  >([]);
  const [activeCallParticipants, setActiveCallParticipants] = useState<
    CallParticipant[]
  >([]);
  const [callNotice, setCallNotice] = useState<string | null>(null);

  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const avatarProcessorRef = useRef<AvatarVideoProcessor | null>(null);
  const audioMixerCtxRef = useRef<AudioContext | null>(null);
  const micGainNodeRef = useRef<GainNode | null>(null);
  const mixedAudioTrackRef = useRef<MediaStreamTrack | null>(null);
  const peersRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const remoteStreamsMapRef = useRef<Map<string, MediaStream>>(new Map());
  const pendingIceRef = useRef<Map<string, RTCIceCandidateInit[]>>(new Map());
  const makingOfferRef = useRef<Map<string, boolean>>(new Map());
  const ignoreOfferRef = useRef<Map<string, boolean>>(new Map());
  const offerSentRef = useRef<Set<string>>(new Set());
  const processedSignalsRef = useRef<Set<string>>(new Set());
  const iceRestartedRef = useRef<Set<string>>(new Set());
  const joinedAtRef = useRef(0);
  const hadRemotePeerRef = useRef(false);

  const micEnabledRef = useRef(micEnabled);
  micEnabledRef.current = micEnabled;
  const cameraEnabledRef = useRef(cameraEnabled);
  cameraEnabledRef.current = cameraEnabled;
  const cameraFacingRef = useRef(cameraFacing);
  cameraFacingRef.current = cameraFacing;
  const screenSharingRef = useRef(screenSharing);
  screenSharingRef.current = screenSharing;
  const avatarFilterRef = useRef(avatarFilter);
  avatarFilterRef.current = avatarFilter;
  const activeCallRoomIdRef = useRef(activeCallRoomId);
  activeCallRoomIdRef.current = activeCallRoomId;
  const activeCallModeRef = useRef(activeCallMode);
  activeCallModeRef.current = activeCallMode;
  const activeCallPeerRef = useRef(activeCallPeer);
  activeCallPeerRef.current = activeCallPeer;

  // Live Call Duration Timer
  useEffect(() => {
    if (!inCall) {
      setCallDurationSec(0);
      hadRemotePeerRef.current = false;
      return;
    }
    setCallDurationSec(0);
    const startTs = Date.now();
    const timer = window.setInterval(() => {
      setCallDurationSec(Math.floor((Date.now() - startTs) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [inCall]);

  // Enumerate cameras & audio output speakers when inCall
  const refreshMediaDevices = useCallback(async () => {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.enumerateDevices) {
      return;
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter((d) => d.kind === 'videoinput');
      setCanSwitchCamera(videoInputs.length > 1);
      const outputs = devices
        .filter((d) => d.kind === 'audiooutput' && d.deviceId)
        .map((d, i) => ({
          deviceId: d.deviceId,
          label: d.label || `Speaker ${i + 1}`,
        }));
      setAudioOutputs(outputs);
    } catch {
      // Ignore enumerateDevices errors in restricted browsers
    }
  }, []);

  useEffect(() => {
    if (inCall) {
      void refreshMediaDevices();
    }
  }, [inCall, refreshMediaDevices]);

  // Monitor main Group Call participants
  useEffect(() => {
    if (!nickname || isBlocked) {
      setGroupCallParticipants([]);
      return;
    }

    const path = `rooms/${MAIN_ROOM_ID}/callParticipants`;
    const unsub = onSnapshot(
      collection(db, 'rooms', MAIN_ROOM_ID, 'callParticipants'),
      (snapshot) => {
        const now = Date.now();
        const active: CallParticipant[] = [];
        snapshot.forEach((docSnap) => {
          const p = docSnap.data() as CallParticipant;
          if (now - p.lastSeenAt <= CALL_STALE_MS) {
            active.push(p);
          }
        });
        active.sort((a, b) => a.joinedAt - b.joinedAt);
        setGroupCallParticipants(active);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, path);
      }
    );

    return () => unsub();
  }, [isBlocked, nickname]);

  // Monitor participants of the active call room
  useEffect(() => {
    if (!inCall) {
      setActiveCallParticipants([]);
      return;
    }
    if (activeCallRoomId === MAIN_ROOM_ID) {
      setActiveCallParticipants(groupCallParticipants);
      if (groupCallParticipants.some((p) => p.clientId !== clientId)) {
        hadRemotePeerRef.current = true;
      }
      return;
    }

    const path = `rooms/${activeCallRoomId}/callParticipants`;
    const unsub = onSnapshot(
      collection(db, 'rooms', activeCallRoomId, 'callParticipants'),
      (snapshot) => {
        const now = Date.now();
        const active: CallParticipant[] = [];
        snapshot.forEach((docSnap) => {
          const p = docSnap.data() as CallParticipant;
          if (now - p.lastSeenAt <= CALL_STALE_MS) {
            active.push(p);
          }
        });
        active.sort((a, b) => a.joinedAt - b.joinedAt);
        if (active.some((p) => p.clientId !== clientId)) {
          hadRemotePeerRef.current = true;
        }
        setActiveCallParticipants(active);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, path);
      }
    );

    return () => unsub();
  }, [activeCallRoomId, clientId, groupCallParticipants, inCall]);

  const callParticipants = inCall
    ? activeCallParticipants
    : groupCallParticipants;

  const sendSignal = useCallback(
    async (
      roomId: string,
      toId: string,
      kind: CallSignalKind,
      payloadObj: unknown
    ) => {
      const id = `sig-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const signal: CallSignal = {
        id,
        fromId: clientId,
        toId,
        kind,
        payload: JSON.stringify(payloadObj),
        createdAt: Date.now(),
      };
      const path = `rooms/${roomId}/callSignals/${id}`;
      try {
        await setDoc(doc(db, 'rooms', roomId, 'callSignals', id), signal);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [clientId]
  );

  const closePeer = useCallback((peerId: string) => {
    const pc = peersRef.current.get(peerId);
    if (pc) {
      pc.onicecandidate = null;
      pc.ontrack = null;
      pc.onnegotiationneeded = null;
      pc.oniceconnectionstatechange = null;
      pc.onconnectionstatechange = null;
      pc.close();
      peersRef.current.delete(peerId);
    }
    offerSentRef.current.delete(peerId);
    pendingIceRef.current.delete(peerId);
    makingOfferRef.current.delete(peerId);
    ignoreOfferRef.current.delete(peerId);
    iceRestartedRef.current.delete(peerId);
    remoteStreamsMapRef.current.delete(peerId);
    setRemoteStreams((prev) => {
      if (!(peerId in prev)) return prev;
      const next = { ...prev };
      delete next[peerId];
      return next;
    });
  }, []);

  const syncParticipantDoc = useCallback(
    async (overrides?: Partial<CallParticipant>) => {
      if (!nickname || !activeCallRoomIdRef.current) return;
      const roomId = activeCallRoomIdRef.current;
      const entry: CallParticipant = {
        clientId,
        nickname,
        avatarColor,
        videoEnabled: overrides?.videoEnabled ?? cameraEnabledRef.current,
        audioEnabled: overrides?.audioEnabled ?? micEnabledRef.current,
        screenSharing: overrides?.screenSharing ?? screenSharingRef.current,
        joinedAt: joinedAtRef.current,
        lastSeenAt: Date.now(),
      };
      try {
        await setDoc(
          doc(db, 'rooms', roomId, 'callParticipants', clientId),
          entry
        );
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.WRITE,
          `rooms/${roomId}/callParticipants/${clientId}`
        );
      }
    },
    [avatarColor, clientId, nickname]
  );

  const getOrCreatePeer = useCallback(
    (peerId: string, roomId: string): RTCPeerConnection => {
      const existing = peersRef.current.get(peerId);
      if (existing) return existing;

      const pc = new RTCPeerConnection(RTC_CONFIG);
      peersRef.current.set(peerId, pc);

      const stream = localStreamRef.current;
      let hasAudioTrack = false;
      let hasVideoTrack = false;

      if (stream) {
        stream.getTracks().forEach((track) => {
          if (track.kind === 'audio') hasAudioTrack = true;
          if (track.kind === 'video') hasVideoTrack = true;
          pc.addTrack(track, stream);
        });
      }

      if (!hasAudioTrack) {
        pc.addTransceiver('audio', { direction: 'recvonly' });
      }
      if (!hasVideoTrack) {
        pc.addTransceiver('video', { direction: 'recvonly' });
      }

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          void sendSignal(roomId, peerId, 'ice', event.candidate.toJSON());
        }
      };

      pc.ontrack = (event) => {
        let remoteStream = remoteStreamsMapRef.current.get(peerId);
        if (!remoteStream) {
          remoteStream = new MediaStream();
          remoteStreamsMapRef.current.set(peerId, remoteStream);
        }

        const incomingTrack = event.track;
        remoteStream.getTracks().forEach((existingTrack) => {
          if (
            existingTrack.kind === incomingTrack.kind &&
            existingTrack.id !== incomingTrack.id
          ) {
            remoteStream!.removeTrack(existingTrack);
          }
        });
        if (!remoteStream.getTracks().some((t) => t.id === incomingTrack.id)) {
          remoteStream.addTrack(incomingTrack);
        }

        const pushUpdatedStream = () => {
          const latest = remoteStreamsMapRef.current.get(peerId);
          if (!latest) return;
          setRemoteStreams((prev) => ({
            ...prev,
            [peerId]: new MediaStream(latest.getTracks()),
          }));
        };

        incomingTrack.onunmute = pushUpdatedStream;
        incomingTrack.onended = pushUpdatedStream;
        pushUpdatedStream();
      };

      pc.onnegotiationneeded = async () => {
        if (
          !offerSentRef.current.has(peerId) &&
          !shouldInitiatePeerOffer(clientId, peerId)
        ) {
          return;
        }
        try {
          makingOfferRef.current.set(peerId, true);
          offerSentRef.current.add(peerId);
          await pc.setLocalDescription();
          if (pc.localDescription) {
            await sendSignal(roomId, peerId, 'offer', pc.localDescription);
          }
        } catch {
          // Ignore transient negotiation errors
        } finally {
          makingOfferRef.current.set(peerId, false);
        }
      };

      pc.oniceconnectionstatechange = () => {
        if (
          pc.iceConnectionState === 'failed' &&
          !iceRestartedRef.current.has(peerId)
        ) {
          iceRestartedRef.current.add(peerId);
          pc.restartIce();
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'closed') {
          closePeer(peerId);
        }
      };

      return pc;
    },
    [clientId, closePeer, sendSignal]
  );

  const negotiatePeer = useCallback(
    async (peerId: string, pc: RTCPeerConnection, roomId: string) => {
      try {
        makingOfferRef.current.set(peerId, true);
        offerSentRef.current.add(peerId);
        const offer = await pc.createOffer({
          offerToReceiveAudio: true,
          offerToReceiveVideo: true,
        });
        if (pc.signalingState !== 'stable') return;
        await pc.setLocalDescription(offer);
        if (pc.localDescription) {
          await sendSignal(roomId, peerId, 'offer', pc.localDescription);
        }
      } catch {
        // Ignore transient negotiation errors
      } finally {
        makingOfferRef.current.set(peerId, false);
      }
    },
    [sendSignal]
  );

  const renegotiateAllPeers = useCallback(async () => {
    const roomId = activeCallRoomIdRef.current;
    if (!roomId) return;
    for (const [peerId, pc] of peersRef.current.entries()) {
      await negotiatePeer(peerId, pc, roomId);
    }
  }, [negotiatePeer]);

  const flushPendingIce = useCallback(
    async (peerId: string, pc: RTCPeerConnection) => {
      const queued = pendingIceRef.current.get(peerId);
      if (!queued || queued.length === 0) return;
      pendingIceRef.current.delete(peerId);
      for (const candidate of queued) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch {
          // Ignore stale ICE
        }
      }
    },
    []
  );

  const stopAvatarProcessor = useCallback(() => {
    if (avatarProcessorRef.current) {
      avatarProcessorRef.current.stop();
      avatarProcessorRef.current = null;
    }
  }, []);

  const stopAudioMixer = useCallback(() => {
    if (mixedAudioTrackRef.current) {
      try {
        mixedAudioTrackRef.current.stop();
      } catch {
        // ignore
      }
      mixedAudioTrackRef.current = null;
    }
    micGainNodeRef.current = null;
    if (audioMixerCtxRef.current) {
      void audioMixerCtxRef.current.close().catch(() => {});
      audioMixerCtxRef.current = null;
    }
    setScreenAudioActive(false);
  }, []);

  const replaceOutgoingVideoTrack = useCallback(
    async (nextTrack: MediaStreamTrack | null, streamForAdd?: MediaStream) => {
      let needsRenegotiation = false;
      for (const pc of peersRef.current.values()) {
        const videoTransceiver = pc
          .getTransceivers()
          .find(
            (tr) =>
              tr.sender.track?.kind === 'video' ||
              tr.receiver.track?.kind === 'video'
          );
        if (videoTransceiver) {
          if (
            nextTrack &&
            (videoTransceiver.direction === 'recvonly' ||
              videoTransceiver.direction === 'inactive')
          ) {
            videoTransceiver.direction = 'sendrecv';
            needsRenegotiation = true;
          }
          await videoTransceiver.sender.replaceTrack(nextTrack).catch(() => {});
        } else if (nextTrack && streamForAdd) {
          pc.addTrack(nextTrack, streamForAdd);
          needsRenegotiation = true;
        }
      }
      if (needsRenegotiation) {
        await renegotiateAllPeers();
      }
    },
    [renegotiateAllPeers]
  );

  const replaceOutgoingAudioTrack = useCallback(
    async (nextTrack: MediaStreamTrack | null, streamForAdd?: MediaStream) => {
      let needsRenegotiation = false;
      for (const pc of peersRef.current.values()) {
        const audioTransceiver = pc
          .getTransceivers()
          .find(
            (tr) =>
              tr.sender.track?.kind === 'audio' ||
              tr.receiver.track?.kind === 'audio'
          );
        if (audioTransceiver) {
          if (
            nextTrack &&
            (audioTransceiver.direction === 'recvonly' ||
              audioTransceiver.direction === 'inactive')
          ) {
            audioTransceiver.direction = 'sendrecv';
            needsRenegotiation = true;
          }
          await audioTransceiver.sender.replaceTrack(nextTrack).catch(() => {});
        } else if (nextTrack && streamForAdd) {
          pc.addTrack(nextTrack, streamForAdd);
          needsRenegotiation = true;
        }
      }
      if (needsRenegotiation) {
        await renegotiateAllPeers();
      }
    },
    [renegotiateAllPeers]
  );

  const leaveCall = useCallback(async () => {
    const roomToLeave = activeCallRoomIdRef.current;
    const modeToLeave = activeCallModeRef.current;
    const peerToClear = activeCallPeerRef.current;
    const missed =
      modeToLeave === 'personal' &&
      Boolean(peerToClear) &&
      !hadRemotePeerRef.current;

    setInCall(false);
    setIsMinimized(false);
    setScreenSharing(false);
    setAvatarFilterState('none');
    setCallNotice(null);

    stopAvatarProcessor();
    stopAudioMixer();

    for (const peerId of Array.from(peersRef.current.keys())) {
      closePeer(peerId);
    }

    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((t) => t.stop());
      cameraStreamRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }

    setLocalStream(null);
    setRemoteStreams({});
    remoteStreamsMapRef.current.clear();
    processedSignalsRef.current.clear();
    setActiveCallParticipants([]);

    if (roomToLeave) {
      try {
        await deleteDoc(
          doc(db, 'rooms', roomToLeave, 'callParticipants', clientId)
        );
      } catch {
        // Ignore cleanup errors
      }
    }

    if (peerToClear) {
      const callPingId = `dmcall__${clientId}__${peerToClear.clientId}`.replace(
        /[^a-zA-Z0-9_-]/g,
        '_'
      );
      void deleteDoc(
        doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', callPingId)
      ).catch(() => {});

      // Notify recipient about missed call if caller ended before peer answered
      if (missed && nickname) {
        const missedId = `missed__${clientId}__${peerToClear.clientId}__${Date.now()}`.replace(
          /[^a-zA-Z0-9_-]/g,
          '_'
        );
        const missedPing: DirectPing = {
          id: missedId,
          toClientId: peerToClear.clientId,
          fromClientId: clientId,
          fromNickname: nickname,
          fromColor: avatarColor,
          dmRoomId: peerToClear.dmRoomId,
          kind: 'missed_call',
          callKind: activeCallKind,
          previewText: `Missed call from ${nickname}`,
          createdAt: Date.now(),
        };
        void setDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', missedId),
          missedPing
        ).catch(() => {});
      }
    }
  }, [activeCallKind, avatarColor, clientId, closePeer, nickname]);

  const rejectIncomingCall = useCallback(
    async (ping: DirectPing) => {
      if (!nickname) return;
      try {
        await deleteDoc(doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', ping.id));
        const missedId = `missed__${clientId}__${ping.fromClientId}__${Date.now()}`.replace(
          /[^a-zA-Z0-9_-]/g,
          '_'
        );
        const declinedPing: DirectPing = {
          id: missedId,
          toClientId: ping.fromClientId,
          fromClientId: clientId,
          fromNickname: nickname,
          fromColor: avatarColor,
          dmRoomId: ping.dmRoomId,
          kind: 'missed_call',
          callKind: ping.callKind || 'video',
          previewText: `${nickname} declined your call`,
          createdAt: Date.now(),
        };
        await setDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', missedId),
          declinedPing
        );
      } catch {
        // ignore
      }
    },
    [avatarColor, clientId, nickname]
  );

  useEffect(() => {
    if (isBlocked && inCall) {
      void leaveCall();
    }
  }, [inCall, isBlocked, leaveCall]);

  useEffect(() => {
    if (!inCall || !nickname || !activeCallRoomId) return;

    const participantRef = doc(
      db,
      'rooms',
      activeCallRoomId,
      'callParticipants',
      clientId
    );

    void syncParticipantDoc();
    const timer = setInterval(() => {
      void syncParticipantDoc();
    }, CALL_HEARTBEAT_MS);

    const handleUnload = () => {
      void deleteDoc(participantRef).catch(() => {});
    };

    window.addEventListener('pagehide', handleUnload);
    window.addEventListener('beforeunload', handleUnload);

    return () => {
      clearInterval(timer);
      window.removeEventListener('pagehide', handleUnload);
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, [activeCallRoomId, clientId, inCall, nickname, syncParticipantDoc]);

  useEffect(() => {
    if (!inCall || !activeCallRoomId) return;

    const remoteIds = new Set(
      activeCallParticipants
        .filter((p) => p.clientId !== clientId)
        .map((p) => p.clientId)
    );

    for (const existingPeerId of Array.from(peersRef.current.keys())) {
      if (!remoteIds.has(existingPeerId)) {
        closePeer(existingPeerId);
      }
    }

    for (const remoteId of remoteIds) {
      const pc = getOrCreatePeer(remoteId, activeCallRoomId);
      if (
        shouldInitiatePeerOffer(clientId, remoteId) &&
        !offerSentRef.current.has(remoteId)
      ) {
        offerSentRef.current.add(remoteId);
        void (async () => {
          try {
            makingOfferRef.current.set(remoteId, true);
            const offer = await pc.createOffer({
              offerToReceiveAudio: true,
              offerToReceiveVideo: true,
            });
            await pc.setLocalDescription(offer);
            await sendSignal(activeCallRoomId, remoteId, 'offer', offer);
          } catch {
            offerSentRef.current.delete(remoteId);
          } finally {
            makingOfferRef.current.set(remoteId, false);
          }
        })();
      }
    }
  }, [
    activeCallParticipants,
    activeCallRoomId,
    clientId,
    closePeer,
    getOrCreatePeer,
    inCall,
    sendSignal,
  ]);

  useEffect(() => {
    if (!inCall || !activeCallRoomId) return;

    const signalsPath = `rooms/${activeCallRoomId}/callSignals`;
    const q = query(
      collection(db, 'rooms', activeCallRoomId, 'callSignals'),
      where('toId', '==', clientId)
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type !== 'added') return;
          const signal = change.doc.data() as CallSignal;
          if (processedSignalsRef.current.has(signal.id)) return;
          processedSignalsRef.current.add(signal.id);

          void (async () => {
            try {
              const parsed = JSON.parse(signal.payload);
              const pc = getOrCreatePeer(signal.fromId, activeCallRoomId);
              const polite = !shouldInitiatePeerOffer(clientId, signal.fromId);

              if (signal.kind === 'offer') {
                const offerCollision =
                  Boolean(makingOfferRef.current.get(signal.fromId)) ||
                  pc.signalingState !== 'stable';
                const ignoreOffer = !polite && offerCollision;
                ignoreOfferRef.current.set(signal.fromId, ignoreOffer);
                if (ignoreOffer) return;

                await pc.setRemoteDescription(
                  new RTCSessionDescription(parsed as RTCSessionDescriptionInit)
                );
                await flushPendingIce(signal.fromId, pc);
                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);
                await sendSignal(
                  activeCallRoomId,
                  signal.fromId,
                  'answer',
                  answer
                );
              } else if (signal.kind === 'answer') {
                if (pc.signalingState === 'have-local-offer') {
                  await pc.setRemoteDescription(
                    new RTCSessionDescription(
                      parsed as RTCSessionDescriptionInit
                    )
                  );
                  await flushPendingIce(signal.fromId, pc);
                }
              } else if (signal.kind === 'ice') {
                const candidate = parsed as RTCIceCandidateInit;
                if (pc.remoteDescription) {
                  try {
                    await pc.addIceCandidate(new RTCIceCandidate(candidate));
                  } catch {
                    // Ignore late ICE
                  }
                } else {
                  const queue = pendingIceRef.current.get(signal.fromId) || [];
                  queue.push(candidate);
                  pendingIceRef.current.set(signal.fromId, queue);
                }
              }
            } catch {
              // Ignore malformed signals
            } finally {
              void deleteDoc(change.doc.ref).catch(() => {});
            }
          })();
        });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, signalsPath);
      }
    );

    return () => unsub();
  }, [
    activeCallRoomId,
    clientId,
    flushPendingIce,
    getOrCreatePeer,
    inCall,
    sendSignal,
  ]);

  const joinCall = useCallback(
    async (args?: StartCallArgs) => {
      if (!nickname || isBlocked || joining) return;

      const targetRoomId = args?.roomId || MAIN_ROOM_ID;
      const targetMode: CallMode = args?.mode || 'group';
      const targetCallKind: CallMediaKind = args?.callKind || 'video';
      const targetPeer: DirectPeer | null = args?.peer ?? null;

      if (inCall) {
        if (activeCallRoomIdRef.current === targetRoomId) {
          setIsMinimized(false);
          return;
        }
        await leaveCall();
      }

      setJoining(true);
      setCallNotice(null);
      setActiveCallRoomId(targetRoomId);
      activeCallRoomIdRef.current = targetRoomId;
      setActiveCallMode(targetMode);
      activeCallModeRef.current = targetMode;
      setActiveCallKind(targetCallKind);
      setActiveCallPeer(targetPeer);
      activeCallPeerRef.current = targetPeer;
      hadRemotePeerRef.current = false;

      let stream: MediaStream | null = null;
      let hasVideo = false;
      let hasAudio = false;

      const audioConstraints: MediaTrackConstraints = {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      };

      if (
        typeof navigator !== 'undefined' &&
        navigator.mediaDevices?.getUserMedia
      ) {
        if (targetCallKind === 'audio') {
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              audio: audioConstraints,
            });
            hasAudio = stream.getAudioTracks().length > 0;
          } catch {
            try {
              stream = await navigator.mediaDevices.getUserMedia({ audio: true });
              hasAudio = stream.getAudioTracks().length > 0;
            } catch {
              setCallNotice('cameraHintBlocked');
            }
          }
        } else {
          const videoAttempts: MediaStreamConstraints[] = [
            {
              video: {
                facingMode: { ideal: cameraFacingRef.current },
                width: { ideal: 640 },
                height: { ideal: 480 },
              },
              audio: audioConstraints,
            },
            {
              video: { facingMode: { ideal: cameraFacingRef.current } },
              audio: true,
            },
            {
              video: true,
              audio: true,
            },
          ];

          for (const constraints of videoAttempts) {
            try {
              stream = await navigator.mediaDevices.getUserMedia(constraints);
              hasVideo = stream.getVideoTracks().length > 0;
              hasAudio = stream.getAudioTracks().length > 0;
              if (stream) break;
            } catch {
              // Try next fallback constraints
            }
          }

          if (!stream) {
            try {
              stream = await navigator.mediaDevices.getUserMedia({
                audio: audioConstraints,
              });
              hasAudio = stream.getAudioTracks().length > 0;
              setCallNotice('cameraHintBlocked');
            } catch {
              try {
                stream = await navigator.mediaDevices.getUserMedia({
                  video: { facingMode: { ideal: cameraFacingRef.current } },
                });
                hasVideo = stream.getVideoTracks().length > 0;
                setCallNotice('cameraHintBlocked');
              } catch {
                try {
                  stream = await navigator.mediaDevices.getUserMedia({ video: true });
                  hasVideo = stream.getVideoTracks().length > 0;
                  setCallNotice('cameraHintBlocked');
                } catch {
                  setCallNotice('cameraHintBlocked');
                }
              }
            }
          }
        }
      } else {
        setCallNotice('cameraHintBlocked');
      }

      if (stream) {
        stream.getAudioTracks().forEach((t) => {
          t.enabled = true;
        });
      }

      cameraStreamRef.current = stream;
      localStreamRef.current = stream;
      setLocalStream(stream);
      setCameraEnabled(hasVideo && targetCallKind === 'video');
      setMicEnabled(hasAudio);
      setScreenSharing(false);
      joinedAtRef.current = Date.now();

      const wasEmpty =
        targetRoomId === MAIN_ROOM_ID && groupCallParticipants.length === 0;
      const participantEntry: CallParticipant = {
        clientId,
        nickname,
        avatarColor,
        videoEnabled: hasVideo && targetCallKind === 'video',
        audioEnabled: hasAudio,
        screenSharing: false,
        joinedAt: joinedAtRef.current,
        lastSeenAt: joinedAtRef.current,
      };

      try {
        await setDoc(
          doc(db, 'rooms', targetRoomId, 'callParticipants', clientId),
          participantEntry
        );
        if (wasEmpty) {
          const now = Date.now();
          const sysId = `sys-call-${now}-${Math.random()
            .toString(36)
            .slice(2, 6)}`;
          const callNoticeMsg: ChatMessage = {
            id: sysId,
            type: 'system',
            senderId: 'system',
            senderName: 'ARFANMesscent',
            senderColor: avatarColor,
            text:
              targetCallKind === 'audio'
                ? `${nickname} started a live group voice call`
                : `${nickname} started a live group video call`,
            reactions: {},
            createdAt: now,
          };
          await setDoc(
            doc(db, 'rooms', MAIN_ROOM_ID, 'messages', sysId),
            callNoticeMsg
          );
        }

        if (targetMode === 'personal' && targetPeer) {
          const pingId = `dmcall__${clientId}__${targetPeer.clientId}`.replace(
            /[^a-zA-Z0-9_-]/g,
            '_'
          );
          const callPing: DirectPing = {
            id: pingId,
            toClientId: targetPeer.clientId,
            fromClientId: clientId,
            fromNickname: nickname,
            fromColor: avatarColor,
            dmRoomId: targetRoomId,
            kind: 'dm_call',
            callKind: targetCallKind,
            previewText:
              targetCallKind === 'audio'
                ? 'Incoming Voice Call'
                : 'Incoming Video Call',
            createdAt: Date.now(),
          };
          await setDoc(
            doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', pingId),
            callPing
          );
        }
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.CREATE,
          `rooms/${targetRoomId}/callParticipants/${clientId}`
        );
      } finally {
        setJoining(false);
      }

      setInCall(true);
      setIsMinimized(false);
    },
    [
      avatarColor,
      clientId,
      groupCallParticipants.length,
      inCall,
      isBlocked,
      joining,
      leaveCall,
      nickname,
    ]
  );

  const switchCamera = useCallback(async () => {
    if (!inCall || typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      return;
    }
    const prevFacing = cameraFacingRef.current;
    const nextFacing = prevFacing === 'user' ? 'environment' : 'user';
    stopAvatarProcessor();
    // Stop old video tracks first so Android/iOS hardware unlocks the second camera
    const oldVideoTracks = cameraStreamRef.current?.getVideoTracks() || [];
    oldVideoTracks.forEach((t) => t.stop());

    const acquireCameraTrack = async (facing: 'user' | 'environment') => {
      try {
        const s = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { exact: facing },
            width: { ideal: 640 },
            height: { ideal: 480 },
          },
        });
        return s.getVideoTracks()[0] || null;
      } catch {
        try {
          const s = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: facing } },
          });
          return s.getVideoTracks()[0] || null;
        } catch {
          return null;
        }
      }
    };

    try {
      let newVideoTrack = await acquireCameraTrack(nextFacing);
      let appliedFacing: 'user' | 'environment' = nextFacing;
      if (!newVideoTrack) {
        newVideoTrack = await acquireCameraTrack(prevFacing);
        appliedFacing = prevFacing;
      }
      if (!newVideoTrack) return;

      const audioTracks = cameraStreamRef.current?.getAudioTracks() || [];
      const merged = new MediaStream([...audioTracks, newVideoTrack]);
      cameraStreamRef.current = merged;

      if (!screenSharingRef.current) {
        let outgoingTrack: MediaStreamTrack = newVideoTrack;
        if (avatarFilterRef.current !== 'none') {
          const proc = createAvatarVideoProcessor(newVideoTrack, avatarFilterRef.current);
          if (proc) {
            avatarProcessorRef.current = proc;
            outgoingTrack = proc.videoTrack;
          }
        }
        const preview = new MediaStream([...audioTracks, outgoingTrack]);
        localStreamRef.current = preview;
        setLocalStream(preview);
        await replaceOutgoingVideoTrack(outgoingTrack, preview);
      }
      setCameraFacing(appliedFacing);
      setCameraEnabled(true);
      setCallNotice(null);
      void syncParticipantDoc({ videoEnabled: true });
    } catch {
      // Ignore if secondary camera unavailable
    }
  }, [inCall, replaceOutgoingVideoTrack, stopAvatarProcessor, syncParticipantDoc]);

  const stopScreenShare = useCallback(async () => {
    if (!screenStreamRef.current) {
      setScreenSharing(false);
      stopAudioMixer();
      return;
    }

    screenStreamRef.current.getTracks().forEach((t) => {
      t.onended = null;
      t.stop();
    });
    screenStreamRef.current = null;
    setScreenSharing(false);
    stopAudioMixer();

    const camStream = cameraStreamRef.current;
    const camVideoTrack = camStream?.getVideoTracks()[0] || null;
    const audioTracks = camStream?.getAudioTracks() || [];
    audioTracks.forEach((t) => {
      t.enabled = micEnabledRef.current;
    });

    const restoredTracks: MediaStreamTrack[] = [...audioTracks];
    let outgoingVideo: MediaStreamTrack | null = null;
    if (camVideoTrack && camVideoTrack.readyState === 'live') {
      camVideoTrack.enabled = cameraEnabledRef.current;
      if (avatarFilterRef.current !== 'none' && cameraEnabledRef.current) {
        const proc = createAvatarVideoProcessor(camVideoTrack, avatarFilterRef.current);
        if (proc) {
          avatarProcessorRef.current = proc;
          outgoingVideo = proc.videoTrack;
        } else {
          outgoingVideo = camVideoTrack;
        }
      } else {
        outgoingVideo = camVideoTrack;
      }
      restoredTracks.push(outgoingVideo);
    }

    const restoredStream =
      restoredTracks.length > 0 ? new MediaStream(restoredTracks) : null;
    localStreamRef.current = restoredStream;
    setLocalStream(restoredStream);

    await replaceOutgoingVideoTrack(
      outgoingVideo && outgoingVideo.readyState === 'live' ? outgoingVideo : null,
      restoredStream || undefined
    );
    await replaceOutgoingAudioTrack(audioTracks[0] || null, restoredStream || undefined);

    void syncParticipantDoc({
      screenSharing: false,
      videoEnabled: Boolean(
        camVideoTrack &&
          camVideoTrack.readyState === 'live' &&
          cameraEnabledRef.current
      ),
    });
  }, [replaceOutgoingAudioTrack, replaceOutgoingVideoTrack, stopAudioMixer, syncParticipantDoc]);

  const toggleScreenShare = useCallback(async () => {
    if (!inCall) return;

    if (screenSharingRef.current) {
      await stopScreenShare();
      return;
    }

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices?.getDisplayMedia
    ) {
      setCallNotice('screenShareUnsupported');
      return;
    }

    try {
      let displayStream: MediaStream;
      try {
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: { frameRate: { ideal: 30 } },
          audio: true,
        });
      } catch {
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });
      }

      const screenVideoTrack = displayStream.getVideoTracks()[0];
      if (!screenVideoTrack) return;

      stopAvatarProcessor();
      screenStreamRef.current = displayStream;
      setScreenSharing(true);
      setCallNotice(null);

      screenVideoTrack.onended = () => {
        void stopScreenShare();
      };

      const camAudioTrack = cameraStreamRef.current?.getAudioTracks()[0] || null;
      const screenAudioTrack = displayStream.getAudioTracks()[0] || null;
      let outgoingAudioTracks: MediaStreamTrack[] = camAudioTrack ? [camAudioTrack] : [];

      // Mix screen/window audio + microphone so mobile & desktop hear system/tab audio clearly
      if (screenAudioTrack) {
        try {
          const AudioCtxClass =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext?: typeof AudioContext })
              .webkitAudioContext;
          if (AudioCtxClass) {
            const ctx = new AudioCtxClass();
            if (ctx.state === 'suspended') {
              void ctx.resume().catch(() => {});
            }
            const dest = ctx.createMediaStreamDestination();
            const screenSource = ctx.createMediaStreamSource(
              new MediaStream([screenAudioTrack])
            );
            screenSource.connect(dest);

            if (camAudioTrack && camAudioTrack.readyState === 'live') {
              camAudioTrack.enabled = true;
              const micGain = ctx.createGain();
              micGain.gain.value = micEnabledRef.current ? 1 : 0;
              const micSource = ctx.createMediaStreamSource(
                new MediaStream([camAudioTrack])
              );
              micSource.connect(micGain);
              micGain.connect(dest);
              micGainNodeRef.current = micGain;
            }

            const mixedTrack = dest.stream.getAudioTracks()[0];
            if (mixedTrack) {
              audioMixerCtxRef.current = ctx;
              mixedAudioTrackRef.current = mixedTrack;
              outgoingAudioTracks = [mixedTrack];
              setScreenAudioActive(true);
            }
          }
        } catch {
          // Fallback to screen audio directly if AudioContext mixing fails
          outgoingAudioTracks = [screenAudioTrack];
          setScreenAudioActive(true);
        }
      } else {
        setScreenAudioActive(false);
      }

      const previewStream = new MediaStream([
        ...outgoingAudioTracks,
        screenVideoTrack,
      ]);
      localStreamRef.current = previewStream;
      setLocalStream(previewStream);

      await replaceOutgoingVideoTrack(screenVideoTrack, previewStream);
      if (outgoingAudioTracks[0] && outgoingAudioTracks[0] !== camAudioTrack) {
        await replaceOutgoingAudioTrack(outgoingAudioTracks[0], previewStream);
      }

      void syncParticipantDoc({ screenSharing: true, videoEnabled: true });
    } catch {
      // Cancelled
    }
  }, [
    inCall,
    replaceOutgoingAudioTrack,
    replaceOutgoingVideoTrack,
    stopAvatarProcessor,
    stopScreenShare,
    syncParticipantDoc,
  ]);

  const setCallAvatarFilter = useCallback(
    async (nextAvatar: CallAvatarId) => {
      avatarFilterRef.current = nextAvatar;
      setAvatarFilterState(nextAvatar);
      if (!inCall || screenSharingRef.current) return;

      const camVideoTrack = cameraStreamRef.current?.getVideoTracks()[0] || null;
      if (!camVideoTrack || camVideoTrack.readyState !== 'live' || !cameraEnabledRef.current) {
        if (nextAvatar === 'none') {
          stopAvatarProcessor();
        }
        return;
      }

      const audioTracks = cameraStreamRef.current?.getAudioTracks() || [];

      if (nextAvatar === 'none') {
        stopAvatarProcessor();
        const restored = new MediaStream([...audioTracks, camVideoTrack]);
        localStreamRef.current = restored;
        setLocalStream(restored);
        await replaceOutgoingVideoTrack(camVideoTrack, restored);
        return;
      }

      if (avatarProcessorRef.current) {
        avatarProcessorRef.current.setAvatarId(nextAvatar);
        return;
      }

      const proc = createAvatarVideoProcessor(camVideoTrack, nextAvatar);
      if (proc) {
        avatarProcessorRef.current = proc;
        const avatarStream = new MediaStream([...audioTracks, proc.videoTrack]);
        localStreamRef.current = avatarStream;
        setLocalStream(avatarStream);
        await replaceOutgoingVideoTrack(proc.videoTrack, avatarStream);
      }
    },
    [inCall, replaceOutgoingVideoTrack, stopAvatarProcessor]
  );

  const toggleMic = useCallback(() => {
    const stream = cameraStreamRef.current || localStreamRef.current;
    if (!stream) return;
    const audioTracks = stream.getAudioTracks();
    const next = !micEnabledRef.current;
    if (micGainNodeRef.current) {
      micGainNodeRef.current.gain.value = next ? 1 : 0;
    } else {
      if (audioTracks.length === 0) return;
      audioTracks.forEach((t) => {
        t.enabled = next;
      });
      localStreamRef.current?.getAudioTracks().forEach((t) => {
        t.enabled = next;
      });
    }
    setMicEnabled(next);
    void syncParticipantDoc({ audioEnabled: next });
  }, [syncParticipantDoc]);

  const toggleCamera = useCallback(async () => {
    const stream = cameraStreamRef.current || localStreamRef.current;
    const videoTracks = stream?.getVideoTracks() || [];

    if (videoTracks.length === 0 && !cameraEnabledRef.current) {
      // Turn on camera dynamically if starting from voice-only call
      if (navigator.mediaDevices?.getUserMedia) {
        try {
          let cam: MediaStream | null = null;
          const attempts: MediaStreamConstraints[] = [
            {
              video: {
                facingMode: { ideal: cameraFacingRef.current },
                width: { ideal: 640 },
                height: { ideal: 480 },
              },
            },
            { video: { facingMode: { ideal: cameraFacingRef.current } } },
            { video: true },
          ];
          for (const constraints of attempts) {
            try {
              cam = await navigator.mediaDevices.getUserMedia(constraints);
              if (cam.getVideoTracks().length > 0) break;
            } catch {
              // Try simpler mobile constraint
            }
          }

          const track = cam?.getVideoTracks()[0];
          if (track) {
            track.enabled = true;
            const audioTracks = cameraStreamRef.current?.getAudioTracks() || [];
            const rawMerged = new MediaStream([...audioTracks, track]);
            cameraStreamRef.current = rawMerged;

            let outgoingTrack: MediaStreamTrack = track;
            if (avatarFilterRef.current !== 'none') {
              const proc = createAvatarVideoProcessor(track, avatarFilterRef.current);
              if (proc) {
                avatarProcessorRef.current = proc;
                outgoingTrack = proc.videoTrack;
              }
            }
            const merged = new MediaStream([...audioTracks, outgoingTrack]);
            localStreamRef.current = merged;
            setLocalStream(merged);
            setCallNotice(null);

            await replaceOutgoingVideoTrack(outgoingTrack, merged);

            setCameraEnabled(true);
            void syncParticipantDoc({ videoEnabled: true });
          } else {
            setCallNotice('cameraHintBlocked');
          }
        } catch {
          setCallNotice('cameraHintBlocked');
        }
      }
      return;
    }

    if (videoTracks.length === 0) return;
    const next = !cameraEnabledRef.current;
    videoTracks.forEach((t) => {
      t.enabled = next;
    });
    if (!next) {
      stopAvatarProcessor();
      const audioTracks = cameraStreamRef.current?.getAudioTracks() || [];
      const paused = new MediaStream([...audioTracks, ...videoTracks]);
      localStreamRef.current = paused;
      setLocalStream(paused);
    } else if (avatarFilterRef.current !== 'none' && !screenSharingRef.current) {
      const rawCam = cameraStreamRef.current?.getVideoTracks()[0];
      const audioTracks = cameraStreamRef.current?.getAudioTracks() || [];
      if (rawCam) {
        const proc = createAvatarVideoProcessor(rawCam, avatarFilterRef.current);
        if (proc) {
          avatarProcessorRef.current = proc;
          const avatarStream = new MediaStream([...audioTracks, proc.videoTrack]);
          localStreamRef.current = avatarStream;
          setLocalStream(avatarStream);
          await replaceOutgoingVideoTrack(proc.videoTrack, avatarStream);
        }
      }
    } else {
      const refreshed = new MediaStream(
        (cameraStreamRef.current || localStreamRef.current)?.getTracks() || []
      );
      localStreamRef.current = refreshed;
      setLocalStream(refreshed);
    }
    setCameraEnabled(next);
    if (next) setCallNotice(null);
    if (!screenSharingRef.current) {
      void syncParticipantDoc({ videoEnabled: next });
    }
  }, [replaceOutgoingVideoTrack, stopAvatarProcessor, syncParticipantDoc]);

  useEffect(() => {
    return () => {
      stopAvatarProcessor();
      stopAudioMixer();
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
      cameraStreamRef.current?.getTracks().forEach((t) => t.stop());
      localStreamRef.current?.getTracks().forEach((t) => t.stop());
      for (const pc of peersRef.current.values()) {
        pc.close();
      }
    };
  }, [stopAudioMixer, stopAvatarProcessor]);

  return {
    inCall,
    isMinimized,
    joining,
    micEnabled,
    cameraEnabled,
    cameraFacing,
    canSwitchCamera,
    audioOutputs,
    selectedAudioOutputId,
    setSelectedAudioOutputId,
    screenSharing,
    screenAudioActive,
    avatarFilter,
    setCallAvatarFilter,
    callDurationSec,
    activeCallRoomId,
    activeCallMode,
    activeCallKind,
    activeCallPeer,
    localStream,
    remoteStreams,
    callParticipants,
    groupCallParticipants,
    callNotice,
    setIsMinimized,
    joinCall,
    leaveCall,
    rejectIncomingCall,
    toggleMic,
    toggleCamera,
    switchCamera,
    toggleScreenShare,
  };
}
