import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { OperationType, db, handleFirestoreError } from '../firebase';
import { STORY_TTL_MS, canViewStory } from '../shared/chatRules';
import type {
  StoryPrivacy,
  StoryStatus,
  StoryType,
  StoryViewer,
} from '../shared/types';
import { uploadMediaFile } from '../utils/storageHelper';

interface UseStoriesOptions {
  clientId: string;
  nickname: string | null;
  avatarColor: string;
  avatarUrl?: string | null;
  blockedPeerIds: string[];
  isAdmin: boolean;
}

export function useStories({
  clientId,
  nickname,
  avatarColor,
  avatarUrl,
  blockedPeerIds,
  isAdmin,
}: UseStoriesOptions) {
  const [rawStories, setRawStories] = useState<StoryStatus[]>([]);
  const [nowTick, setNowTick] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNowTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!nickname) return;
    const q = query(collection(db, 'statuses'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: StoryStatus[] = [];
        snapshot.forEach((docSnap) => {
          const item = docSnap.data() as StoryStatus;
          list.push(item);
        });
        setRawStories(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'statuses');
      }
    );
    return () => unsub();
  }, [nickname]);

  const visibleStories = useMemo(() => {
    return rawStories.filter((story) => {
      const blockedRelation = blockedPeerIds.includes(story.authorId);
      return canViewStory(story, clientId, blockedRelation, true, nowTick);
    });
  }, [blockedPeerIds, clientId, nowTick, rawStories]);

  // Group active stories by authorId for story ring strip
  const storiesByAuthor = useMemo(() => {
    const map = new Map<
      string,
      {
        authorId: string;
        authorName: string;
        authorColor: string;
        authorAvatarUrl?: string | null;
        stories: StoryStatus[];
        hasUnviewed: boolean;
      }
    >();

    for (const story of visibleStories) {
      const existing = map.get(story.authorId);
      const alreadyViewed =
        story.authorId === clientId ||
        story.viewers.some((v) => v.uid === clientId);
      if (!existing) {
        map.set(story.authorId, {
          authorId: story.authorId,
          authorName: story.authorName,
          authorColor: story.authorColor,
          authorAvatarUrl: story.authorAvatarUrl,
          stories: [story],
          hasUnviewed: !alreadyViewed,
        });
      } else {
        existing.stories.push(story);
        if (!alreadyViewed) existing.hasUnviewed = true;
      }
    }

    const groups = Array.from(map.values());
    groups.sort((a, b) => {
      if (a.authorId === clientId) return -1;
      if (b.authorId === clientId) return 1;
      if (a.hasUnviewed !== b.hasUnviewed) return a.hasUnviewed ? -1 : 1;
      return b.stories[0].createdAt - a.stories[0].createdAt;
    });
    return groups;
  }, [clientId, visibleStories]);

  const createStory = useCallback(
    async (input: {
      type: StoryType;
      text?: string;
      bgColor?: string;
      file?: File | null;
      privacy: StoryPrivacy;
      allowedViewerIds?: string[];
      excludedViewerIds?: string[];
    }) => {
      if (!nickname || !clientId) return;
      const now = Date.now();
      const id = `st-${now}-${Math.random().toString(36).slice(2, 7)}`;

      let mediaUrl: string | null = null;
      if (input.file && (input.type === 'image' || input.type === 'video')) {
        const res = await uploadMediaFile(
          input.file,
          'stories',
          clientId,
          input.file.name
        );
        mediaUrl = res.url;
      }

      const story: StoryStatus = {
        id,
        authorId: clientId,
        authorName: nickname,
        authorColor: avatarColor,
        authorAvatarUrl: avatarUrl ?? null,
        type: input.type,
        mediaUrl,
        text: (input.text || '').trim().slice(0, 400),
        bgColor: input.bgColor || '#6D28D9',
        privacy: input.privacy,
        allowedViewerIds: input.allowedViewerIds || [],
        excludedViewerIds: input.excludedViewerIds || [],
        viewers: [],
        createdAt: now,
        expiresAt: now + STORY_TTL_MS,
      };

      try {
        await setDoc(doc(db, 'statuses', id), story);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `statuses/${id}`);
      }
    },
    [avatarColor, avatarUrl, clientId, nickname]
  );

  const markStoryViewed = useCallback(
    async (story: StoryStatus) => {
      if (!nickname || !clientId || story.authorId === clientId) return;
      if (story.viewers.some((v) => v.uid === clientId)) return;

      const viewer: StoryViewer = {
        uid: clientId,
        name: nickname,
        avatarColor,
        avatarUrl: avatarUrl ?? null,
        viewedAt: Date.now(),
      };
      const nextViewers = [...story.viewers, viewer];
      try {
        await updateDoc(doc(db, 'statuses', story.id), {
          viewers: nextViewers,
        });
      } catch {
        // Ignore transient view write failures
      }
    },
    [avatarColor, avatarUrl, clientId, nickname]
  );

  const deleteStory = useCallback(
    async (story: StoryStatus) => {
      if (!clientId) return;
      if (story.authorId !== clientId && !isAdmin) return;
      try {
        await deleteDoc(doc(db, 'statuses', story.id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `statuses/${story.id}`);
      }
    },
    [clientId, isAdmin]
  );

  return {
    visibleStories,
    storiesByAuthor,
    createStory,
    markStoryViewed,
    deleteStory,
  };
}
