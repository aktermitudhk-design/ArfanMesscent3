import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  endBefore,
  getDoc,
  getDocs,
  limitToLast,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { MAIN_ROOM_ID, OperationType, db, handleFirestoreError } from '../firebase';
import {
  canDeleteContact,
  canDeleteForEveryone,
  canEditMessage,
  canForwardMessage,
  canSendUnderSlowMode,
  filterExpiredMessages,
  getDirectRoomId,
  getLatestReadableMessage,
  isDirectRoomId,
  isDirectRoomParticipant,
  isGroupRoomId,
  isSafeMediaUrl,
  isSelfOrHostTarget,
  isUserBlocked,
  normalizeNicknameKey,
  resolveTheme,
  shouldMarkMessageRead,
  shouldNotifyForMessage,
  togglePollVote,
  toggleReactionMap,
  validateBangladeshPhone,
  validateMessagePayload,
} from '../shared/chatRules';
import type {
  BlockedUser,
  ChatMessage,
  CustomSticker,
  DeletedContact,
  DirectPeer,
  DirectPing,
  DmThreadSummary,
  OnlineUser,
  PinnedMessageSummary,
  ReadReceipt,
  RegisteredUser,
  ReplyReference,
  ThemeId,
  UserProfile,
  UserReport,
} from '../shared/types';
import { showChatBrowserNotification } from '../utils/notificationHelper';
import {
  playMessageChime,
  playMessageSentSound,
  playMissedCallTone,
  startCallRingtone,
  stopCallRingtone,
} from '../utils/soundHelper';
import {
  deleteRoomBackgroundObject,
  uploadMediaFile,
  uploadRoomBackground as uploadBackgroundToStorage,
} from '../utils/storageHelper';
import {
  isStaticHostToken,
  issueStaticHostToken,
  verifyStaticHostPassword,
  verifyStaticHostToken,
} from '../utils/hostAuth';

interface UseChatSocketOptions {
  clientId: string;
  nickname: string | null;
  phoneNumber: string | null;
  avatarColor: string;
  avatarUrl?: string | null;
  isGuest: boolean;
  soundEnabled: boolean;
  browserNotifEnabled: boolean;
  mutedRoomIds: string[];
  blockedPeerIds: string[];
  profilesById?: Record<string, UserProfile>;
  activeRoomId: string;
  activeDirectPeer: DirectPeer | null;
  isAtBottom: boolean;
  inCall: boolean;
  onOpenDirectRoomFromAlert?: (ping: DirectPing) => void;
}

interface RoomDoc {
  roomTitle: string;
  theme: ThemeId;
  roomLocked: boolean;
  slowModeSec: number;
  guestAllowed: boolean;
  announcement?: string;
  allowMedia?: boolean;
  allowVoice?: boolean;
  allowPolls?: boolean;
  allowGroupCreation?: boolean;
  disappearingHours?: 0 | 24 | 168;
  pinnedMessage?: PinnedMessageSummary | null;
  backgroundImageUrl?: string | null;
  ownerEmail: string;
  updatedAt: number;
}

interface PresenceDoc {
  clientId: string;
  nickname: string;
  avatarColor: string;
  avatarUrl?: string | null;
  isAdmin: boolean;
  isGuest: boolean;
  isTyping: boolean;
  typingRoomId?: string;
  connectedAt: number;
  lastSeenAt: number;
}

const PAGE_SIZE = 40;
const PRESENCE_STALE_MS = 50_000;
const PRESENCE_HEARTBEAT_MS = 20_000;
const JOIN_NOTICE_COOLDOWN_MS = 5 * 60 * 1000;
const CALL_PING_STALE_MS = 60_000;
const HOST_TOKEN_STORAGE_KEY = 'arfan_host_token';

export function useChatSocket({
  clientId,
  nickname,
  phoneNumber,
  avatarColor,
  avatarUrl,
  isGuest,
  soundEnabled,
  browserNotifEnabled,
  mutedRoomIds,
  blockedPeerIds,
  profilesById,
  activeRoomId,
  activeDirectPeer,
  isAtBottom,
  inCall,
  onOpenDirectRoomFromAlert,
}: UseChatSocketOptions) {
  const [connected, setConnected] = useState(false);
  const [liveMessages, setLiveMessages] = useState<ChatMessage[]>([]);
  const [olderMessages, setOlderMessages] = useState<ChatMessage[]>([]);
  const [hasMoreOlder, setHasMoreOlder] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [readReceipts, setReadReceipts] = useState<ReadReceipt[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>([]);
  const [deletedContacts, setDeletedContacts] = useState<DeletedContact[]>([]);
  const [reports, setReports] = useState<UserReport[]>([]);
  const [indexedDmThreads, setIndexedDmThreads] = useState<DmThreadSummary[]>([]);
  const [discoveredDmThreads, setDiscoveredDmThreads] = useState<DmThreadSummary[]>([]);
  const [scanningDmThreads, setScanningDmThreads] = useState(false);
  const [customStickers, setCustomStickers] = useState<CustomSticker[]>([]);
  const [isTabVisible, setIsTabVisible] = useState<boolean>(
    () => typeof document === 'undefined' || !document.hidden
  );
  const [typingUsers, setTypingUsers] = useState<
    { clientId: string; nickname: string }[]
  >([]);
  const [themeId, setThemeId] = useState<ThemeId>('midnight-violet');
  const [roomLocked, setRoomLocked] = useState(false);
  const [roomTitle, setRoomTitle] = useState('ARFANMesscent Lounge');
  const [slowModeSec, setSlowModeSec] = useState(0);
  const [guestAllowed, setGuestAllowed] = useState(true);
  const [announcement, setAnnouncement] = useState('');
  const [allowMedia, setAllowMedia] = useState(true);
  const [allowVoice, setAllowVoice] = useState(true);
  const [allowPolls, setAllowPolls] = useState(true);
  const [allowGroupCreation, setAllowGroupCreation] = useState(true);
  const [disappearingHours, setDisappearingHours] = useState<0 | 24 | 168>(0);
  const [pinnedMessage, setPinnedMessage] =
    useState<PinnedMessageSummary | null>(null);
  const [backgroundImageUrl, setBackgroundImageUrl] = useState<string | null>(
    null
  );
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [authError, setAuthError] = useState<string | null>(null);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [unreadTabCount, setUnreadTabCount] = useState(0);

  const [unreadByPeerId, setUnreadByPeerId] = useState<Record<string, number>>(
    {}
  );
  const [latestDmAlert, setLatestDmAlert] = useState<DirectPing | null>(null);
  const [incomingCallPings, setIncomingCallPings] = useState<DirectPing[]>([]);
  const [missedCallAlerts, setMissedCallAlerts] = useState<DirectPing[]>([]);

  const lastSentAtRef = useRef(0);
  const connectedAtRef = useRef(Date.now());
  const lastWrittenReadByRoomRef = useRef<
    Record<string, { at: number; messageId: string }>
  >({});
  const joinedAtRef = useRef<number>((() => {
    try {
      const existing = Number(localStorage.getItem('arfan_joined_at') || '0');
      if (existing > 0) return existing;
      const now = Date.now();
      localStorage.setItem('arfan_joined_at', String(now));
      return now;
    } catch {
      return Date.now();
    }
  })());
  const initialMessagesLoadedRef = useRef(false);
  const seenMessageIdsRef = useRef<Set<string>>(new Set());
  const seenPingTimestampsRef = useRef<Map<string, number>>(new Map());
  const soundEnabledRef = useRef(soundEnabled);
  soundEnabledRef.current = soundEnabled;
  const browserNotifRef = useRef(browserNotifEnabled);
  browserNotifRef.current = browserNotifEnabled;
  const mutedRoomsRef = useRef(mutedRoomIds);
  mutedRoomsRef.current = mutedRoomIds;
  const blockedPeersRef = useRef(blockedPeerIds);
  blockedPeersRef.current = blockedPeerIds;
  const activeRoomIdRef = useRef(activeRoomId);
  activeRoomIdRef.current = activeRoomId;
  const onOpenDirectAlertRef = useRef(onOpenDirectRoomFromAlert);
  onOpenDirectAlertRef.current = onOpenDirectRoomFromAlert;

  // Verify persisted Host Admin signed token via backend API (or static-host token on Netlify)
  useEffect(() => {
    let token: string | null = null;
    try {
      token = localStorage.getItem(HOST_TOKEN_STORAGE_KEY);
    } catch {
      token = null;
    }
    if (!token) return;

    if (isStaticHostToken(token)) {
      if (verifyStaticHostToken(token)) {
        setIsAdmin(true);
      } else {
        try {
          localStorage.removeItem(HOST_TOKEN_STORAGE_KEY);
        } catch {
          // ignore
        }
      }
      return;
    }

    void fetch('/api/admin/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    })
      .then(async (res) => {
        const contentType = res.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          return { valid: false };
        }
        return (await res.json()) as { valid?: boolean };
      })
      .then((data: { valid?: boolean }) => {
        if (data.valid) {
          setIsAdmin(true);
        } else {
          try {
            localStorage.removeItem(HOST_TOKEN_STORAGE_KEY);
          } catch {
            // ignore
          }
        }
      })
      .catch(() => {});
  }, []);

  // Play distinct ringtone when receiving incoming call ping and not currently in call
  useEffect(() => {
    const hasIncomingCall = incomingCallPings.length > 0 && !inCall;
    if (hasIncomingCall && soundEnabled) {
      startCallRingtone();
    } else {
      stopCallRingtone();
    }
    return () => stopCallRingtone();
  }, [inCall, incomingCallPings.length, soundEnabled]);

  useEffect(() => {
    const handleVisibility = () => {
      const visible = !document.hidden;
      setIsTabVisible(visible);
      if (visible) {
        setUnreadTabCount(0);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () =>
      document.removeEventListener('visibilitychange', handleVisibility);
  }, []);

  useEffect(() => {
    document.title =
      unreadTabCount > 0
        ? `(${unreadTabCount}) ARFANMesscent — Live Chat`
        : 'ARFANMesscent — Live Chat';
  }, [unreadTabCount]);

  useEffect(() => {
    if (activeDirectPeer) {
      setUnreadByPeerId((prev) => {
        if (!prev[activeDirectPeer.clientId]) return prev;
        const next = { ...prev };
        delete next[activeDirectPeer.clientId];
        return next;
      });
      setLatestDmAlert((prev) =>
        prev?.fromClientId === activeDirectPeer.clientId ? null : prev
      );
      const pingId = `dmmsg__${activeDirectPeer.clientId}__${clientId}`.replace(
        /[^a-zA-Z0-9_-]/g,
        '_'
      );
      void deleteDoc(
        doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', pingId)
      ).catch(() => {});
    }
  }, [activeDirectPeer, clientId]);

  // Bootstrap /rooms/main if first ever launch
  useEffect(() => {
    if (!nickname || !phoneNumber) return;

    let cancelled = false;
    const roomRef = doc(db, 'rooms', MAIN_ROOM_ID);

    async function ensureRoomBootstrapped() {
      let roomSnap;
      try {
        roomSnap = await getDoc(roomRef);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `rooms/${MAIN_ROOM_ID}`);
      }

      if (cancelled || !roomSnap || roomSnap.exists()) return;

      const defaultRoom: RoomDoc = {
        roomTitle: 'ARFANMesscent Lounge',
        theme: 'midnight-violet',
        roomLocked: false,
        slowModeSec: 0,
        guestAllowed: true,
        pinnedMessage: null,
        backgroundImageUrl: null,
        ownerEmail: 'host@arfanmesscent.local',
        updatedAt: Date.now(),
      };

      try {
        await setDoc(roomRef, defaultRoom);
        const welcomeId = `sys-welcome-${Date.now()}`;
        const welcomeMsg: ChatMessage = {
          id: welcomeId,
          type: 'system',
          senderId: 'system',
          senderName: 'ARFANMesscent',
          senderColor: '#7C3AED',
          text: 'Welcome to ARFANMesscent! Share the invite link — friends can join as Guests or pick a nickname.',
          reactions: {},
          createdAt: Date.now(),
        };
        await setDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'messages', welcomeId),
          welcomeMsg
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `rooms/${MAIN_ROOM_ID}`);
      }
    }

    void ensureRoomBootstrapped();
    return () => {
      cancelled = true;
    };
  }, [nickname, phoneNumber]);

  // Subscribe to room settings, presence, blockedUsers, stickers, and personal directPings
  useEffect(() => {
    if (!nickname || !phoneNumber) return;

    const roomPath = `rooms/${MAIN_ROOM_ID}`;
    const unsubRoom = onSnapshot(
      doc(db, 'rooms', MAIN_ROOM_ID),
      (snap) => {
        setConnected(true);
        if (!snap.exists()) return;
        const data = snap.data() as RoomDoc;
        if (data.theme) setThemeId(data.theme);
        setRoomLocked(Boolean(data.roomLocked));
        if (data.roomTitle) setRoomTitle(data.roomTitle);
        setSlowModeSec(
          typeof data.slowModeSec === 'number' ? data.slowModeSec : 0
        );
        setGuestAllowed(
          data.guestAllowed !== undefined ? Boolean(data.guestAllowed) : true
        );
        setAnnouncement(typeof data.announcement === 'string' ? data.announcement : '');
        setAllowMedia(data.allowMedia !== undefined ? Boolean(data.allowMedia) : true);
        setAllowVoice(data.allowVoice !== undefined ? Boolean(data.allowVoice) : true);
        setAllowPolls(data.allowPolls !== undefined ? Boolean(data.allowPolls) : true);
        setAllowGroupCreation(
          data.allowGroupCreation !== undefined ? Boolean(data.allowGroupCreation) : true
        );
        setDisappearingHours(
          data.disappearingHours === 24 || data.disappearingHours === 168
            ? data.disappearingHours
            : 0
        );
        setPinnedMessage(data.pinnedMessage ?? null);
        setBackgroundImageUrl(data.backgroundImageUrl ?? null);
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, roomPath);
      }
    );

    const presencePath = `rooms/${MAIN_ROOM_ID}/presence`;
    const unsubPresence = onSnapshot(
      collection(db, 'rooms', MAIN_ROOM_ID, 'presence'),
      (snapshot) => {
        const now = Date.now();
        const active: OnlineUser[] = [];
        const typing: { clientId: string; nickname: string }[] = [];

        snapshot.forEach((docSnap) => {
          const p = docSnap.data() as PresenceDoc;
          if (now - p.lastSeenAt <= PRESENCE_STALE_MS) {
            active.push({
              clientId: p.clientId,
              nickname: p.nickname,
              avatarColor: p.avatarColor,
              avatarUrl: p.avatarUrl ?? null,
              isAdmin: Boolean(p.isAdmin),
              isGuest: Boolean(p.isGuest),
              connectedAt: p.connectedAt,
            });
            const typingMatch =
              p.typingRoomId === activeRoomIdRef.current ||
              (!p.typingRoomId && activeRoomIdRef.current === MAIN_ROOM_ID);
            if (
              p.isTyping &&
              p.clientId !== clientId &&
              typingMatch &&
              !blockedPeersRef.current.includes(p.clientId)
            ) {
              typing.push({ clientId: p.clientId, nickname: p.nickname });
            }
          }
        });

        active.sort((a, b) => {
          if (a.isAdmin !== b.isAdmin) return a.isAdmin ? -1 : 1;
          return a.connectedAt - b.connectedAt;
        });

        setOnlineUsers(active);
        setTypingUsers(typing);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, presencePath);
      }
    );

    const blockedPath = `rooms/${MAIN_ROOM_ID}/blockedUsers`;
    const unsubBlocked = onSnapshot(
      collection(db, 'rooms', MAIN_ROOM_ID, 'blockedUsers'),
      (snapshot) => {
        const list: BlockedUser[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as BlockedUser);
        });
        setBlockedUsers(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, blockedPath);
      }
    );

    const unsubStickers = onSnapshot(
      query(collection(db, 'stickers'), orderBy('createdAt', 'desc')),
      (snapshot) => {
        const list: CustomSticker[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as CustomSticker);
        });
        setCustomStickers(list);
      },
      () => {}
    );

    const pingsPath = `rooms/${MAIN_ROOM_ID}/directPings`;
    const pingsQuery = query(
      collection(db, 'rooms', MAIN_ROOM_ID, 'directPings'),
      where('toClientId', '==', clientId)
    );
    const unsubPings = onSnapshot(
      pingsQuery,
      (snapshot) => {
        const now = Date.now();
        const activeCalls: DirectPing[] = [];
        const missedCalls: DirectPing[] = [];

        snapshot.forEach((docSnap) => {
          const ping = docSnap.data() as DirectPing;
          if (blockedPeersRef.current.includes(ping.fromClientId)) {
            return;
          }

          if (ping.kind === 'dm_call') {
            if (now - ping.createdAt <= CALL_PING_STALE_MS) {
              activeCalls.push(ping);
              const lastSeen = seenPingTimestampsRef.current.get(ping.id) || 0;
              if (ping.createdAt > lastSeen) {
                seenPingTimestampsRef.current.set(ping.id, ping.createdAt);
                if (browserNotifRef.current && document.hidden) {
                  showChatBrowserNotification({
                    title: `${ping.fromNickname} is calling`,
                    body:
                      ping.callKind === 'audio'
                        ? 'Incoming Voice Call'
                        : 'Incoming Video Call',
                    tag: `call-${ping.id}-${ping.createdAt}`,
                  });
                }
              }
            } else {
              void deleteDoc(docSnap.ref).catch(() => {});
            }
          } else if (ping.kind === 'missed_call') {
            missedCalls.push(ping);
            const lastSeen = seenPingTimestampsRef.current.get(ping.id) || 0;
            if (ping.createdAt > lastSeen) {
              seenPingTimestampsRef.current.set(ping.id, ping.createdAt);
              if (soundEnabledRef.current) {
                playMissedCallTone();
              }
              if (browserNotifRef.current) {
                showChatBrowserNotification({
                  title: 'Missed Call',
                  body: `Missed call from ${ping.fromNickname}`,
                  tag: `missed-${ping.id}-${ping.createdAt}`,
                });
              }
            }
          } else if (ping.kind === 'dm_message') {
            const lastSeen = seenPingTimestampsRef.current.get(ping.id) || 0;
            if (ping.createdAt > lastSeen) {
              seenPingTimestampsRef.current.set(ping.id, ping.createdAt);
              const isMuted = mutedRoomsRef.current.includes(ping.dmRoomId);
              if (activeRoomIdRef.current !== ping.dmRoomId) {
                setUnreadByPeerId((prev) => ({
                  ...prev,
                  [ping.fromClientId]: (prev[ping.fromClientId] || 0) + 1,
                }));
                setLatestDmAlert(ping);
                if (soundEnabledRef.current && !isMuted) {
                  playMessageChime();
                }
                if (browserNotifRef.current && !isMuted) {
                  showChatBrowserNotification({
                    title: ping.fromNickname,
                    body: ping.previewText || 'Sent you a message',
                    tag: `dm-${ping.id}-${ping.createdAt}`,
                    onClick: () => onOpenDirectAlertRef.current?.(ping),
                  });
                }
                if (document.hidden && !isMuted) {
                  setUnreadTabCount((c) => c + 1);
                }
              } else {
                void deleteDoc(docSnap.ref).catch(() => {});
              }
            }
          }
        });

        activeCalls.sort((a, b) => b.createdAt - a.createdAt);
        missedCalls.sort((a, b) => b.createdAt - a.createdAt);
        setIncomingCallPings(activeCalls);
        setMissedCallAlerts(missedCalls);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, pingsPath);
      }
    );

    return () => {
      unsubRoom();
      unsubPresence();
      unsubBlocked();
      unsubStickers();
      unsubPings();
    };
  }, [clientId, nickname, phoneNumber]);

  // Subscribe to BD phone registry, deleted contacts archive, reports, and ALL private DM threads ONLY when Host mode is unlocked
  useEffect(() => {
    if (!nickname || !phoneNumber || !isAdmin) {
      setRegisteredUsers([]);
      setDeletedContacts([]);
      setReports([]);
      setIndexedDmThreads([]);
      setDiscoveredDmThreads([]);
      return;
    }

    const registryPath = `rooms/${MAIN_ROOM_ID}/phoneRegistry`;
    const unsubRegistry = onSnapshot(
      collection(db, 'rooms', MAIN_ROOM_ID, 'phoneRegistry'),
      (snapshot) => {
        const list: RegisteredUser[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as RegisteredUser);
        });
        list.sort((a, b) => b.lastSeenAt - a.lastSeenAt);
        setRegisteredUsers(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, registryPath);
      }
    );

    const deletedPath = `rooms/${MAIN_ROOM_ID}/deletedContacts`;
    const unsubDeleted = onSnapshot(
      query(
        collection(db, 'rooms', MAIN_ROOM_ID, 'deletedContacts'),
        orderBy('deletedAt', 'desc')
      ),
      (snapshot) => {
        const list: DeletedContact[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as DeletedContact);
        });
        setDeletedContacts(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, deletedPath);
      }
    );

    const reportsPath = `rooms/${MAIN_ROOM_ID}/reports`;
    const unsubReports = onSnapshot(
      query(
        collection(db, 'rooms', MAIN_ROOM_ID, 'reports'),
        orderBy('createdAt', 'desc')
      ),
      (snapshot) => {
        const list: UserReport[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as UserReport);
        });
        setReports(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, reportsPath);
      }
    );

    const dmThreadsPath = `rooms/${MAIN_ROOM_ID}/dmThreads`;
    const unsubDmThreads = onSnapshot(
      query(
        collection(db, 'rooms', MAIN_ROOM_ID, 'dmThreads'),
        orderBy('lastMessageAt', 'desc')
      ),
      (snapshot) => {
        const list: DmThreadSummary[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as DmThreadSummary);
        });
        setIndexedDmThreads(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, dmThreadsPath);
      }
    );

    return () => {
      unsubRegistry();
      unsubDeleted();
      unsubReports();
      unsubDmThreads();
    };
  }, [isAdmin, nickname, phoneNumber]);

  const allDmThreads = useMemo(() => {
    const map = new Map<string, DmThreadSummary>();
    for (const d of discoveredDmThreads) map.set(d.dmRoomId, d);
    for (const d of indexedDmThreads) map.set(d.dmRoomId, d);
    return Array.from(map.values()).sort(
      (a, b) => b.lastMessageAt - a.lastMessageAt
    );
  }, [discoveredDmThreads, indexedDmThreads]);

  const discoverAllDmThreads = useCallback(async () => {
    if (!isAdmin) return;
    setScanningDmThreads(true);
    try {
      const idSet = new Set<string>();
      if (clientId) idSet.add(clientId);
      for (const uid of Object.keys(profilesById || {})) idSet.add(uid);
      for (const u of registeredUsers) idSet.add(u.clientId);
      for (const u of onlineUsers) idSet.add(u.clientId);
      for (const d of deletedContacts) idSet.add(d.clientId);

      const ids = Array.from(idSet).filter(Boolean).slice(0, 36);
      const knownSet = new Set(indexedDmThreads.map((t) => t.dmRoomId));
      const candidateRooms: Array<{ dmRoomId: string; pA: string; pB: string }> = [];

      for (let i = 0; i < ids.length; i += 1) {
        for (let j = i + 1; j < ids.length; j += 1) {
          const dmRoomId = getDirectRoomId(ids[i], ids[j]);
          if (!knownSet.has(dmRoomId)) {
            const parts = dmRoomId.slice(4).split('__').slice(0, 2);
            if (parts.length === 2) {
              candidateRooms.push({ dmRoomId, pA: parts[0], pB: parts[1] });
            }
          }
        }
      }

      const found: DmThreadSummary[] = [];
      const chunkSize = 10;
      const capped = candidateRooms.slice(0, 140);
      for (let idx = 0; idx < capped.length; idx += chunkSize) {
        const chunk = capped.slice(idx, idx + chunkSize);
        const results = await Promise.all(
          chunk.map(async ({ dmRoomId, pA, pB }) => {
            try {
              const snap = await getDocs(
                query(
                  collection(db, 'rooms', dmRoomId, 'messages'),
                  orderBy('createdAt', 'asc'),
                  limitToLast(1)
                )
              );
              if (snap.empty) return null;
              const latest = snap.docs[0].data() as ChatMessage;
              const nameA =
                profilesById?.[pA]?.displayName ||
                registeredUsers.find((r) => r.clientId === pA)?.nickname ||
                deletedContacts.find((d) => d.clientId === pA)?.nickname ||
                pA;
              const nameB =
                profilesById?.[pB]?.displayName ||
                registeredUsers.find((r) => r.clientId === pB)?.nickname ||
                deletedContacts.find((d) => d.clientId === pB)?.nickname ||
                pB;
              const preview =
                latest.text ||
                (latest.poll ? `Poll: ${latest.poll.question}` : '') ||
                (latest.audioUrl || latest.audioDataUrl ? 'Voice Note' : '') ||
                (latest.videoUrl ? 'Video' : '') ||
                (latest.gifUrl ? 'GIF' : '') ||
                (latest.stickerUrl ? 'Sticker' : '') ||
                (latest.fileName ? `File: ${latest.fileName}` : '') ||
                (latest.imageUrl || latest.imageDataUrl ? 'Photo' : 'Message');

              const summary: DmThreadSummary = {
                dmRoomId,
                participantIds: [pA, pB],
                participantNames: {
                  [pA]: nameA.slice(0, 40),
                  [pB]: nameB.slice(0, 40),
                },
                lastMessagePreview: preview.slice(0, 140),
                lastSenderId: latest.senderId,
                lastSenderName: (latest.senderName || 'User').slice(0, 40),
                lastMessageAt: latest.createdAt,
              };
              return summary;
            } catch {
              return null;
            }
          })
        );
        for (const item of results) {
          if (item) found.push(item);
        }
      }

      if (found.length > 0) {
        setDiscoveredDmThreads((prev) => {
          const map = new Map<string, DmThreadSummary>();
          for (const d of prev) map.set(d.dmRoomId, d);
          for (const d of found) map.set(d.dmRoomId, d);
          return Array.from(map.values());
        });
      }
    } finally {
      setScanningDmThreads(false);
    }
  }, [
    clientId,
    deletedContacts,
    indexedDmThreads,
    isAdmin,
    onlineUsers,
    profilesById,
    registeredUsers,
  ]);

  // Subscribe to latest PAGE_SIZE messages for active room (only if authorized to view it)
  useEffect(() => {
    if (!nickname || !phoneNumber || !activeRoomId) return;
    if (
      isDirectRoomId(activeRoomId) &&
      !isAdmin &&
      !isDirectRoomParticipant(activeRoomId, clientId)
    ) {
      setLiveMessages([]);
      setOlderMessages([]);
      setHasMoreOlder(false);
      return;
    }

    initialMessagesLoadedRef.current = false;
    seenMessageIdsRef.current.clear();
    setLiveMessages([]);
    setOlderMessages([]);
    setHasMoreOlder(false);

    const messagesPath = `rooms/${activeRoomId}/messages`;
    const messagesQuery = query(
      collection(db, 'rooms', activeRoomId, 'messages'),
      orderBy('createdAt', 'asc'),
      limitToLast(PAGE_SIZE)
    );

    const unsubMessages = onSnapshot(
      messagesQuery,
      (snapshot) => {
        setConnected(true);
        const list: ChatMessage[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as ChatMessage);
        });

        if (!initialMessagesLoadedRef.current) {
          list.forEach((m) => seenMessageIdsRef.current.add(m.id));
          initialMessagesLoadedRef.current = true;
          setHasMoreOlder(list.length >= PAGE_SIZE);
        } else {
          for (const msg of list) {
            if (!seenMessageIdsRef.current.has(msg.id)) {
              seenMessageIdsRef.current.add(msg.id);
              const decision = shouldNotifyForMessage({
                message: msg,
                viewerId: clientId,
                roomId: activeRoomId,
                mutedRoomIds: mutedRoomsRef.current,
                blockedPeerIds: blockedPeersRef.current,
                soundEnabled: soundEnabledRef.current,
              });
              if (decision.playSound) {
                playMessageChime();
              }
              if (
                decision.showBrowserNotification &&
                browserNotifRef.current &&
                document.hidden
              ) {
                showChatBrowserNotification({
                  title: msg.senderName,
                  body:
                    msg.text ||
                    (msg.gifUrl ? 'Sent a GIF' : '') ||
                    (msg.stickerUrl ? 'Sent a sticker' : '') ||
                    (msg.imageUrl || msg.imageDataUrl ? 'Sent a photo' : '') ||
                    (msg.videoUrl ? 'Sent a video' : '') ||
                    (msg.audioUrl || msg.audioDataUrl ? 'Sent a voice note' : '') ||
                    (msg.fileName ? `File: ${msg.fileName}` : 'New message'),
                  tag: `msg-${msg.id}`,
                });
              }
              if (
                msg.type === 'user' &&
                msg.senderId !== clientId &&
                document.hidden &&
                !mutedRoomsRef.current.includes(activeRoomId)
              ) {
                setUnreadTabCount((c) => c + 1);
              }
            }
          }
        }

        setLiveMessages(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, messagesPath);
      }
    );

    return () => unsubMessages();
  }, [activeRoomId, clientId, isAdmin, nickname, phoneNumber]);

  const messages = useMemo(() => {
    const map = new Map<string, ChatMessage>();
    for (const m of olderMessages) map.set(m.id, m);
    for (const m of liveMessages) map.set(m.id, m);
    const active = Array.from(map.values())
      .filter((m) => !blockedPeerIds.includes(m.senderId))
      .sort((a, b) => a.createdAt - b.createdAt);
    return filterExpiredMessages(active, disappearingHours);
  }, [blockedPeerIds, disappearingHours, liveMessages, olderMessages]);

  const loadOlderMessages = useCallback(async () => {
    if (!activeRoomId || loadingOlder || !hasMoreOlder) return;
    const earliest = messages[0];
    if (!earliest) return;

    setLoadingOlder(true);
    try {
      const olderQuery = query(
        collection(db, 'rooms', activeRoomId, 'messages'),
        orderBy('createdAt', 'asc'),
        endBefore(earliest.createdAt),
        limitToLast(PAGE_SIZE)
      );
      const snap = await getDocs(olderQuery);
      const batch: ChatMessage[] = [];
      snap.forEach((docSnap) => {
        batch.push(docSnap.data() as ChatMessage);
      });
      if (batch.length > 0) {
        batch.forEach((m) => seenMessageIdsRef.current.add(m.id));
        setOlderMessages((prev) => {
          const map = new Map<string, ChatMessage>();
          for (const m of batch) map.set(m.id, m);
          for (const m of prev) map.set(m.id, m);
          return Array.from(map.values()).sort(
            (a, b) => a.createdAt - b.createdAt
          );
        });
      }
      setHasMoreOlder(batch.length >= PAGE_SIZE);
    } catch {
      // Ignore transient query errors
    } finally {
      setLoadingOlder(false);
    }
  }, [activeRoomId, hasMoreOlder, loadingOlder, messages]);

  // Subscribe to readReceipts for the currently selected room
  useEffect(() => {
    if (!nickname || !phoneNumber || !activeRoomId) {
      setReadReceipts([]);
      return;
    }
    if (
      isDirectRoomId(activeRoomId) &&
      !isAdmin &&
      !isDirectRoomParticipant(activeRoomId, clientId)
    ) {
      setReadReceipts([]);
      return;
    }

    setReadReceipts([]);
    const receiptsPath = `rooms/${activeRoomId}/readReceipts`;
    const unsubReceipts = onSnapshot(
      collection(db, 'rooms', activeRoomId, 'readReceipts'),
      (snapshot) => {
        const list: ReadReceipt[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as ReadReceipt);
        });
        setReadReceipts(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, receiptsPath);
      }
    );

    return () => unsubReceipts();
  }, [activeRoomId, clientId, isAdmin, nickname, phoneNumber]);

  // Ensure blockedUsers is still listened even if BlockedScreen is visible when blocked earlier
  useEffect(() => {
    if (!isAdmin || blockedUsers.length === 0) return;
    const phoneNormalized = phoneNumber
      ? validateBangladeshPhone(phoneNumber).normalized
      : '';
    const nickKey = nickname ? normalizeNicknameKey(nickname) : '';

    const matchingDocs: string[] = [];
    for (const bu of blockedUsers) {
      const buPhone = bu.phoneNumber
        ? validateBangladeshPhone(bu.phoneNumber).normalized
        : '';
      if (
        (bu.clientId && bu.clientId === clientId) ||
        (nickKey && normalizeNicknameKey(bu.nickname) === nickKey) ||
        (phoneNormalized && buPhone && buPhone === phoneNormalized)
      ) {
        if (bu.clientId) matchingDocs.push(bu.clientId);
        if (buPhone) matchingDocs.push(`phone-${buPhone}`);
        const nk = normalizeNicknameKey(bu.nickname).replace(/[^a-z0-9]/g, '_');
        if (nk) matchingDocs.push(`nick-${nk}`);
      }
    }

    if (matchingDocs.length > 0) {
      void getDocs(collection(db, 'rooms', MAIN_ROOM_ID, 'blockedUsers'))
        .then((snap) => {
          const batch = writeBatch(db);
          let hasDeletions = false;
          snap.forEach((docSnap) => {
            const data = docSnap.data() as BlockedUser;
            const entryPhone = data.phoneNumber
              ? validateBangladeshPhone(data.phoneNumber).normalized
              : '';
            const matches =
              data.clientId === clientId ||
              docSnap.id === clientId ||
              (nickKey && normalizeNicknameKey(data.nickname) === nickKey) ||
              (phoneNormalized && entryPhone && entryPhone === phoneNormalized);
            if (matches) {
              batch.delete(docSnap.ref);
              hasDeletions = true;
            }
          });
          if (hasDeletions) return batch.commit();
          return undefined;
        })
        .catch(() => {});
    }
  }, [blockedUsers, clientId, isAdmin, nickname, phoneNumber]);

  const blockedByAdmin =
    !isAdmin &&
    Boolean(nickname) &&
    isUserBlocked(
      blockedUsers,
      clientId,
      nickname || undefined,
      phoneNumber || undefined
    );
  const blockedAsGuest = !isAdmin && isGuest && !guestAllowed;
  const isBlocked = blockedByAdmin || blockedAsGuest;
  const kickReason = blockedAsGuest
    ? 'Guest access is currently paused by Host. Please enter a nickname.'
    : undefined;

  // Automatically record read receipt when user views latest message in active room
  useEffect(() => {
    if (!nickname || !phoneNumber || !activeRoomId || isBlocked) return;
    const latestMsg = getLatestReadableMessage(messages);
    const existingForRoom = lastWrittenReadByRoomRef.current[activeRoomId];
    const myFirestoreReceipt = readReceipts.find((r) => r.clientId === clientId);
    const lastAt = Math.max(
      existingForRoom?.at || 0,
      myFirestoreReceipt?.lastReadAt || 0
    );
    const lastId =
      existingForRoom?.messageId ?? myFirestoreReceipt?.lastReadMessageId ?? null;

    if (
      !shouldMarkMessageRead(lastAt, lastId, latestMsg, isTabVisible, isAtBottom) ||
      !latestMsg
    ) {
      return;
    }

    lastWrittenReadByRoomRef.current[activeRoomId] = {
      at: latestMsg.createdAt,
      messageId: latestMsg.id,
    };

    const receiptPath = `rooms/${activeRoomId}/readReceipts/${clientId}`;
    const payload: ReadReceipt = {
      clientId,
      nickname,
      avatarColor,
      lastReadMessageId: latestMsg.id,
      lastReadAt: latestMsg.createdAt,
      updatedAt: Date.now(),
    };

    void setDoc(
      doc(db, 'rooms', activeRoomId, 'readReceipts', clientId),
      payload
    ).catch((err) =>
      handleFirestoreError(err, OperationType.WRITE, receiptPath)
    );
  }, [
    activeRoomId,
    avatarColor,
    clientId,
    isAtBottom,
    isBlocked,
    isTabVisible,
    messages,
    nickname,
    phoneNumber,
    readReceipts,
  ]);

  // Mark recent unread messages as delivered to current clientId
  useEffect(() => {
    if (!nickname || !activeRoomId || isBlocked) return;
    const recentUndelivered = messages
      .slice(-15)
      .filter(
        (m) =>
          m.type === 'user' &&
          m.senderId !== clientId &&
          !(m.deliveredTo || []).includes(clientId)
      );
    for (const msg of recentUndelivered) {
      const nextDelivered = Array.from(
        new Set([...(msg.deliveredTo || []), clientId])
      ).slice(-100);
      void updateDoc(doc(db, 'rooms', activeRoomId, 'messages', msg.id), {
        deliveredTo: nextDelivered,
      }).catch(() => {});
    }
  }, [activeRoomId, clientId, isBlocked, messages, nickname]);

  // Record user's BD phone number in isolated Host-only registry
  useEffect(() => {
    if (!nickname || !phoneNumber || isBlocked) return;
    const phoneCheck = validateBangladeshPhone(phoneNumber);
    if (!phoneCheck.valid) return;

    const registryPath = `rooms/${MAIN_ROOM_ID}/phoneRegistry/${clientId}`;
    const registryRef = doc(
      db,
      'rooms',
      MAIN_ROOM_ID,
      'phoneRegistry',
      clientId
    );

    const writeRegistry = async () => {
      const payload: RegisteredUser = {
        clientId,
        nickname,
        phoneNumber: phoneCheck.normalized,
        avatarColor,
        isGuest: isGuest && !isAdmin,
        joinedAt: joinedAtRef.current,
        lastSeenAt: Date.now(),
      };
      try {
        await setDoc(registryRef, payload);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, registryPath);
      }
    };

    void writeRegistry();
    const timer = setInterval(() => {
      void writeRegistry();
    }, 60_000);

    return () => clearInterval(timer);
  }, [avatarColor, clientId, isAdmin, isBlocked, isGuest, nickname, phoneNumber]);

  // Sync own presence & heartbeat + 5-min anti-spam join notice
  useEffect(() => {
    if (!nickname || !phoneNumber || isBlocked) return;

    const presencePath = `rooms/${MAIN_ROOM_ID}/presence/${clientId}`;
    const presenceRef = doc(db, 'rooms', MAIN_ROOM_ID, 'presence', clientId);

    const writePresence = async (typingState: boolean) => {
      const payload: PresenceDoc = {
        clientId,
        nickname,
        avatarColor,
        avatarUrl: avatarUrl ?? null,
        isAdmin,
        isGuest: isGuest && !isAdmin,
        isTyping: typingState,
        typingRoomId: activeRoomIdRef.current,
        connectedAt: connectedAtRef.current,
        lastSeenAt: Date.now(),
      };
      try {
        await setDoc(presenceRef, payload);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, presencePath);
      }
    };

    void writePresence(false);

    const joinKey = `arfan_last_join_${clientId}`;
    const lastJoinAt = Number(localStorage.getItem(joinKey) || '0');
    const now = Date.now();
    if (now - lastJoinAt > JOIN_NOTICE_COOLDOWN_MS) {
      try {
        localStorage.setItem(joinKey, String(now));
      } catch {
        // Ignore storage errors
      }
      const sysId = `sys-join-${now}-${Math.random().toString(36).slice(2, 6)}`;
      const joinMsg: ChatMessage = {
        id: sysId,
        type: 'system',
        senderId: 'system',
        senderName: 'ARFANMesscent',
        senderColor: avatarColor,
        text: isGuest
          ? `${nickname} joined as a Guest`
          : `${nickname} joined the chat`,
        reactions: {},
        createdAt: now,
      };
      void setDoc(
        doc(db, 'rooms', MAIN_ROOM_ID, 'messages', sysId),
        joinMsg
      ).catch((err) =>
        handleFirestoreError(
          err,
          OperationType.CREATE,
          `rooms/${MAIN_ROOM_ID}/messages/${sysId}`
        )
      );
    }

    const heartbeat = setInterval(() => {
      void writePresence(false);
    }, PRESENCE_HEARTBEAT_MS);

    const cleanupPresence = () => {
      void deleteDoc(presenceRef).catch(() => {});
    };

    window.addEventListener('pagehide', cleanupPresence);
    window.addEventListener('beforeunload', cleanupPresence);

    return () => {
      clearInterval(heartbeat);
      window.removeEventListener('pagehide', cleanupPresence);
      window.removeEventListener('beforeunload', cleanupPresence);
      cleanupPresence();
    };
  }, [avatarColor, avatarUrl, clientId, isAdmin, isBlocked, isGuest, nickname, phoneNumber]);

  const themeSpec = resolveTheme(themeId);
  useEffect(() => {
    if (themeSpec.isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [themeSpec.isDark]);

  const showRoomError = useCallback((msg: string) => {
    setRoomError(msg);
    setTimeout(() => setRoomError(null), 3500);
  }, []);

  const postMessageToRoom = useCallback(
    async (
      targetRoomId: string,
      targetDirectPeer: DirectPeer | null,
      payload: {
        text: string;
        imageDataUrl?: string;
        imageUrl?: string;
        videoUrl?: string;
        audioDataUrl?: string;
        audioUrl?: string;
        audioDurationSec?: number;
        fileUrl?: string;
        fileName?: string;
        fileSize?: number;
        fileMime?: string;
        gifUrl?: string;
        stickerUrl?: string;
        poll?: { question: string; options: string[] };
        replyTo?: ReplyReference;
        forwardedFrom?: ChatMessage['forwardedFrom'];
      }
    ) => {
      if (!nickname || isBlocked) return;
      if (targetRoomId === MAIN_ROOM_ID && roomLocked && !isAdmin) {
        showRoomError('Chat is currently paused by Host.');
        return;
      }

      const now = Date.now();
      if (!isDirectRoomId(targetRoomId) && !isGroupRoomId(targetRoomId)) {
        const slowCheck = canSendUnderSlowMode(
          lastSentAtRef.current,
          now,
          slowModeSec,
          isAdmin
        );
        if (!slowCheck.allowed) {
          showRoomError(
            `Slow mode is active. Wait ${slowCheck.waitSec}s before sending.`
          );
          return;
        }
      }

      const validated = validateMessagePayload(payload);
      if (!validated.valid) {
        showRoomError(validated.error || 'Invalid message.');
        return;
      }

      lastSentAtRef.current = now;
      const id = `msg-${now}-${Math.random().toString(36).slice(2, 8)}`;

      const cleanMessage: ChatMessage = {
        id,
        type: 'user',
        senderId: clientId,
        senderName: nickname,
        senderColor: avatarColor,
        senderAvatarUrl: avatarUrl ?? null,
        isAdmin,
        isGuest: isGuest && !isAdmin,
        text: validated.text,
        reactions: {},
        createdAt: now,
      };

      if (validated.imageDataUrl) cleanMessage.imageDataUrl = validated.imageDataUrl;
      if (validated.imageUrl) cleanMessage.imageUrl = validated.imageUrl;
      if (validated.videoUrl) cleanMessage.videoUrl = validated.videoUrl;
      if (validated.audioDataUrl) cleanMessage.audioDataUrl = validated.audioDataUrl;
      if (validated.audioUrl) cleanMessage.audioUrl = validated.audioUrl;
      if (typeof payload.audioDurationSec === 'number') {
        cleanMessage.audioDurationSec = Math.max(
          0,
          Math.round(payload.audioDurationSec)
        );
      }
      if (validated.fileUrl) {
        cleanMessage.fileUrl = validated.fileUrl;
        if (validated.fileName) cleanMessage.fileName = validated.fileName;
        if (typeof validated.fileSize === 'number') {
          cleanMessage.fileSize = validated.fileSize;
        }
        if (validated.fileMime) cleanMessage.fileMime = validated.fileMime;
      }
      if (validated.gifUrl) cleanMessage.gifUrl = validated.gifUrl;
      if (validated.stickerUrl) cleanMessage.stickerUrl = validated.stickerUrl;
      if (validated.poll) cleanMessage.poll = validated.poll;
      if (payload.replyTo) {
        cleanMessage.replyTo = {
          messageId: payload.replyTo.messageId,
          senderName: payload.replyTo.senderName,
          textPreview: payload.replyTo.textPreview,
          ...(payload.replyTo.hasImage ? { hasImage: true } : {}),
          ...(payload.replyTo.hasVideo ? { hasVideo: true } : {}),
          ...(payload.replyTo.hasAudio ? { hasAudio: true } : {}),
          ...(payload.replyTo.hasFile ? { hasFile: true } : {}),
          ...(payload.replyTo.hasGif ? { hasGif: true } : {}),
          ...(payload.replyTo.hasSticker ? { hasSticker: true } : {}),
          ...(payload.replyTo.hasPoll ? { hasPoll: true } : {}),
        };
      }
      if (payload.forwardedFrom) {
        cleanMessage.forwardedFrom = payload.forwardedFrom;
      }

      const msgPath = `rooms/${targetRoomId}/messages/${id}`;
      try {
        await setDoc(
          doc(db, 'rooms', targetRoomId, 'messages', id),
          cleanMessage
        );
        if (soundEnabledRef.current) {
          playMessageSentSound();
        }

        if (isDirectRoomId(targetRoomId)) {
          const preview =
            validated.text ||
            (validated.poll ? `Poll: ${validated.poll.question}` : '') ||
            (validated.audioUrl || validated.audioDataUrl ? 'Voice Note' : '') ||
            (validated.videoUrl ? 'Video' : '') ||
            (validated.gifUrl ? 'GIF' : '') ||
            (validated.stickerUrl ? 'Sticker' : '') ||
            (validated.fileName ? `File: ${validated.fileName}` : '') ||
            (validated.imageUrl || validated.imageDataUrl ? 'Photo' : '');

          const participants = targetRoomId.slice(4).split('__').slice(0, 2);
          if (participants.length === 2) {
            const pA = participants[0];
            const pB = participants[1];
            const nameA =
              pA === clientId
                ? nickname
                : targetDirectPeer?.clientId === pA
                  ? targetDirectPeer.nickname
                  : profilesById?.[pA]?.displayName || pA;
            const nameB =
              pB === clientId
                ? nickname
                : targetDirectPeer?.clientId === pB
                  ? targetDirectPeer.nickname
                  : profilesById?.[pB]?.displayName || pB;
            const dmThread: DmThreadSummary = {
              dmRoomId: targetRoomId,
              participantIds: participants,
              participantNames: { [pA]: nameA.slice(0, 40), [pB]: nameB.slice(0, 40) },
              lastMessagePreview: preview.slice(0, 140),
              lastSenderId: clientId,
              lastSenderName: nickname.slice(0, 40),
              lastMessageAt: now,
            };
            void setDoc(
              doc(db, 'rooms', MAIN_ROOM_ID, 'dmThreads', targetRoomId),
              dmThread
            ).catch(() => {});
          }

          if (targetDirectPeer) {
            const pingId = `dmmsg__${clientId}__${targetDirectPeer.clientId}`.replace(
              /[^a-zA-Z0-9_-]/g,
              '_'
            );
            const pingDoc: DirectPing = {
              id: pingId,
              toClientId: targetDirectPeer.clientId,
              fromClientId: clientId,
              fromNickname: nickname,
              fromColor: avatarColor,
              dmRoomId: targetRoomId,
              kind: 'dm_message',
              previewText: preview.slice(0, 140),
              createdAt: now,
            };
            await setDoc(
              doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', pingId),
              pingDoc
            );
          }
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, msgPath);
      }
    },
    [
      avatarColor,
      avatarUrl,
      clientId,
      isAdmin,
      isBlocked,
      isGuest,
      nickname,
      profilesById,
      roomLocked,
      showRoomError,
      slowModeSec,
    ]
  );

  const sendMessage = useCallback(
    async (payload: Parameters<typeof postMessageToRoom>[2]) => {
      await postMessageToRoom(activeRoomId, activeDirectPeer, payload);
    },
    [activeDirectPeer, activeRoomId, postMessageToRoom]
  );

  const editMessage = useCallback(
    async (messageId: string, nextText: string) => {
      const target = messages.find((m) => m.id === messageId);
      if (!target || !canEditMessage(target, clientId)) {
        showRoomError('You can only edit your own text messages.');
        return;
      }
      const trimmed = nextText.trim();
      if (!trimmed || trimmed.length > 2000) return;
      try {
        await updateDoc(doc(db, 'rooms', activeRoomId, 'messages', messageId), {
          text: trimmed,
          editedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `rooms/${activeRoomId}/messages/${messageId}`
        );
      }
    },
    [activeRoomId, clientId, messages, showRoomError]
  );

  const forwardMessage = useCallback(
    async (
      sourceMsg: ChatMessage,
      targetRoomId: string,
      targetPeer: DirectPeer | null
    ) => {
      if (!canForwardMessage(sourceMsg)) return;
      await postMessageToRoom(targetRoomId, targetPeer, {
        text: sourceMsg.text,
        imageDataUrl: sourceMsg.imageDataUrl,
        imageUrl: sourceMsg.imageUrl,
        videoUrl: sourceMsg.videoUrl,
        audioDataUrl: sourceMsg.audioDataUrl,
        audioUrl: sourceMsg.audioUrl,
        audioDurationSec: sourceMsg.audioDurationSec,
        fileUrl: sourceMsg.fileUrl,
        fileName: sourceMsg.fileName,
        fileSize: sourceMsg.fileSize,
        fileMime: sourceMsg.fileMime,
        gifUrl: sourceMsg.gifUrl,
        stickerUrl: sourceMsg.stickerUrl,
        forwardedFrom: {
          senderId: sourceMsg.senderId,
          senderName: sourceMsg.senderName,
          originalMessageId: sourceMsg.id,
        },
      });
    },
    [postMessageToRoom]
  );

  const uploadCustomSticker = useCallback(
    async (file: File, label?: string): Promise<CustomSticker | null> => {
      if (!clientId) return null;
      const uploaded = await uploadMediaFile(
        file,
        'stickers',
        clientId,
        file.name
      );
      const id = `stk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const sticker: CustomSticker = {
        id,
        url: uploaded.url,
        label: (label || file.name.replace(/\.[^.]+$/, '') || 'Sticker').slice(
          0,
          40
        ),
        ownerId: clientId,
        createdAt: Date.now(),
      };
      await setDoc(doc(db, 'stickers', id), sticker);
      return sticker;
    },
    [clientId]
  );

  const reactToMessage = useCallback(
    async (messageId: string, emoji: string) => {
      const target = messages.find((m) => m.id === messageId);
      if (!target) return;
      const nextReactions = toggleReactionMap(
        target.reactions || {},
        emoji,
        clientId
      );
      const msgPath = `rooms/${activeRoomId}/messages/${messageId}`;
      try {
        await updateDoc(
          doc(db, 'rooms', activeRoomId, 'messages', messageId),
          { reactions: nextReactions }
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, msgPath);
      }
    },
    [activeRoomId, clientId, messages]
  );

  const votePoll = useCallback(
    async (messageId: string, optionId: string) => {
      const target = messages.find((m) => m.id === messageId);
      if (!target?.poll) return;
      const nextPoll = togglePollVote(target.poll, optionId, clientId);
      const msgPath = `rooms/${activeRoomId}/messages/${messageId}`;
      try {
        await updateDoc(
          doc(db, 'rooms', activeRoomId, 'messages', messageId),
          { poll: nextPoll }
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, msgPath);
      }
    },
    [activeRoomId, clientId, messages]
  );

  const sendTyping = useCallback(
    (isTyping: boolean) => {
      if (!nickname || isBlocked) return;
      const presencePath = `rooms/${MAIN_ROOM_ID}/presence/${clientId}`;
      const payload: PresenceDoc = {
        clientId,
        nickname,
        avatarColor,
        avatarUrl: avatarUrl ?? null,
        isAdmin,
        isGuest: isGuest && !isAdmin,
        isTyping,
        typingRoomId: activeRoomId,
        connectedAt: connectedAtRef.current,
        lastSeenAt: Date.now(),
      };
      void setDoc(
        doc(db, 'rooms', MAIN_ROOM_ID, 'presence', clientId),
        payload
      ).catch((err) =>
        handleFirestoreError(err, OperationType.UPDATE, presencePath)
      );
    },
    [
      activeRoomId,
      avatarColor,
      avatarUrl,
      clientId,
      isAdmin,
      isBlocked,
      isGuest,
      nickname,
    ]
  );

  // Asynchronous server-side Host password verification, with salted SHA-256 fallback on static hosting (Netlify Drop)
  const loginAdmin = useCallback(async (password: string): Promise<boolean> => {
    setAuthError(null);
    let backendHandled = false;
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json') && res.status !== 404 && res.status !== 405) {
        backendHandled = true;
        const data = (await res.json()) as {
          success?: boolean;
          token?: string;
          error?: string;
        };
        if (res.ok && data.success && data.token) {
          setIsAdmin(true);
          setAuthError(null);
          try {
            localStorage.setItem(HOST_TOKEN_STORAGE_KEY, data.token);
          } catch {
            // ignore
          }
          return true;
        }
        setAuthError(data.error || 'wrongPassword');
        return false;
      }
    } catch {
      // Static HTML hosting (e.g. Netlify Drop) has no /api backend — continue to static verifier
    }

    if (!backendHandled) {
      const validStatic = await verifyStaticHostPassword(password);
      if (validStatic) {
        const staticToken = issueStaticHostToken();
        setIsAdmin(true);
        setAuthError(null);
        try {
          localStorage.setItem(HOST_TOKEN_STORAGE_KEY, staticToken);
        } catch {
          // ignore
        }
        return true;
      }
      setAuthError('wrongPassword');
      return false;
    }

    setAuthError('wrongPassword');
    return false;
  }, []);

  const unlockSelfAsHost = useCallback(
    async (password: string): Promise<boolean> => {
      const ok = await loginAdmin(password);
      if (!ok) return false;
      const phoneNormalized = phoneNumber
        ? validateBangladeshPhone(phoneNumber).normalized
        : '';
      const nickKey = nickname ? normalizeNicknameKey(nickname) : '';
      try {
        const snap = await getDocs(
          collection(db, 'rooms', MAIN_ROOM_ID, 'blockedUsers')
        );
        const batch = writeBatch(db);
        let removedAny = false;
        snap.forEach((docSnap) => {
          const data = docSnap.data() as BlockedUser;
          const entryPhone = data.phoneNumber
            ? validateBangladeshPhone(data.phoneNumber).normalized
            : '';
          const matches =
            data.clientId === clientId ||
            docSnap.id === clientId ||
            (nickKey && normalizeNicknameKey(data.nickname) === nickKey) ||
            (phoneNormalized && entryPhone && entryPhone === phoneNormalized);
          if (matches) {
            batch.delete(docSnap.ref);
            removedAny = true;
          }
        });
        if (removedAny) {
          await batch.commit();
        }
      } catch {
        // Ignore cleanup failures
      }
      return true;
    },
    [clientId, loginAdmin, nickname, phoneNumber]
  );

  const logoutAdmin = useCallback(() => {
    setIsAdmin(false);
    setAuthError(null);
    try {
      localStorage.removeItem(HOST_TOKEN_STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  const updateRoomDoc = useCallback(
    async (patch: Partial<RoomDoc>) => {
      if (!isAdmin) return;
      const roomPath = `rooms/${MAIN_ROOM_ID}`;
      const nextRoom: RoomDoc = {
        roomTitle: patch.roomTitle ?? roomTitle,
        theme: patch.theme ?? themeId,
        roomLocked: patch.roomLocked ?? roomLocked,
        slowModeSec: patch.slowModeSec ?? slowModeSec,
        guestAllowed: patch.guestAllowed ?? guestAllowed,
        announcement:
          patch.announcement !== undefined ? patch.announcement : announcement,
        allowMedia:
          patch.allowMedia !== undefined ? patch.allowMedia : allowMedia,
        allowVoice:
          patch.allowVoice !== undefined ? patch.allowVoice : allowVoice,
        allowPolls:
          patch.allowPolls !== undefined ? patch.allowPolls : allowPolls,
        allowGroupCreation:
          patch.allowGroupCreation !== undefined
            ? patch.allowGroupCreation
            : allowGroupCreation,
        disappearingHours:
          patch.disappearingHours !== undefined
            ? patch.disappearingHours
            : disappearingHours,
        pinnedMessage:
          patch.pinnedMessage !== undefined
            ? patch.pinnedMessage
            : pinnedMessage,
        backgroundImageUrl:
          patch.backgroundImageUrl !== undefined
            ? patch.backgroundImageUrl
            : backgroundImageUrl,
        ownerEmail: 'host@arfanmesscent.local',
        updatedAt: Date.now(),
      };
      try {
        await setDoc(doc(db, 'rooms', MAIN_ROOM_ID), nextRoom);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, roomPath);
      }
    },
    [
      allowGroupCreation,
      allowMedia,
      allowPolls,
      allowVoice,
      announcement,
      backgroundImageUrl,
      disappearingHours,
      guestAllowed,
      isAdmin,
      pinnedMessage,
      roomLocked,
      roomTitle,
      slowModeSec,
      themeId,
    ]
  );

  const setRoomTheme = useCallback(
    (nextTheme: ThemeId) => {
      void updateRoomDoc({ theme: nextTheme });
    },
    [updateRoomDoc]
  );

  const setRoomBackgroundPreset = useCallback(
    async (presetUrl: string | null) => {
      if (!isAdmin) return;
      if (presetUrl && !isSafeMediaUrl(presetUrl)) return;
      await updateRoomDoc({ backgroundImageUrl: presetUrl });
    },
    [isAdmin, updateRoomDoc]
  );

  const uploadRoomBackground = useCallback(
    async (file: File, onProgress?: (percent: number) => void) => {
      if (!isAdmin) return { usedFallback: false };
      const result = await uploadBackgroundToStorage(
        file,
        backgroundImageUrl,
        onProgress
      );
      await updateRoomDoc({ backgroundImageUrl: result.url });
      return { usedFallback: result.usedFallback };
    },
    [backgroundImageUrl, isAdmin, updateRoomDoc]
  );

  const clearRoomBackground = useCallback(async () => {
    if (!isAdmin) return;
    if (backgroundImageUrl) {
      await deleteRoomBackgroundObject(backgroundImageUrl);
    }
    await updateRoomDoc({ backgroundImageUrl: null });
  }, [backgroundImageUrl, isAdmin, updateRoomDoc]);

  const toggleLock = useCallback(
    (locked: boolean) => {
      void updateRoomDoc({ roomLocked: locked });
    },
    [updateRoomDoc]
  );

  const updateRoomSettings = useCallback(
    (settings: {
      roomTitle?: string;
      slowModeSec?: number;
      guestAllowed?: boolean;
      announcement?: string;
      allowMedia?: boolean;
      allowVoice?: boolean;
      allowPolls?: boolean;
      allowGroupCreation?: boolean;
      disappearingHours?: 0 | 24 | 168;
    }) => {
      const cleanPatch: Partial<RoomDoc> = {};
      if (typeof settings.roomTitle === 'string') {
        const nextTitle = settings.roomTitle.trim().slice(0, 40);
        if (nextTitle) cleanPatch.roomTitle = nextTitle;
      }
      if (typeof settings.slowModeSec === 'number') {
        cleanPatch.slowModeSec = Math.max(0, Math.min(60, settings.slowModeSec));
      }
      if (typeof settings.guestAllowed === 'boolean') {
        cleanPatch.guestAllowed = settings.guestAllowed;
      }
      if (typeof settings.announcement === 'string') {
        cleanPatch.announcement = settings.announcement.trim().slice(0, 280);
      }
      if (typeof settings.allowMedia === 'boolean') {
        cleanPatch.allowMedia = settings.allowMedia;
      }
      if (typeof settings.allowVoice === 'boolean') {
        cleanPatch.allowVoice = settings.allowVoice;
      }
      if (typeof settings.allowPolls === 'boolean') {
        cleanPatch.allowPolls = settings.allowPolls;
      }
      if (typeof settings.allowGroupCreation === 'boolean') {
        cleanPatch.allowGroupCreation = settings.allowGroupCreation;
      }
      if (
        settings.disappearingHours === 0 ||
        settings.disappearingHours === 24 ||
        settings.disappearingHours === 168
      ) {
        cleanPatch.disappearingHours = settings.disappearingHours;
      }
      void updateRoomDoc(cleanPatch);
    },
    [updateRoomDoc]
  );

  const clearRoomCalls = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const snap = await getDocs(
        collection(db, 'rooms', MAIN_ROOM_ID, 'callParticipants')
      );
      if (snap.empty) return;
      const batch = writeBatch(db);
      snap.forEach((docSnap) => batch.delete(docSnap.ref));
      await batch.commit();
    } catch {
      // Ignore cleanup errors
    }
  }, [isAdmin]);

  const blockUser = useCallback(
    async (
      targetNickname: string,
      targetClientId?: string,
      targetPhoneNumber?: string
    ): Promise<boolean> => {
      if (!isAdmin) return false;
      const cleanInput = targetNickname.trim();
      const cleanId = (targetClientId || '').trim();
      if (!cleanInput && !cleanId && !targetPhoneNumber) return false;

      const hostUsers = [
        ...onlineUsers,
        ...Object.values(profilesById || {}).map((p) => ({
          clientId: p.clientId,
          displayName: p.displayName,
          isAdmin: Boolean(p.isAdmin),
        })),
      ];

      if (
        isSelfOrHostTarget({
          targetClientId: cleanId,
          targetNickname: cleanInput,
          targetPhoneNumber,
          selfClientId: clientId,
          selfNickname: nickname,
          selfPhoneNumber: phoneNumber,
          hostUsers,
        })
      ) {
        showRoomError('Host cannot block themselves or another Host.');
        return false;
      }

      const explicitPhoneCheck = targetPhoneNumber
        ? validateBangladeshPhone(targetPhoneNumber)
        : validateBangladeshPhone(cleanInput);

      let resolvedPhone = explicitPhoneCheck.valid
        ? explicitPhoneCheck.normalized
        : '';
      let resolvedId = cleanId;
      let resolvedNick = cleanInput;

      if (!resolvedPhone && resolvedId) {
        const reg = registeredUsers.find((r) => r.clientId === resolvedId);
        if (reg?.phoneNumber) resolvedPhone = reg.phoneNumber;
      }

      if (resolvedPhone && (!resolvedId || explicitPhoneCheck.valid)) {
        const reg = registeredUsers.find(
          (r) => r.phoneNumber === resolvedPhone
        );
        if (reg) {
          if (!resolvedId) resolvedId = reg.clientId;
          if (!cleanInput || explicitPhoneCheck.valid) {
            resolvedNick = reg.nickname;
          }
        } else if (explicitPhoneCheck.valid && !targetPhoneNumber) {
          resolvedNick = explicitPhoneCheck.display;
        }
      }

      if (
        isSelfOrHostTarget({
          targetClientId: resolvedId,
          targetNickname: resolvedNick,
          targetPhoneNumber: resolvedPhone,
          selfClientId: clientId,
          selfNickname: nickname,
          selfPhoneNumber: phoneNumber,
          hostUsers,
        })
      ) {
        showRoomError('Host cannot block themselves or another Host.');
        return false;
      }

      const blockKey =
        resolvedId ||
        (resolvedPhone
          ? `phone-${resolvedPhone}`
          : `nick-${normalizeNicknameKey(resolvedNick).replace(/[^a-z0-9]/g, '_') || Date.now()}`);
      const blockPath = `rooms/${MAIN_ROOM_ID}/blockedUsers/${blockKey}`;
      const entry: BlockedUser = {
        clientId: resolvedId,
        nickname: resolvedNick || resolvedId || resolvedPhone,
        blockedAt: Date.now(),
      };
      if (resolvedPhone) {
        entry.phoneNumber = resolvedPhone;
      }

      try {
        await setDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'blockedUsers', blockKey),
          entry
        );
        if (resolvedId) {
          await deleteDoc(
            doc(db, 'rooms', MAIN_ROOM_ID, 'presence', resolvedId)
          ).catch(() => {});
        }
        return true;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, blockPath);
        return false;
      }
    },
    [
      clientId,
      isAdmin,
      nickname,
      onlineUsers,
      phoneNumber,
      profilesById,
      registeredUsers,
      showRoomError,
    ]
  );

  const unblockUser = useCallback(
    async (
      target:
        | string
        | { nickname?: string; clientId?: string; phoneNumber?: string }
    ) => {
      if (!isAdmin) return;
      const targetObj =
        typeof target === 'string'
          ? { nickname: target, clientId: target, phoneNumber: target }
          : target;
      const targetKey = targetObj.nickname
        ? normalizeNicknameKey(targetObj.nickname)
        : '';
      const targetPhoneCheck = targetObj.phoneNumber
        ? validateBangladeshPhone(targetObj.phoneNumber)
        : targetObj.nickname
          ? validateBangladeshPhone(targetObj.nickname)
          : null;
      const targetNormalizedPhone = targetPhoneCheck?.valid
        ? targetPhoneCheck.normalized
        : '';

      const blockedPath = `rooms/${MAIN_ROOM_ID}/blockedUsers`;
      try {
        const snap = await getDocs(
          collection(db, 'rooms', MAIN_ROOM_ID, 'blockedUsers')
        );
        const batch = writeBatch(db);
        snap.forEach((docSnap) => {
          const data = docSnap.data() as BlockedUser;
          const matchesId =
            Boolean(targetObj.clientId) &&
            (data.clientId === targetObj.clientId ||
              docSnap.id === targetObj.clientId);
          const matchesNick =
            Boolean(targetKey) &&
            normalizeNicknameKey(data.nickname) === targetKey;
          const entryPhone = data.phoneNumber
            ? validateBangladeshPhone(data.phoneNumber)
            : null;
          const matchesPhone =
            Boolean(targetNormalizedPhone) &&
            Boolean(entryPhone?.valid) &&
            entryPhone?.normalized === targetNormalizedPhone;

          if (matchesId || matchesNick || matchesPhone) {
            batch.delete(docSnap.ref);
          }
        });
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, blockedPath);
      }
    },
    [isAdmin]
  );

  const deleteContact = useCallback(
    async (target: {
      clientId: string;
      nickname?: string;
      phoneNumber?: string;
    }): Promise<boolean> => {
      if (!isAdmin || !target.clientId) return false;

      if (
        !canDeleteContact({
          targetClientId: target.clientId,
          selfClientId: clientId,
          isAdmin,
        })
      ) {
        showRoomError('Cannot delete your own active Host session.');
        return false;
      }

      const prof = profilesById?.[target.clientId];
      const reg = registeredUsers.find((r) => r.clientId === target.clientId);
      const online = onlineUsers.find((u) => u.clientId === target.clientId);
      const archiveEntry: DeletedContact = {
        clientId: target.clientId,
        nickname: (
          prof?.displayName ||
          target.nickname ||
          reg?.nickname ||
          online?.nickname ||
          'Member'
        ).slice(0, 40),
        ...(prof?.username ? { username: prof.username.slice(0, 24) } : {}),
        ...(reg?.phoneNumber || target.phoneNumber
          ? { phoneNumber: (reg?.phoneNumber || target.phoneNumber || '').slice(0, 20) }
          : {}),
        avatarColor: prof?.avatarColor || reg?.avatarColor || online?.avatarColor || '#7C3AED',
        ...(prof?.avatarUrl ? { avatarUrl: prof.avatarUrl } : {}),
        ...(prof?.bio ? { bio: prof.bio.slice(0, 180) } : {}),
        isGuest: Boolean(prof?.isGuest ?? reg?.isGuest ?? online?.isGuest),
        isAdmin: Boolean(prof?.isAdmin ?? online?.isAdmin),
        deletedAt: Date.now(),
        deletedBy: clientId,
      };

      const userPath = `users/${target.clientId}`;
      try {
        await setDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'deletedContacts', target.clientId),
          archiveEntry
        );
        await Promise.all([
          deleteDoc(doc(db, 'users', target.clientId)).catch((err) => {
            handleFirestoreError(err, OperationType.DELETE, userPath);
          }),
          deleteDoc(
            doc(db, 'rooms', MAIN_ROOM_ID, 'presence', target.clientId)
          ).catch(() => {}),
          deleteDoc(
            doc(db, 'rooms', MAIN_ROOM_ID, 'phoneRegistry', target.clientId)
          ).catch(() => {}),
        ]);
        return true;
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, userPath);
        return false;
      }
    },
    [
      clientId,
      isAdmin,
      onlineUsers,
      profilesById,
      registeredUsers,
      showRoomError,
    ]
  );

  const restoreDeletedContact = useCallback(
    async (entry: DeletedContact): Promise<boolean> => {
      if (!isAdmin || !entry.clientId) return false;
      const now = Date.now();
      const cleanName =
        entry.nickname.trim().length >= 2
          ? entry.nickname.trim().slice(0, 30)
          : 'Restored User';

      const restoredProfile: UserProfile = {
        uid: entry.clientId,
        clientId: entry.clientId,
        displayName: cleanName,
        username: (entry.username || '').slice(0, 24),
        bio: (entry.bio || '').slice(0, 180),
        ...(entry.avatarUrl ? { avatarUrl: entry.avatarUrl } : {}),
        avatarColor: entry.avatarColor || '#7C3AED',
        isGuest: Boolean(entry.isGuest),
        isAdmin: Boolean(entry.isAdmin),
        online: false,
        lastSeenAt: now,
        privacy: {
          lastSeen: 'everyone',
          profilePhoto: 'everyone',
          status: 'everyone',
        },
        updatedAt: now,
      };

      try {
        await setDoc(doc(db, 'users', entry.clientId), restoredProfile);
        if (entry.phoneNumber) {
          const phoneCheck = validateBangladeshPhone(entry.phoneNumber);
          if (phoneCheck.valid) {
            const regRecord: RegisteredUser = {
              clientId: entry.clientId,
              nickname: cleanName,
              phoneNumber: phoneCheck.normalized,
              avatarColor: entry.avatarColor || '#7C3AED',
              isGuest: Boolean(entry.isGuest),
              joinedAt: entry.deletedAt || now,
              lastSeenAt: now,
            };
            await setDoc(
              doc(db, 'rooms', MAIN_ROOM_ID, 'phoneRegistry', entry.clientId),
              regRecord
            );
          }
        }
        await deleteDoc(
          doc(db, 'rooms', MAIN_ROOM_ID, 'deletedContacts', entry.clientId)
        );
        return true;
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.CREATE,
          `users/${entry.clientId}`
        );
        return false;
      }
    },
    [isAdmin]
  );

  const deleteMessage = useCallback(
    async (messageId: string, overrideRoomId?: string) => {
      const targetRoom = overrideRoomId || activeRoomId;
      const target = messages.find((m) => m.id === messageId);
      if (
        !overrideRoomId &&
        (!target || !canDeleteForEveryone(target, clientId, isAdmin))
      ) {
        showRoomError('You can only delete your own messages for everyone.');
        return;
      }

      const msgPath = `rooms/${targetRoom}/messages/${messageId}`;
      try {
        await deleteDoc(doc(db, 'rooms', targetRoom, 'messages', messageId));
        if (
          targetRoom === MAIN_ROOM_ID &&
          pinnedMessage?.messageId === messageId &&
          isAdmin
        ) {
          await updateRoomDoc({ pinnedMessage: null });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, msgPath);
      }
    },
    [
      activeRoomId,
      clientId,
      isAdmin,
      messages,
      pinnedMessage,
      showRoomError,
      updateRoomDoc,
    ]
  );

  const pinMessage = useCallback(
    (messageId: string | null) => {
      if (!isAdmin || activeRoomId !== MAIN_ROOM_ID) return;
      if (!messageId) {
        void updateRoomDoc({ pinnedMessage: null });
        return;
      }
      const target = messages.find((m) => m.id === messageId);
      if (!target) return;
      const preview =
        target.text ||
        (target.poll ? `Poll: ${target.poll.question}` : '') ||
        (target.audioUrl || target.audioDataUrl ? 'Voice message' : '') ||
        (target.videoUrl ? 'Video' : '') ||
        (target.fileName ? target.fileName : '') ||
        (target.imageUrl || target.imageDataUrl ? 'Photo' : '');

      void updateRoomDoc({
        pinnedMessage: {
          messageId: target.id,
          senderName: target.senderName,
          previewText: preview.slice(0, 140),
          pinnedAt: Date.now(),
        },
      });
    },
    [activeRoomId, isAdmin, messages, updateRoomDoc]
  );

  const clearChat = useCallback(async () => {
    if (!isAdmin) return;
    const targetRoom = activeRoomId || MAIN_ROOM_ID;
    const messagesPath = `rooms/${targetRoom}/messages`;
    try {
      const snap = await getDocs(collection(db, 'rooms', targetRoom, 'messages'));
      const batch = writeBatch(db);
      snap.forEach((docSnap) => batch.delete(docSnap.ref));
      if (targetRoom === MAIN_ROOM_ID) {
        const clearedId = `sys-cleared-${Date.now()}`;
        const clearedMsg: ChatMessage = {
          id: clearedId,
          type: 'system',
          senderId: 'system',
          senderName: 'ARFANMesscent',
          senderColor: '#7C3AED',
          text: 'Chat history was cleared by Host.',
          reactions: {},
          createdAt: Date.now(),
        };
        batch.set(
          doc(db, 'rooms', MAIN_ROOM_ID, 'messages', clearedId),
          clearedMsg
        );
      }
      await batch.commit();
      if (targetRoom === MAIN_ROOM_ID) {
        await updateRoomDoc({ pinnedMessage: null });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, messagesPath);
    }
  }, [activeRoomId, isAdmin, updateRoomDoc]);

  const submitReport = useCallback(
    async (input: {
      targetId: string;
      targetName: string;
      targetType: 'user' | 'message';
      messageId?: string;
      messagePreview?: string;
      reason: string;
    }) => {
      if (!nickname || !clientId) return;
      const cleanReason = input.reason.trim().slice(0, 300);
      if (cleanReason.length < 2) return;

      const id = `rep-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const report: UserReport = {
        id,
        reporterId: clientId,
        reporterName: nickname,
        targetId: input.targetId,
        targetName: input.targetName,
        targetType: input.targetType,
        roomId: activeRoomId,
        ...(input.messageId ? { messageId: input.messageId } : {}),
        ...(input.messagePreview
          ? { messagePreview: input.messagePreview.slice(0, 200) }
          : {}),
        reason: cleanReason,
        status: 'open',
        createdAt: Date.now(),
      };

      try {
        await setDoc(doc(db, 'rooms', MAIN_ROOM_ID, 'reports', id), report);
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.CREATE,
          `rooms/${MAIN_ROOM_ID}/reports/${id}`
        );
      }
    },
    [activeRoomId, clientId, nickname]
  );

  const resolveReport = useCallback(
    async (reportId: string) => {
      if (!isAdmin) return;
      try {
        await updateDoc(doc(db, 'rooms', MAIN_ROOM_ID, 'reports', reportId), {
          status: 'resolved',
        });
      } catch (err) {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `rooms/${MAIN_ROOM_ID}/reports/${reportId}`
        );
      }
    },
    [isAdmin]
  );

  const dismissCallPing = useCallback(async (pingId: string) => {
    setIncomingCallPings((prev) => prev.filter((p) => p.id !== pingId));
    try {
      await deleteDoc(doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', pingId));
    } catch {
      // Ignore cleanup errors
    }
  }, []);

  const dismissMissedCall = useCallback(async (pingId: string) => {
    setMissedCallAlerts((prev) => prev.filter((p) => p.id !== pingId));
    try {
      await deleteDoc(doc(db, 'rooms', MAIN_ROOM_ID, 'directPings', pingId));
    } catch {
      // Ignore cleanup errors
    }
  }, []);

  const dismissDmAlert = useCallback(() => {
    setLatestDmAlert(null);
  }, []);

  return {
    connected,
    messages,
    hasMoreOlder,
    loadingOlder,
    loadOlderMessages,
    readReceipts,
    onlineUsers,
    registeredUsers,
    deletedContacts,
    reports,
    allDmThreads,
    scanningDmThreads,
    discoverAllDmThreads,
    customStickers,
    themeId,
    themeSpec,
    roomLocked,
    roomTitle,
    slowModeSec,
    guestAllowed,
    announcement,
    allowMedia,
    allowVoice,
    allowPolls,
    allowGroupCreation,
    disappearingHours,
    pinnedMessage,
    backgroundImageUrl,
    isAdmin,
    isBlocked,
    kickReason,
    blockedUsers,
    authError,
    roomError,
    typingUsers,
    unreadByPeerId,
    latestDmAlert,
    incomingCallPings,
    missedCallAlerts,
    sendMessage,
    editMessage,
    forwardMessage,
    uploadCustomSticker,
    reactToMessage,
    votePoll,
    sendTyping,
    loginAdmin,
    unlockSelfAsHost,
    logoutAdmin,
    setRoomTheme,
    setRoomBackgroundPreset,
    uploadRoomBackground,
    clearRoomBackground,
    blockUser,
    unblockUser,
    deleteContact,
    restoreDeletedContact,
    deleteMessage,
    pinMessage,
    clearChat,
    clearRoomCalls,
    submitReport,
    resolveReport,
    toggleLock,
    updateRoomSettings,
    dismissCallPing,
    dismissMissedCall,
    dismissDmAlert,
  };
}
