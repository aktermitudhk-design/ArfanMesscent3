import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { OperationType, db, handleFirestoreError } from '../firebase';
import {
  AVATAR_COLORS,
  canManageGroupMembers,
  canManageGroupSettings,
  getGroupRoomId,
} from '../shared/chatRules';
import type { ChatGroup } from '../shared/types';
import { uploadMediaFile } from '../utils/storageHelper';

interface UseGroupsOptions {
  clientId: string;
  nickname: string | null;
  isAdmin: boolean;
}

export function useGroups({ clientId, nickname, isAdmin }: UseGroupsOptions) {
  const [allGroups, setAllGroups] = useState<ChatGroup[]>([]);

  useEffect(() => {
    if (!nickname) return;
    const q = query(collection(db, 'groups'), orderBy('updatedAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: ChatGroup[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as ChatGroup);
        });
        setAllGroups(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'groups');
      }
    );
    return () => unsub();
  }, [nickname]);

  const myGroups = useMemo(
    () =>
      allGroups.filter(
        (g) =>
          g.memberIds.includes(clientId) ||
          g.adminIds.includes(clientId) ||
          g.createdBy === clientId
      ),
    [allGroups, clientId]
  );

  const createGroup = useCallback(
    async (input: {
      name: string;
      description?: string;
      memberIds: string[];
      avatarFile?: File | null;
    }): Promise<ChatGroup | null> => {
      if (!clientId || !nickname) return null;
      const cleanName = input.name.trim().slice(0, 50);
      if (cleanName.length < 2) return null;

      const now = Date.now();
      const id = getGroupRoomId(
        `${now.toString(36)}-${Math.random().toString(36).slice(2, 6)}`
      );

      let avatarUrl: string | null = null;
      if (input.avatarFile) {
        const uploaded = await uploadMediaFile(
          input.avatarFile,
          'groups',
          id,
          input.avatarFile.name
        );
        avatarUrl = uploaded.url;
      }

      const uniqueMembers = Array.from(
        new Set([clientId, ...input.memberIds.filter(Boolean)])
      );
      const group: ChatGroup = {
        id,
        name: cleanName,
        description: (input.description || '').trim().slice(0, 240),
        avatarUrl,
        avatarColor:
          AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
        createdBy: clientId,
        adminIds: [clientId],
        memberIds: uniqueMembers,
        mutedBy: [],
        pinnedMessage: null,
        createdAt: now,
        updatedAt: now,
      };

      try {
        await setDoc(doc(db, 'groups', id), group);
        return group;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `groups/${id}`);
      }
    },
    [clientId, nickname]
  );

  const updateGroupDetails = useCallback(
    async (
      group: ChatGroup,
      patch: {
        name?: string;
        description?: string;
        avatarFile?: File | null;
      }
    ) => {
      if (!canManageGroupSettings(group, clientId, isAdmin)) return;
      let nextAvatarUrl = group.avatarUrl ?? null;
      if (patch.avatarFile) {
        const uploaded = await uploadMediaFile(
          patch.avatarFile,
          'groups',
          group.id,
          patch.avatarFile.name
        );
        nextAvatarUrl = uploaded.url;
      }

      const nextName = patch.name
        ? patch.name.trim().slice(0, 50)
        : group.name;
      if (nextName.length < 2) return;

      try {
        await updateDoc(doc(db, 'groups', group.id), {
          name: nextName,
          description:
            patch.description !== undefined
              ? patch.description.trim().slice(0, 240)
              : group.description,
          avatarUrl: nextAvatarUrl,
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `groups/${group.id}`);
      }
    },
    [clientId, isAdmin]
  );

  const addMemberToGroup = useCallback(
    async (group: ChatGroup, memberId: string) => {
      if (!canManageGroupMembers(group, clientId, isAdmin)) return;
      if (group.memberIds.includes(memberId)) return;
      try {
        await updateDoc(doc(db, 'groups', group.id), {
          memberIds: [...group.memberIds, memberId],
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `groups/${group.id}`);
      }
    },
    [clientId, isAdmin]
  );

  const removeMemberFromGroup = useCallback(
    async (group: ChatGroup, memberId: string) => {
      const removingSelf = memberId === clientId;
      if (!removingSelf && !canManageGroupMembers(group, clientId, isAdmin)) return;
      if (memberId === group.createdBy && !isAdmin) return;
      const nextMembers = group.memberIds.filter((id) => id !== memberId);
      const nextAdmins = group.adminIds.filter((id) => id !== memberId);
      try {
        await updateDoc(doc(db, 'groups', group.id), {
          memberIds: nextMembers.length > 0 ? nextMembers : [group.createdBy],
          adminIds: nextAdmins.length > 0 ? nextAdmins : [group.createdBy],
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `groups/${group.id}`);
      }
    },
    [clientId, isAdmin]
  );

  const toggleGroupAdminRole = useCallback(
    async (group: ChatGroup, memberId: string) => {
      if (!canManageGroupMembers(group, clientId, isAdmin)) return;
      if (memberId === group.createdBy) return;
      const isAlreadyAdmin = group.adminIds.includes(memberId);
      const nextAdmins = isAlreadyAdmin
        ? group.adminIds.filter((id) => id !== memberId)
        : [...group.adminIds, memberId];
      try {
        await updateDoc(doc(db, 'groups', group.id), {
          adminIds: nextAdmins,
          updatedAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `groups/${group.id}`);
      }
    },
    [clientId, isAdmin]
  );

  const deleteGroup = useCallback(
    async (group: ChatGroup) => {
      if (!canManageGroupSettings(group, clientId, isAdmin)) return;
      try {
        await deleteDoc(doc(db, 'groups', group.id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `groups/${group.id}`);
      }
    },
    [clientId, isAdmin]
  );

  return {
    allGroups,
    myGroups,
    createGroup,
    updateGroupDetails,
    addMemberToGroup,
    removeMemberFromGroup,
    toggleGroupAdminRole,
    deleteGroup,
  };
}
