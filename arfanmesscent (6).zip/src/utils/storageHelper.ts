import {
  deleteObject,
  getDownloadURL,
  ref,
  uploadBytesResumable,
} from 'firebase/storage';
import { MAIN_ROOM_ID, storage } from '../firebase';
import { compressImageFile } from './imageHelper';

export interface MediaUploadResult {
  url: string;
  usedFallback: boolean;
  size: number;
  mime: string;
}

const MAX_RAW_BACKGROUND_BYTES = 10 * 1024 * 1024; // 10 MB
const MAX_MEDIA_UPLOAD_BYTES = 24 * 1024 * 1024; // 24 MB
let storageBucketUnavailable = false;

function sanitizeExtension(filename: string, mime: string): string {
  const fromName = filename
    .split('.')
    .pop()
    ?.replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase();
  if (fromName && fromName.length <= 6) return fromName;
  if (mime.includes('png')) return 'png';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('gif')) return 'gif';
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('ogg')) return 'ogg';
  if (mime.includes('mpeg')) return 'mp3';
  if (mime.includes('pdf')) return 'pdf';
  return 'bin';
}

async function uploadViaFirebaseStorage(
  blob: Blob,
  objectPath: string,
  contentType: string,
  onProgress?: (percent: number) => void
): Promise<string> {
  if (storageBucketUnavailable) {
    throw new Error('Firebase Storage unavailable.');
  }
  const storageRef = ref(storage, objectPath);
  return await new Promise<string>((resolve, reject) => {
    const task = uploadBytesResumable(storageRef, blob, { contentType });

    const timeoutId = window.setTimeout(() => {
      storageBucketUnavailable = true;
      task.cancel();
      reject(new Error('Firebase Storage upload timed out.'));
    }, 3500);

    task.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0) {
          const pct = Math.round(
            (snapshot.bytesTransferred / snapshot.totalBytes) * 90
          );
          onProgress?.(Math.max(15, pct));
        }
      },
      (err) => {
        window.clearTimeout(timeoutId);
        storageBucketUnavailable = true;
        reject(err);
      },
      async () => {
        window.clearTimeout(timeoutId);
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          onProgress?.(100);
          resolve(url);
        } catch (urlErr) {
          reject(urlErr);
        }
      }
    );
  });
}

async function uploadViaServerEndpoint(
  blob: Blob,
  filename: string,
  mime: string,
  onProgress?: (percent: number) => void
): Promise<string> {
  onProgress?.(45);
  const res = await fetch('/api/media/upload', {
    method: 'POST',
    headers: {
      'Content-Type': mime || 'application/octet-stream',
      'X-File-Name': encodeURIComponent(filename),
    },
    body: blob,
  });
  if (!res.ok) {
    throw new Error('Server media upload failed.');
  }
  const data = (await res.json()) as { url?: string };
  if (!data.url) {
    throw new Error('Server returned no media URL.');
  }
  onProgress?.(100);
  return data.url;
}

export async function uploadMediaFile(
  fileOrBlob: File | Blob,
  folder:
    | 'chat-images'
    | 'chat-videos'
    | 'chat-audio'
    | 'chat-files'
    | 'avatars'
    | 'stories'
    | 'stickers'
    | 'groups'
    | 'wallpapers',
  ownerId: string,
  filenameArg?: string,
  onProgress?: (percent: number) => void
): Promise<MediaUploadResult> {
  const filename =
    filenameArg ||
    (fileOrBlob instanceof File ? fileOrBlob.name : `upload-${Date.now()}`);
  const mime = fileOrBlob.type || 'application/octet-stream';

  if (fileOrBlob.size > MAX_MEDIA_UPLOAD_BYTES) {
    throw new Error('File must be 24 MB or smaller.');
  }

  onProgress?.(10);
  const ext = sanitizeExtension(filename, mime);
  const cleanOwner = ownerId.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 48) || 'anon';
  const objectPath = `media/${folder}/${cleanOwner}/${Date.now()}-${Math.random()
    .toString(36)
    .slice(2, 7)}.${ext}`;

  try {
    const url = await uploadViaFirebaseStorage(
      fileOrBlob,
      objectPath,
      mime,
      onProgress
    );
    return { url, usedFallback: false, size: fileOrBlob.size, mime };
  } catch {
    try {
      const url = await uploadViaServerEndpoint(
        fileOrBlob,
        filename,
        mime,
        onProgress
      );
      return { url, usedFallback: true, size: fileOrBlob.size, mime };
    } catch {
      // Static single-file HTML mode without server: allow only small images/audio (<400KB) as compressed fallback
      if (fileOrBlob instanceof File && mime.startsWith('image/')) {
        const compressed = await compressImageFile(fileOrBlob, 900, 0.72);
        if (compressed.length <= 550_000) {
          onProgress?.(100);
          return { url: compressed, usedFallback: true, size: fileOrBlob.size, mime };
        }
      }
      throw new Error(
        'Enable Firebase Storage in Firebase Console to upload large videos, audio, and files.'
      );
    }
  }
}

export async function uploadRoomBackground(
  file: File,
  previousUrl?: string | null,
  onProgress?: (percent: number) => void
): Promise<{ url: string; usedFallback: boolean }> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a valid image file (PNG, JPG, WebP, or GIF).');
  }
  if (file.size > MAX_RAW_BACKGROUND_BYTES) {
    throw new Error('Background image must be 10 MB or smaller.');
  }

  onProgress?.(10);

  const safeExt = sanitizeExtension(file.name, file.type);
  const objectPath = `rooms/${MAIN_ROOM_ID}/backgrounds/bg-${Date.now()}.${safeExt}`;

  try {
    const downloadUrl = await uploadViaFirebaseStorage(
      file,
      objectPath,
      file.type,
      onProgress
    );
    if (previousUrl) {
      await deleteRoomBackgroundObject(previousUrl);
    }
    return { url: downloadUrl, usedFallback: false };
  } catch {
    try {
      const url = await uploadViaServerEndpoint(file, file.name, file.type, onProgress);
      return { url, usedFallback: true };
    } catch {
      const compressed = await compressImageFile(file, 1400, 0.78);
      if (compressed.length > 740_000) {
        const tighter = await compressImageFile(file, 1000, 0.65);
        if (tighter.length > 740_000) {
          throw new Error(
            'Image is too large after compression. Please pick a smaller image.'
          );
        }
        onProgress?.(100);
        return { url: tighter, usedFallback: true };
      }
      onProgress?.(100);
      return { url: compressed, usedFallback: true };
    }
  }
}

export async function deleteRoomBackgroundObject(
  url?: string | null
): Promise<void> {
  if (!url || !url.includes('firebasestorage.googleapis.com')) {
    return;
  }
  try {
    const oldRef = ref(storage, url);
    await deleteObject(oldRef);
  } catch {
    // Ignore cleanup failures
  }
}
