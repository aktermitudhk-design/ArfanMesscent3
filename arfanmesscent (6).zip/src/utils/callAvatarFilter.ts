import type { CallAvatarId } from '../shared/types';

interface FaceBox {
  cx: number;
  cy: number;
  w: number;
  h: number;
}

interface NativeFaceDetector {
  detect: (
    image: CanvasImageSource
  ) => Promise<Array<{ boundingBox: DOMRectReadOnly }>>;
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  color: string
) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  for (let i = 0; i < 8; i += 1) {
    const angle = (i * Math.PI) / 4;
    const rad = i % 2 === 0 ? r : r * 0.36;
    const x = cx + Math.cos(angle) * rad;
    const y = cy + Math.sin(angle) * rad;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawHeart(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  size: number,
  color: string
) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(cx, cy + size * 0.35);
  ctx.bezierCurveTo(
    cx - size * 0.7,
    cy - size * 0.2,
    cx - size * 0.35,
    cy - size * 0.75,
    cx,
    cy - size * 0.25
  );
  ctx.bezierCurveTo(
    cx + size * 0.35,
    cy - size * 0.75,
    cx + size * 0.7,
    cy - size * 0.2,
    cx,
    cy + size * 0.35
  );
  ctx.fill();
  ctx.restore();
}

export function drawAvatarOverlay(
  ctx: CanvasRenderingContext2D,
  avatarId: CallAvatarId,
  box: FaceBox
) {
  if (avatarId === 'none') return;
  const { cx, cy, w, h } = box;
  const eyeY = cy - h * 0.08;
  const eyeOffset = w * 0.2;

  ctx.save();

  switch (avatarId) {
    case 'shades': {
      ctx.fillStyle = '#09090B';
      ctx.strokeStyle = '#E4E4E7';
      ctx.lineWidth = Math.max(2, w * 0.018);
      const lensW = w * 0.29;
      const lensH = h * 0.16;
      // Left lens
      ctx.beginPath();
      ctx.roundRect(cx - eyeOffset - lensW * 0.5, eyeY - lensH * 0.5, lensW, lensH, 10);
      ctx.fill();
      ctx.stroke();
      // Right lens
      ctx.beginPath();
      ctx.roundRect(cx + eyeOffset - lensW * 0.5, eyeY - lensH * 0.5, lensW, lensH, 10);
      ctx.fill();
      ctx.stroke();
      // Bridge
      ctx.beginPath();
      ctx.moveTo(cx - eyeOffset + lensW * 0.5, eyeY - lensH * 0.15);
      ctx.lineTo(cx + eyeOffset - lensW * 0.5, eyeY - lensH * 0.15);
      ctx.stroke();
      // Glossy reflection stripes
      ctx.strokeStyle = 'rgba(255,255,255,0.45)';
      ctx.lineWidth = Math.max(2, w * 0.015);
      ctx.beginPath();
      ctx.moveTo(cx - eyeOffset - lensW * 0.22, eyeY - lensH * 0.25);
      ctx.lineTo(cx - eyeOffset - lensW * 0.02, eyeY + lensH * 0.25);
      ctx.moveTo(cx + eyeOffset - lensW * 0.22, eyeY - lensH * 0.25);
      ctx.lineTo(cx + eyeOffset - lensW * 0.02, eyeY + lensH * 0.25);
      ctx.stroke();
      break;
    }

    case 'visor': {
      const grad = ctx.createLinearGradient(cx - w * 0.44, eyeY, cx + w * 0.44, eyeY);
      grad.addColorStop(0, 'rgba(6, 182, 212, 0.86)');
      grad.addColorStop(0.5, 'rgba(139, 92, 246, 0.88)');
      grad.addColorStop(1, 'rgba(236, 72, 153, 0.86)');
      ctx.fillStyle = grad;
      ctx.strokeStyle = '#67E8F9';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(cx - w * 0.44, eyeY - h * 0.1, w * 0.88, h * 0.19, 16);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.65)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - w * 0.34, eyeY - h * 0.03);
      ctx.lineTo(cx + w * 0.34, eyeY - h * 0.03);
      ctx.stroke();
      break;
    }

    case 'cat': {
      const earTop = cy - h * 0.62;
      const earBase = cy - h * 0.33;
      // Left & Right outer ears
      for (const dir of [-1, 1]) {
        ctx.fillStyle = '#1F2937';
        ctx.beginPath();
        ctx.moveTo(cx + dir * w * 0.15, earBase);
        ctx.lineTo(cx + dir * w * 0.38, earTop);
        ctx.lineTo(cx + dir * w * 0.44, earBase + h * 0.05);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#F472B6';
        ctx.beginPath();
        ctx.moveTo(cx + dir * w * 0.2, earBase);
        ctx.lineTo(cx + dir * w * 0.36, earTop + h * 0.08);
        ctx.lineTo(cx + dir * w * 0.4, earBase + h * 0.03);
        ctx.closePath();
        ctx.fill();
      }
      // Cute pink nose & whiskers
      ctx.fillStyle = '#F472B6';
      ctx.beginPath();
      ctx.arc(cx, cy + h * 0.06, w * 0.045, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.8)';
      ctx.lineWidth = 2;
      for (const dir of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(cx + dir * w * 0.14, cy + h * 0.06);
        ctx.lineTo(cx + dir * w * 0.42, cy + h * 0.02);
        ctx.moveTo(cx + dir * w * 0.14, cy + h * 0.1);
        ctx.lineTo(cx + dir * w * 0.42, cy + h * 0.12);
        ctx.stroke();
      }
      break;
    }

    case 'crown': {
      const crownBottom = cy - h * 0.38;
      const crownTop = cy - h * 0.68;
      const hw = w * 0.36;
      const grad = ctx.createLinearGradient(cx - hw, crownTop, cx + hw, crownBottom);
      grad.addColorStop(0, '#FDE047');
      grad.addColorStop(1, '#D97706');
      ctx.fillStyle = grad;
      ctx.strokeStyle = '#FEF9C3';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(cx - hw, crownBottom);
      ctx.lineTo(cx - hw * 1.08, crownTop + h * 0.06);
      ctx.lineTo(cx - hw * 0.48, crownBottom - h * 0.12);
      ctx.lineTo(cx, crownTop);
      ctx.lineTo(cx + hw * 0.48, crownBottom - h * 0.12);
      ctx.lineTo(cx + hw * 1.08, crownTop + h * 0.06);
      ctx.lineTo(cx + hw, crownBottom);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // Jewels
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(cx, crownBottom - h * 0.09, w * 0.04, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'robot': {
      ctx.fillStyle = 'rgba(30, 41, 59, 0.9)';
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(cx - w * 0.45, cy - h * 0.44, w * 0.9, h * 0.88, 28);
      ctx.fill();
      ctx.stroke();
      // Glowing cyan eyes
      ctx.fillStyle = '#22D3EE';
      ctx.beginPath();
      ctx.arc(cx - eyeOffset, eyeY, w * 0.09, 0, Math.PI * 2);
      ctx.arc(cx + eyeOffset, eyeY, w * 0.09, 0, Math.PI * 2);
      ctx.fill();
      // Digital mouth bar
      ctx.fillStyle = '#38BDF8';
      ctx.beginPath();
      ctx.roundRect(cx - w * 0.22, cy + h * 0.18, w * 0.44, h * 0.08, 6);
      ctx.fill();
      // Antenna
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx, cy - h * 0.44);
      ctx.lineTo(cx, cy - h * 0.62);
      ctx.stroke();
      ctx.fillStyle = '#F43F5E';
      ctx.beginPath();
      ctx.arc(cx, cy - h * 0.64, w * 0.045, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'panda': {
      // Dark round ears
      ctx.fillStyle = '#111827';
      ctx.beginPath();
      ctx.arc(cx - w * 0.36, cy - h * 0.42, w * 0.16, 0, Math.PI * 2);
      ctx.arc(cx + w * 0.36, cy - h * 0.42, w * 0.16, 0, Math.PI * 2);
      ctx.fill();
      // Eye patches
      ctx.fillStyle = 'rgba(17, 24, 39, 0.88)';
      ctx.beginPath();
      ctx.ellipse(cx - eyeOffset, eyeY, w * 0.14, h * 0.11, -0.2, 0, Math.PI * 2);
      ctx.ellipse(cx + eyeOffset, eyeY, w * 0.14, h * 0.11, 0.2, 0, Math.PI * 2);
      ctx.fill();
      // Glossy inner eyes
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(cx - eyeOffset, eyeY, w * 0.045, 0, Math.PI * 2);
      ctx.arc(cx + eyeOffset, eyeY, w * 0.045, 0, Math.PI * 2);
      ctx.fill();
      // Panda nose
      ctx.fillStyle = '#111827';
      ctx.beginPath();
      ctx.ellipse(cx, cy + h * 0.08, w * 0.07, h * 0.045, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'heart': {
      drawHeart(ctx, cx - eyeOffset, eyeY, w * 0.24, '#FB7185');
      drawHeart(ctx, cx + eyeOffset, eyeY, w * 0.24, '#FB7185');
      ctx.fillStyle = 'rgba(244, 114, 182, 0.35)';
      ctx.beginPath();
      ctx.ellipse(cx - w * 0.28, cy + h * 0.08, w * 0.09, h * 0.045, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + w * 0.28, cy + h * 0.08, w * 0.09, h * 0.045, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'cyber': {
      // Glowing halo ring above head
      ctx.strokeStyle = '#C084FC';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(cx, cy - h * 0.56, w * 0.34, h * 0.08, 0, 0, Math.PI * 2);
      ctx.stroke();
      drawStar(ctx, cx - w * 0.38, cy - h * 0.05, w * 0.08, '#FDE047');
      drawStar(ctx, cx + w * 0.38, cy - h * 0.05, w * 0.08, '#38BDF8');
      drawStar(ctx, cx - w * 0.26, cy + h * 0.22, w * 0.055, '#F472B6');
      drawStar(ctx, cx + w * 0.26, cy + h * 0.22, w * 0.055, '#F472B6');
      break;
    }

    case 'privacy': {
      // Full stylized friendly purple avatar mask for privacy
      const maskGrad = ctx.createRadialGradient(
        cx - w * 0.15,
        cy - h * 0.15,
        w * 0.08,
        cx,
        cy,
        w * 0.55
      );
      maskGrad.addColorStop(0, '#A855F7');
      maskGrad.addColorStop(1, '#4C1D95');
      ctx.fillStyle = maskGrad;
      ctx.strokeStyle = '#DDD6FE';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(cx, cy, w * 0.48, h * 0.52, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      // Happy stylized eyes & smile
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(cx - eyeOffset, eyeY, w * 0.08, 0, Math.PI * 2);
      ctx.arc(cx + eyeOffset, eyeY, w * 0.08, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.arc(cx - eyeOffset, eyeY, w * 0.038, 0, Math.PI * 2);
      ctx.arc(cx + eyeOffset, eyeY, w * 0.038, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(cx, cy + h * 0.09, w * 0.18, 0.2, Math.PI - 0.2);
      ctx.stroke();
      break;
    }
  }

  ctx.restore();
}

export interface AvatarVideoProcessor {
  videoTrack: MediaStreamTrack;
  setAvatarId: (next: CallAvatarId) => void;
  stop: () => void;
}

export function createAvatarVideoProcessor(
  rawVideoTrack: MediaStreamTrack,
  initialAvatarId: CallAvatarId
): AvatarVideoProcessor | null {
  if (typeof document === 'undefined' || !rawVideoTrack) return null;

  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d');
  if (!ctx || typeof canvas.captureStream !== 'function') return null;

  const video = document.createElement('video');
  video.muted = true;
  video.playsInline = true;
  video.autoplay = true;
  video.srcObject = new MediaStream([rawVideoTrack]);
  void video.play().catch(() => {});

  let currentAvatar: CallAvatarId = initialAvatarId;
  let stopped = false;

  let smoothedBox: FaceBox = {
    cx: canvas.width * 0.5,
    cy: canvas.height * 0.44,
    w: canvas.width * 0.34,
    h: canvas.height * 0.46,
  };
  let targetBox: FaceBox = { ...smoothedBox };

  const FaceDetectorCtor = (
    window as unknown as {
      FaceDetector?: new (opts?: { fastMode?: boolean; maxDetectedFaces?: number }) => NativeFaceDetector;
    }
  ).FaceDetector;
  const detector = FaceDetectorCtor
    ? new FaceDetectorCtor({ fastMode: true, maxDetectedFaces: 1 })
    : null;
  let lastDetectAt = 0;
  let detecting = false;

  const tick = () => {
    if (stopped) return;
    const cw = canvas.width;
    const ch = canvas.height;

    if (video.readyState >= 2) {
      const vw = video.videoWidth || cw;
      const vh = video.videoHeight || ch;
      // Cover-crop onto 640x480
      const scale = Math.max(cw / vw, ch / vh);
      const dw = vw * scale;
      const dh = vh * scale;
      const dx = (cw - dw) / 2;
      const dy = (ch - dh) / 2;
      ctx.drawImage(video, dx, dy, dw, dh);

      const now = performance.now();
      if (detector && !detecting && now - lastDetectAt > 120) {
        detecting = true;
        lastDetectAt = now;
        void detector
          .detect(canvas)
          .then((faces) => {
            if (faces.length > 0) {
              const bb = faces[0].boundingBox;
              if (bb.width > 30 && bb.height > 30) {
                targetBox = {
                  cx: bb.x + bb.width / 2,
                  cy: bb.y + bb.height / 2,
                  w: bb.width,
                  h: bb.height,
                };
              }
            }
          })
          .catch(() => {})
          .finally(() => {
            detecting = false;
          });
      }
    } else {
      ctx.fillStyle = '#0B0A10';
      ctx.fillRect(0, 0, cw, ch);
    }

    // Smooth lerp face anchor
    smoothedBox = {
      cx: smoothedBox.cx + (targetBox.cx - smoothedBox.cx) * 0.25,
      cy: smoothedBox.cy + (targetBox.cy - smoothedBox.cy) * 0.25,
      w: smoothedBox.w + (targetBox.w - smoothedBox.w) * 0.25,
      h: smoothedBox.h + (targetBox.h - smoothedBox.h) * 0.25,
    };

    drawAvatarOverlay(ctx, currentAvatar, smoothedBox);
  };

  const intervalId = window.setInterval(tick, 42);
  const captured = canvas.captureStream(24);
  const processedTrack = captured.getVideoTracks()[0];
  if (!processedTrack) {
    window.clearInterval(intervalId);
    return null;
  }

  return {
    videoTrack: processedTrack,
    setAvatarId: (next: CallAvatarId) => {
      currentAvatar = next;
    },
    stop: () => {
      if (stopped) return;
      stopped = true;
      window.clearInterval(intervalId);
      try {
        processedTrack.stop();
      } catch {
        // ignore
      }
      video.pause();
      video.srcObject = null;
    },
  };
}
