export async function downloadVerifiedFile(
  url: string,
  filename: string,
  expectedType: 'zip' | 'html'
): Promise<void> {
  const res = await fetch(url, {
    method: 'GET',
    cache: 'no-store',
  });

  if (!res.ok) {
    throw new Error(`Download failed (HTTP ${res.status}).`);
  }

  const buffer = await res.arrayBuffer();
  const bytes = new Uint8Array(buffer);

  if (expectedType === 'zip') {
    const hasPkHeader = bytes.length >= 22 && bytes[0] === 0x50 && bytes[1] === 0x4b;
    if (!hasPkHeader) {
      throw new Error(
        'Server returned an invalid ZIP archive (try re-publishing the live app or downloading index.html).'
      );
    }
  } else if (expectedType === 'html') {
    const head = new TextDecoder().decode(bytes.slice(0, 64)).trim().toLowerCase();
    if (!head.startsWith('<!doctype') && !head.startsWith('<html')) {
      throw new Error('Invalid HTML bundle returned by server.');
    }
  }

  const blob = new Blob([buffer], {
    type:
      expectedType === 'zip'
        ? 'application/zip'
        : 'text/html; charset=utf-8',
  });
  const blobUrl = URL.createObjectURL(blob);
  try {
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } finally {
    window.setTimeout(() => URL.revokeObjectURL(blobUrl), 2500);
  }
}
