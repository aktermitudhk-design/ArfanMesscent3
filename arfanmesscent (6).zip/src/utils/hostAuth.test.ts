import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isStaticHostToken,
  issueStaticHostToken,
  verifyStaticHostPassword,
  verifyStaticHostToken,
} from './hostAuth';

test('verifyStaticHostPassword accepts valid host password and rejects wrong passwords', async () => {
  const expected = ['arfan', '9899'].join('');
  assert.equal(await verifyStaticHostPassword(expected), true);
  assert.equal(await verifyStaticHostPassword(`  ${expected}  `), true);
  assert.equal(await verifyStaticHostPassword('wrongpass'), false);
  assert.equal(await verifyStaticHostPassword(''), false);
});

test('issueStaticHostToken and verifyStaticHostToken issue and validate tokens', () => {
  const token = issueStaticHostToken();
  assert.equal(isStaticHostToken(token), true);
  assert.equal(verifyStaticHostToken(token), true);
  assert.equal(verifyStaticHostToken('static-host.9999999999999.bad.tamper'), false);
  assert.equal(verifyStaticHostToken('static-host.1000.abc.def'), false);
  assert.equal(isStaticHostToken('regular-backend-token'), false);
});
