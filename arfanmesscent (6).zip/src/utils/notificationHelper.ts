const shownNotificationTags = new Set<string>();

export function isBrowserNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getBrowserNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!isBrowserNotificationSupported()) return 'unsupported';
  return Notification.permission;
}

export async function requestBrowserNotificationPermission(): Promise<
  NotificationPermission | 'unsupported'
> {
  if (!isBrowserNotificationSupported()) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission === 'denied') return 'denied';
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

export function showChatBrowserNotification(params: {
  title: string;
  body: string;
  tag: string;
  onClick?: () => void;
}) {
  const { title, body, tag, onClick } = params;
  if (!isBrowserNotificationSupported()) return;
  if (Notification.permission !== 'granted') return;
  if (shownNotificationTags.has(tag)) return;

  shownNotificationTags.add(tag);
  if (shownNotificationTags.size > 300) {
    const first = shownNotificationTags.values().next().value;
    if (first) shownNotificationTags.delete(first);
  }

  try {
    const notification = new Notification(title, {
      body: body.slice(0, 140),
      tag,
      silent: true,
    });
    notification.onclick = () => {
      window.focus();
      onClick?.();
      notification.close();
    };
  } catch {
    // Ignore Environments where Notification constructor throws (e.g. certain Android webviews)
  }
}
