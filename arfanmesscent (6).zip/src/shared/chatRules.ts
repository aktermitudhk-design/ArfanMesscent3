import type {
  BlockedUser,
  CallAvatarId,
  ChatGroup,
  ChatMessage,
  ChatPoll,
  PrivacyAudience,
  ReadReceipt,
  StoryStatus,
  ThemeId,
  ThemeSpec,
  WallpaperPreset,
} from './types';

export const AVATAR_COLORS = [
  '#7C3AED', // Royal Violet
  '#9333EA', // Deep Purple
  '#6366F1', // Indigo
  '#EC4899', // Rose Pink
  '#0EA5E9', // Sky Blue
  '#10B981', // Emerald
  '#F59E0B', // Amber
  '#EF4444', // Crimson
] as const;

export const QUICK_REACTIONS = ['❤️', '😂', '👍', '🔥', '😮', '👏'] as const;

export const STORY_BG_COLORS = [
  '#6D28D9',
  '#059669',
  '#2563EB',
  '#DB2777',
  '#D97706',
  '#111827',
] as const;

export const BUILTIN_STICKERS = [
  { id: 'stk-wave', label: 'Hey!', bg: '#7C3AED', emoji: '👋', accent: '#DDD6FE' },
  { id: 'stk-love', label: 'Love It', bg: '#DB2777', emoji: '💖', accent: '#FBCFE8' },
  { id: 'stk-fire', label: 'On Fire', bg: '#EA580C', emoji: '🔥', accent: '#FED7AA' },
  { id: 'stk-lol', label: 'Haha!', bg: '#CA8A04', emoji: '😂', accent: '#FEF08A' },
  { id: 'stk-cool', label: 'Legend', bg: '#0284C7', emoji: '😎', accent: '#BAE6FD' },
  { id: 'stk-party', label: 'Party!', bg: '#059669', emoji: '🎉', accent: '#A7F3D0' },
  { id: 'stk-ok', label: 'Gotcha', bg: '#4F46E5', emoji: '👌', accent: '#C7D2FE' },
  { id: 'stk-sad', label: 'Oops', bg: '#475569', emoji: '🥺', accent: '#CBD5E1' },
] as const;

export const THEME_SPECS: Record<ThemeId, ThemeSpec> = {
  'midnight-violet': {
    id: 'midnight-violet',
    name: 'Midnight Violet',
    nameBn: 'মিডনাইট ভায়োলেট',
    isDark: true,
    canvasBg: '#0B0A10',
    sidebarBg: '#110F1A',
    surfaceBg: '#171423',
    surfaceHoverBg: '#201C30',
    borderColor: 'rgba(167, 139, 250, 0.14)',
    textPrimary: '#F5F3FF',
    textSecondary: '#C4B5FD',
    textMuted: '#8B84A3',
    accentBg: '#7C3AED',
    accentHoverBg: '#6D28D9',
    accentSoftBg: 'rgba(124, 58, 237, 0.16)',
    accentText: '#C4B5FD',
    accentBorder: 'rgba(139, 92, 246, 0.35)',
    ownBubbleBg: '#6D28D9',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#1B1829',
    otherBubbleText: '#F3F1FC',
    swatchPrimary: '#0B0A10',
    swatchSecondary: '#7C3AED',
  },
  'obsidian-plum': {
    id: 'obsidian-plum',
    name: 'Obsidian Plum',
    nameBn: 'অবসিডিয়ান প্লাম',
    isDark: true,
    canvasBg: '#100A14',
    sidebarBg: '#170F1E',
    surfaceBg: '#1F1528',
    surfaceHoverBg: '#2A1D36',
    borderColor: 'rgba(216, 180, 254, 0.14)',
    textPrimary: '#FAF5FF',
    textSecondary: '#E9D5FF',
    textMuted: '#9E89B0',
    accentBg: '#A855F7',
    accentHoverBg: '#9333EA',
    accentSoftBg: 'rgba(168, 85, 247, 0.16)',
    accentText: '#E9D5FF',
    accentBorder: 'rgba(168, 85, 247, 0.36)',
    ownBubbleBg: '#9333EA',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#23172E',
    otherBubbleText: '#F8F2FF',
    swatchPrimary: '#100A14',
    swatchSecondary: '#A855F7',
  },
  'aurora-indigo': {
    id: 'aurora-indigo',
    name: 'Aurora Indigo',
    nameBn: 'অরোরা ইন্ডিগো',
    isDark: true,
    canvasBg: '#090D16',
    sidebarBg: '#0F1524',
    surfaceBg: '#151D30',
    surfaceHoverBg: '#1E2842',
    borderColor: 'rgba(129, 140, 248, 0.16)',
    textPrimary: '#F1F5F9',
    textSecondary: '#C7D2FE',
    textMuted: '#8896B3',
    accentBg: '#4F46E5',
    accentHoverBg: '#4338CA',
    accentSoftBg: 'rgba(79, 70, 229, 0.18)',
    accentText: '#A5B4FC',
    accentBorder: 'rgba(99, 102, 241, 0.35)',
    ownBubbleBg: '#4F46E5',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#182136',
    otherBubbleText: '#F1F5F9',
    swatchPrimary: '#090D16',
    swatchSecondary: '#4F46E5',
  },
  'emerald-dusk': {
    id: 'emerald-dusk',
    name: 'Emerald Dusk',
    nameBn: 'এমেরাল্ড ডাস্ক',
    isDark: true,
    canvasBg: '#080E0D',
    sidebarBg: '#0D1715',
    surfaceBg: '#13201E',
    surfaceHoverBg: '#1A2B28',
    borderColor: 'rgba(52, 211, 153, 0.15)',
    textPrimary: '#ECFDF5',
    textSecondary: '#A7F3D0',
    textMuted: '#789A8E',
    accentBg: '#059669',
    accentHoverBg: '#047857',
    accentSoftBg: 'rgba(16, 185, 129, 0.16)',
    accentText: '#6EE7B7',
    accentBorder: 'rgba(16, 185, 129, 0.35)',
    ownBubbleBg: '#059669',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#142421',
    otherBubbleText: '#ECFDF5',
    swatchPrimary: '#080E0D',
    swatchSecondary: '#10B981',
  },
  'clean-daylight': {
    id: 'clean-daylight',
    name: 'Clean Daylight',
    nameBn: 'ক্লিন ডে-লাইট',
    isDark: false,
    canvasBg: '#F6F5FA',
    sidebarBg: '#FFFFFF',
    surfaceBg: '#FFFFFF',
    surfaceHoverBg: '#EFEBF8',
    borderColor: 'rgba(109, 40, 217, 0.14)',
    textPrimary: '#161324',
    textSecondary: '#4C1D95',
    textMuted: '#68627E',
    accentBg: '#7C3AED',
    accentHoverBg: '#6D28D9',
    accentSoftBg: 'rgba(124, 58, 237, 0.1)',
    accentText: '#6D28D9',
    accentBorder: 'rgba(124, 58, 237, 0.25)',
    ownBubbleBg: '#7C3AED',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#FFFFFF',
    otherBubbleText: '#161324',
    swatchPrimary: '#F6F5FA',
    swatchSecondary: '#7C3AED',
  },
  'whatsapp-dark': {
    id: 'whatsapp-dark',
    name: 'WA Dark',
    nameBn: 'হোয়াটসঅ্যাপ ডার্ক',
    isDark: true,
    canvasBg: '#0B141A',
    sidebarBg: '#111B21',
    surfaceBg: '#202C33',
    surfaceHoverBg: '#2A3942',
    borderColor: 'rgba(134, 150, 160, 0.18)',
    textPrimary: '#E9EDEF',
    textSecondary: '#A6E3CE',
    textMuted: '#8696A0',
    accentBg: '#00A884',
    accentHoverBg: '#008F72',
    accentSoftBg: 'rgba(0, 168, 132, 0.16)',
    accentText: '#25D366',
    accentBorder: 'rgba(0, 168, 132, 0.36)',
    ownBubbleBg: '#005C4B',
    ownBubbleText: '#E9EDEF',
    otherBubbleBg: '#202C33',
    otherBubbleText: '#E9EDEF',
    swatchPrimary: '#0B141A',
    swatchSecondary: '#00A884',
  },
  'whatsapp-classic': {
    id: 'whatsapp-classic',
    name: 'WA Classic',
    nameBn: 'হোয়াটসঅ্যাপ ক্লাসিক',
    isDark: false,
    canvasBg: '#EFEAE2',
    sidebarBg: '#FFFFFF',
    surfaceBg: '#FFFFFF',
    surfaceHoverBg: '#F0F2F5',
    borderColor: 'rgba(17, 27, 33, 0.12)',
    textPrimary: '#111B21',
    textSecondary: '#008069',
    textMuted: '#667781',
    accentBg: '#008069',
    accentHoverBg: '#016B57',
    accentSoftBg: 'rgba(0, 128, 105, 0.1)',
    accentText: '#008069',
    accentBorder: 'rgba(0, 128, 105, 0.28)',
    ownBubbleBg: '#D9FDD3',
    ownBubbleText: '#111B21',
    otherBubbleBg: '#FFFFFF',
    otherBubbleText: '#111B21',
    swatchPrimary: '#EFEAE2',
    swatchSecondary: '#008069',
  },
  'messenger-midnight': {
    id: 'messenger-midnight',
    name: 'Messenger Blue',
    nameBn: 'মেসেঞ্জার ব্লু',
    isDark: true,
    canvasBg: '#0A0C12',
    sidebarBg: '#12151E',
    surfaceBg: '#1C202B',
    surfaceHoverBg: '#262B3A',
    borderColor: 'rgba(56, 152, 255, 0.16)',
    textPrimary: '#F5F7FA',
    textSecondary: '#93C5FD',
    textMuted: '#8B95A8',
    accentBg: '#0084FF',
    accentHoverBg: '#0070DB',
    accentSoftBg: 'rgba(0, 132, 255, 0.18)',
    accentText: '#60A5FA',
    accentBorder: 'rgba(0, 132, 255, 0.36)',
    ownBubbleBg: '#0084FF',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#242936',
    otherBubbleText: '#F5F7FA',
    swatchPrimary: '#0A0C12',
    swatchSecondary: '#0084FF',
  },
  'oled-amoled': {
    id: 'oled-amoled',
    name: 'AMOLED Pure',
    nameBn: 'অ্যামোলেড ব্ল্যাক',
    isDark: true,
    canvasBg: '#000000',
    sidebarBg: '#070709',
    surfaceBg: '#111116',
    surfaceHoverBg: '#1B1B24',
    borderColor: 'rgba(255, 255, 255, 0.12)',
    textPrimary: '#FAFAFA',
    textSecondary: '#67E8F9',
    textMuted: '#8E8E98',
    accentBg: '#0891B2',
    accentHoverBg: '#0E7490',
    accentSoftBg: 'rgba(8, 145, 178, 0.18)',
    accentText: '#22D3EE',
    accentBorder: 'rgba(34, 211, 238, 0.35)',
    ownBubbleBg: '#0E7490',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#15151C',
    otherBubbleText: '#FAFAFA',
    swatchPrimary: '#000000',
    swatchSecondary: '#06B6D4',
  },
  'ocean-teal': {
    id: 'ocean-teal',
    name: 'Ocean Teal',
    nameBn: 'ওশান টিল',
    isDark: true,
    canvasBg: '#061318',
    sidebarBg: '#0A1C22',
    surfaceBg: '#102830',
    surfaceHoverBg: '#163640',
    borderColor: 'rgba(45, 212, 191, 0.16)',
    textPrimary: '#F0FDFA',
    textSecondary: '#99F6E4',
    textMuted: '#7AA3AA',
    accentBg: '#0D9488',
    accentHoverBg: '#0F766E',
    accentSoftBg: 'rgba(13, 148, 136, 0.18)',
    accentText: '#5EEAD4',
    accentBorder: 'rgba(45, 212, 191, 0.36)',
    ownBubbleBg: '#0F766E',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#122C34',
    otherBubbleText: '#F0FDFA',
    swatchPrimary: '#061318',
    swatchSecondary: '#14B8A6',
  },
  'sunset-rose': {
    id: 'sunset-rose',
    name: 'Sunset Rose',
    nameBn: 'সানসেট রোজ',
    isDark: true,
    canvasBg: '#14090F',
    sidebarBg: '#1D0E16',
    surfaceBg: '#29141F',
    surfaceHoverBg: '#361B2A',
    borderColor: 'rgba(251, 113, 133, 0.18)',
    textPrimary: '#FFF1F2',
    textSecondary: '#FECDD3',
    textMuted: '#B28492',
    accentBg: '#E11D48',
    accentHoverBg: '#BE123C',
    accentSoftBg: 'rgba(225, 29, 72, 0.18)',
    accentText: '#FDA4AF',
    accentBorder: 'rgba(244, 63, 94, 0.38)',
    ownBubbleBg: '#BE123C',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#2E1623',
    otherBubbleText: '#FFF1F2',
    swatchPrimary: '#14090F',
    swatchSecondary: '#E11D48',
  },
  'nordic-slate': {
    id: 'nordic-slate',
    name: 'Nordic Slate',
    nameBn: 'নর্ডিক স্লেট',
    isDark: true,
    canvasBg: '#0F172A',
    sidebarBg: '#162036',
    surfaceBg: '#1E293B',
    surfaceHoverBg: '#293548',
    borderColor: 'rgba(148, 163, 184, 0.18)',
    textPrimary: '#F8FAFC',
    textSecondary: '#BAE6FD',
    textMuted: '#94A3B8',
    accentBg: '#0284C7',
    accentHoverBg: '#0369A1',
    accentSoftBg: 'rgba(2, 132, 199, 0.18)',
    accentText: '#38BDF8',
    accentBorder: 'rgba(56, 189, 248, 0.36)',
    ownBubbleBg: '#0369A1',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#1E293B',
    otherBubbleText: '#F8FAFC',
    swatchPrimary: '#0F172A',
    swatchSecondary: '#38BDF8',
  },
  'mocha-espresso': {
    id: 'mocha-espresso',
    name: 'Mocha Espresso',
    nameBn: 'মোকা এসপ্রেসো',
    isDark: true,
    canvasBg: '#140E0B',
    sidebarBg: '#1C1410',
    surfaceBg: '#271D17',
    surfaceHoverBg: '#33261E',
    borderColor: 'rgba(251, 191, 36, 0.15)',
    textPrimary: '#FEF7EE',
    textSecondary: '#FDE68A',
    textMuted: '#A89483',
    accentBg: '#D97706',
    accentHoverBg: '#B45309',
    accentSoftBg: 'rgba(217, 119, 6, 0.18)',
    accentText: '#FBBF24',
    accentBorder: 'rgba(245, 158, 11, 0.36)',
    ownBubbleBg: '#B45309',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#2B2019',
    otherBubbleText: '#FEF7EE',
    swatchPrimary: '#140E0B',
    swatchSecondary: '#D97706',
  },
  'crimson-velvet': {
    id: 'crimson-velvet',
    name: 'Crimson Velvet',
    nameBn: 'ক্রিমসন ভেলভেট',
    isDark: true,
    canvasBg: '#15080B',
    sidebarBg: '#1E0D11',
    surfaceBg: '#2A1218',
    surfaceHoverBg: '#371820',
    borderColor: 'rgba(248, 113, 113, 0.16)',
    textPrimary: '#FEF2F2',
    textSecondary: '#FECACA',
    textMuted: '#AE868C',
    accentBg: '#DC2626',
    accentHoverBg: '#B91C1C',
    accentSoftBg: 'rgba(220, 38, 38, 0.18)',
    accentText: '#FCA5A5',
    accentBorder: 'rgba(239, 68, 68, 0.38)',
    ownBubbleBg: '#B91C1C',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#2D141B',
    otherBubbleText: '#FEF2F2',
    swatchPrimary: '#15080B',
    swatchSecondary: '#DC2626',
  },
  'cyber-indigo': {
    id: 'cyber-indigo',
    name: 'Cyber Neon',
    nameBn: 'সাইবার নিয়ন',
    isDark: true,
    canvasBg: '#080814',
    sidebarBg: '#0E0E21',
    surfaceBg: '#161632',
    surfaceHoverBg: '#202045',
    borderColor: 'rgba(192, 132, 252, 0.18)',
    textPrimary: '#F5F3FF',
    textSecondary: '#F0ABFC',
    textMuted: '#9291B5',
    accentBg: '#C026D3',
    accentHoverBg: '#A21CAF',
    accentSoftBg: 'rgba(192, 38, 211, 0.18)',
    accentText: '#E879F9',
    accentBorder: 'rgba(217, 70, 239, 0.38)',
    ownBubbleBg: '#9333EA',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#1A1A38',
    otherBubbleText: '#F5F3FF',
    swatchPrimary: '#080814',
    swatchSecondary: '#D946EF',
  },
  'sakura-blush': {
    id: 'sakura-blush',
    name: 'Sakura Blush',
    nameBn: 'সাকুরা ব্লাশ',
    isDark: false,
    canvasBg: '#FFF5F8',
    sidebarBg: '#FFFFFF',
    surfaceBg: '#FFFFFF',
    surfaceHoverBg: '#FCE7F0',
    borderColor: 'rgba(219, 39, 119, 0.15)',
    textPrimary: '#28101C',
    textSecondary: '#9D174D',
    textMuted: '#7F5D6E',
    accentBg: '#DB2777',
    accentHoverBg: '#BE185D',
    accentSoftBg: 'rgba(219, 39, 119, 0.1)',
    accentText: '#BE185D',
    accentBorder: 'rgba(219, 39, 119, 0.28)',
    ownBubbleBg: '#DB2777',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#FFFFFF',
    otherBubbleText: '#28101C',
    swatchPrimary: '#FFF5F8',
    swatchSecondary: '#DB2777',
  },
  'forest-sage': {
    id: 'forest-sage',
    name: 'Forest Sage',
    nameBn: 'ফরেস্ট সেজ',
    isDark: true,
    canvasBg: '#09120D',
    sidebarBg: '#0F1B14',
    surfaceBg: '#16261D',
    surfaceHoverBg: '#1E3327',
    borderColor: 'rgba(74, 222, 128, 0.15)',
    textPrimary: '#F0FDF4',
    textSecondary: '#BBF7D0',
    textMuted: '#7E9F8B',
    accentBg: '#16A34A',
    accentHoverBg: '#15803D',
    accentSoftBg: 'rgba(22, 163, 74, 0.18)',
    accentText: '#4ADE80',
    accentBorder: 'rgba(74, 222, 128, 0.35)',
    ownBubbleBg: '#15803D',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#182A20',
    otherBubbleText: '#F0FDF4',
    swatchPrimary: '#09120D',
    swatchSecondary: '#22C55E',
  },
  'amber-gold': {
    id: 'amber-gold',
    name: 'Royal Gold',
    nameBn: 'রয়্যাল গোল্ড',
    isDark: true,
    canvasBg: '#121009',
    sidebarBg: '#1B170D',
    surfaceBg: '#262013',
    surfaceHoverBg: '#322A19',
    borderColor: 'rgba(250, 204, 21, 0.16)',
    textPrimary: '#FEFCE8',
    textSecondary: '#FEF08A',
    textMuted: '#A89F7F',
    accentBg: '#CA8A04',
    accentHoverBg: '#A16207',
    accentSoftBg: 'rgba(202, 138, 4, 0.18)',
    accentText: '#FACC15',
    accentBorder: 'rgba(250, 204, 21, 0.36)',
    ownBubbleBg: '#A16207',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#292315',
    otherBubbleText: '#FEFCE8',
    swatchPrimary: '#121009',
    swatchSecondary: '#EAB308',
  },
  'lavender-cloud': {
    id: 'lavender-cloud',
    name: 'Lavender Cloud',
    nameBn: 'ল্যাভেন্ডার ক্লাউড',
    isDark: false,
    canvasBg: '#F3F0FF',
    sidebarBg: '#FFFFFF',
    surfaceBg: '#FFFFFF',
    surfaceHoverBg: '#EAE4FF',
    borderColor: 'rgba(99, 102, 241, 0.15)',
    textPrimary: '#1E1B4B',
    textSecondary: '#4338CA',
    textMuted: '#63668B',
    accentBg: '#4F46E5',
    accentHoverBg: '#4338CA',
    accentSoftBg: 'rgba(79, 70, 229, 0.1)',
    accentText: '#4338CA',
    accentBorder: 'rgba(79, 70, 229, 0.28)',
    ownBubbleBg: '#4F46E5',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#FFFFFF',
    otherBubbleText: '#1E1B4B',
    swatchPrimary: '#F3F0FF',
    swatchSecondary: '#4F46E5',
  },
  'desert-sand': {
    id: 'desert-sand',
    name: 'Desert Sand',
    nameBn: 'ডেজার্ট স্যান্ড',
    isDark: false,
    canvasBg: '#FAF5EE',
    sidebarBg: '#FFFFFF',
    surfaceBg: '#FFFFFF',
    surfaceHoverBg: '#F3EADF',
    borderColor: 'rgba(194, 65, 12, 0.14)',
    textPrimary: '#2B1810',
    textSecondary: '#9A3412',
    textMuted: '#7E6557',
    accentBg: '#C2410C',
    accentHoverBg: '#9A3412',
    accentSoftBg: 'rgba(194, 65, 12, 0.1)',
    accentText: '#C2410C',
    accentBorder: 'rgba(194, 65, 12, 0.28)',
    ownBubbleBg: '#C2410C',
    ownBubbleText: '#FFFFFF',
    otherBubbleBg: '#FFFFFF',
    otherBubbleText: '#2B1810',
    swatchPrimary: '#FAF5EE',
    swatchSecondary: '#EA580C',
  },
};

function makeSvgWallpaper(defsAndShapes: string, bg: string): string {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='640' height='640' viewBox='0 0 640 640'><rect width='640' height='640' fill='${bg}'/>${defsAndShapes}</svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

export const WALLPAPER_PRESETS: WallpaperPreset[] = [
  {
    id: 'wp-violet-nebula',
    name: 'Violet Nebula',
    nameBn: 'ভায়োলেট নেবুলা',
    previewBg: 'radial-gradient(circle at 25% 25%, #6D28D9, #0B0A10 70%)',
    url: makeSvgWallpaper(
      "<defs><radialGradient id='g1' cx='25%' cy='20%' r='65%'><stop offset='0%' stop-color='#7C3AED' stop-opacity='0.55'/><stop offset='100%' stop-color='#0B0A10' stop-opacity='0'/></radialGradient><radialGradient id='g2' cx='80%' cy='80%' r='55%'><stop offset='0%' stop-color='#EC4899' stop-opacity='0.35'/><stop offset='100%' stop-color='#0B0A10' stop-opacity='0'/></radialGradient></defs><rect width='640' height='640' fill='url(#g1)'/><rect width='640' height='640' fill='url(#g2)'/>",
      '#0B0A10'
    ),
  },
  {
    id: 'wp-whatsapp-doodle',
    name: 'Chat Doodles',
    nameBn: 'চ্যাট ডুডল',
    previewBg: 'linear-gradient(135deg, #0B141A 0%, #16302B 100%)',
    url: makeSvgWallpaper(
      "<defs><pattern id='p' width='80' height='80' patternUnits='userSpaceOnUse'><circle cx='20' cy='20' r='5' fill='none' stroke='#25D366' stroke-opacity='0.14' stroke-width='2'/><path d='M50 15 l10 10 m0 -10 l-10 10' stroke='#25D366' stroke-opacity='0.14' stroke-width='2'/><rect x='14' y='52' width='14' height='10' rx='4' fill='none' stroke='#25D366' stroke-opacity='0.14' stroke-width='2'/><path d='M52 58 q6 -10 12 0' fill='none' stroke='#25D366' stroke-opacity='0.14' stroke-width='2'/></pattern></defs><rect width='640' height='640' fill='url(#p)'/>",
      '#0B141A'
    ),
  },
  {
    id: 'wp-aurora-waves',
    name: 'Aurora Waves',
    nameBn: 'অরোরা ওয়েভ',
    previewBg: 'linear-gradient(160deg, #0F172A, #312E81, #065F46)',
    url: makeSvgWallpaper(
      "<defs><linearGradient id='w1' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='#4F46E5' stop-opacity='0.45'/><stop offset='50%' stop-color='#0EA5E9' stop-opacity='0.28'/><stop offset='100%' stop-color='#10B981' stop-opacity='0.4'/></linearGradient></defs><path d='M0 240 Q160 140 320 240 T640 240 L640 640 L0 640 Z' fill='url(#w1)'/><path d='M0 390 Q200 300 400 390 T640 370 L640 640 L0 640 Z' fill='#6366F1' fill-opacity='0.16'/>",
      '#090D16'
    ),
  },
  {
    id: 'wp-emerald-grid',
    name: 'Emerald Grid',
    nameBn: 'এমেরাল্ড গ্রিড',
    previewBg: 'linear-gradient(135deg, #071310, #064E3B)',
    url: makeSvgWallpaper(
      "<defs><pattern id='g' width='40' height='40' patternUnits='userSpaceOnUse'><path d='M40 0 H0 V40' fill='none' stroke='#34D399' stroke-opacity='0.12' stroke-width='1'/></pattern></defs><rect width='640' height='640' fill='url(#g)'/>",
      '#071310'
    ),
  },
  {
    id: 'wp-crimson-silk',
    name: 'Crimson Silk',
    nameBn: 'ক্রিমসন সিল্ক',
    previewBg: 'radial-gradient(circle at 75% 25%, #BE123C, #14080E 75%)',
    url: makeSvgWallpaper(
      "<defs><radialGradient id='r' cx='75%' cy='20%' r='70%'><stop offset='0%' stop-color='#E11D48' stop-opacity='0.5'/><stop offset='100%' stop-color='#14080E' stop-opacity='0'/></radialGradient></defs><rect width='640' height='640' fill='url(#r)'/><path d='M0 480 Q320 380 640 500 L640 640 L0 640 Z' fill='#FB7185' fill-opacity='0.12'/>",
      '#14080E'
    ),
  },
  {
    id: 'wp-ocean-depths',
    name: 'Ocean Depths',
    nameBn: 'সমুদ্র গভীর',
    previewBg: 'linear-gradient(180deg, #082F49, #04131E)',
    url: makeSvgWallpaper(
      "<defs><linearGradient id='o' x1='0' y1='0' x2='0' y2='1'><stop offset='0%' stop-color='#0284C7' stop-opacity='0.45'/><stop offset='100%' stop-color='#04131E' stop-opacity='0'/></linearGradient></defs><rect width='640' height='640' fill='url(#o)'/><circle cx='120' cy='160' r='90' fill='#38BDF8' fill-opacity='0.08'/><circle cx='500' cy='420' r='130' fill='#2DD4BF' fill-opacity='0.08'/>",
      '#04131E'
    ),
  },
  {
    id: 'wp-golden-hex',
    name: 'Golden Hex',
    nameBn: 'গোল্ডেন হেক্স',
    previewBg: 'linear-gradient(135deg, #171207, #422006)',
    url: makeSvgWallpaper(
      "<defs><pattern id='h' width='56' height='48' patternUnits='userSpaceOnUse'><polygon points='28,2 52,14 52,36 28,46 4,36 4,14' fill='none' stroke='#FACC15' stroke-opacity='0.14' stroke-width='1.5'/></pattern></defs><rect width='640' height='640' fill='url(#h)'/>",
      '#120E06'
    ),
  },
  {
    id: 'wp-starlight-night',
    name: 'Starlight Night',
    nameBn: 'তারার রাত',
    previewBg: 'radial-gradient(circle at 50% 40%, #1E1B4B, #05050A)',
    url: makeSvgWallpaper(
      "<circle cx='80' cy='90' r='2' fill='#FFFFFF' fill-opacity='0.65'/><circle cx='210' cy='160' r='1.5' fill='#C4B5FD' fill-opacity='0.8'/><circle cx='390' cy='70' r='2.5' fill='#FFFFFF' fill-opacity='0.55'/><circle cx='540' cy='140' r='1.8' fill='#93C5FD' fill-opacity='0.75'/><circle cx='140' cy='340' r='2' fill='#FFFFFF' fill-opacity='0.5'/><circle cx='310' cy='290' r='1.4' fill='#FDE68A' fill-opacity='0.7'/><circle cx='490' cy='370' r='2.2' fill='#FFFFFF' fill-opacity='0.6'/><circle cx='100' cy='520' r='1.8' fill='#C4B5FD' fill-opacity='0.7'/><circle cx='420' cy='540' r='2' fill='#FFFFFF' fill-opacity='0.65'/><circle cx='580' cy='510' r='1.5' fill='#FFFFFF' fill-opacity='0.5'/>",
      '#060612'
    ),
  },
  {
    id: 'wp-sunset-horizon',
    name: 'Sunset Horizon',
    nameBn: 'গোধূলি আকাশ',
    previewBg: 'linear-gradient(160deg, #4C1D95, #BE185D, #EA580C)',
    url: makeSvgWallpaper(
      "<defs><linearGradient id='s' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='#4C1D95' stop-opacity='0.75'/><stop offset='55%' stop-color='#BE185D' stop-opacity='0.55'/><stop offset='100%' stop-color='#EA580C' stop-opacity='0.55'/></linearGradient></defs><rect width='640' height='640' fill='url(#s)'/>",
      '#1A0B1E'
    ),
  },
  {
    id: 'wp-cyber-circuit',
    name: 'Cyber Matrix',
    nameBn: 'সাইবার ম্যাট্রিক্স',
    previewBg: 'linear-gradient(135deg, #060918, #3B0764)',
    url: makeSvgWallpaper(
      "<defs><pattern id='c' width='64' height='64' patternUnits='userSpaceOnUse'><path d='M0 32 H24 L32 24 H64 M32 0 V16 M32 40 V64' fill='none' stroke='#D946EF' stroke-opacity='0.18' stroke-width='1.5'/><circle cx='32' cy='24' r='3' fill='#22D3EE' fill-opacity='0.3'/></pattern></defs><rect width='640' height='640' fill='url(#c)'/>",
      '#070716'
    ),
  },
  {
    id: 'wp-pastel-clouds',
    name: 'Soft Lavender',
    nameBn: 'সফট ল্যাভেন্ডার',
    previewBg: 'linear-gradient(135deg, #EDE9FE, #FCE7F3)',
    url: makeSvgWallpaper(
      "<defs><radialGradient id='l1' cx='20%' cy='20%' r='60%'><stop offset='0%' stop-color='#C4B5FD' stop-opacity='0.55'/><stop offset='100%' stop-color='#F5F3FF' stop-opacity='0'/></radialGradient><radialGradient id='l2' cx='85%' cy='80%' r='60%'><stop offset='0%' stop-color='#F9A8D4' stop-opacity='0.45'/><stop offset='100%' stop-color='#F5F3FF' stop-opacity='0'/></radialGradient></defs><rect width='640' height='640' fill='url(#l1)'/><rect width='640' height='640' fill='url(#l2)'/>",
      '#F5F3FF'
    ),
  },
  {
    id: 'wp-wa-light-paper',
    name: 'Classic Sand',
    nameBn: 'ক্লাসিক পেপার',
    previewBg: 'linear-gradient(135deg, #EFEAE2, #E2D9CB)',
    url: makeSvgWallpaper(
      "<defs><pattern id='wd' width='72' height='72' patternUnits='userSpaceOnUse'><circle cx='18' cy='18' r='4' fill='none' stroke='#8C7E6A' stroke-opacity='0.18' stroke-width='1.8'/><path d='M48 16 l8 8 m0 -8 l-8 8' stroke='#8C7E6A' stroke-opacity='0.16' stroke-width='1.8'/><rect x='14' y='46' width='12' height='9' rx='3' fill='none' stroke='#8C7E6A' stroke-opacity='0.16' stroke-width='1.8'/></pattern></defs><rect width='640' height='640' fill='url(#wd)'/>",
      '#EFEAE2'
    ),
  },
  {
    id: 'wp-mint-dots',
    name: 'Mint Polka',
    nameBn: 'মিন্ট ডটস',
    previewBg: 'linear-gradient(135deg, #ECFDF5, #D1FAE5)',
    url: makeSvgWallpaper(
      "<defs><pattern id='m' width='36' height='36' patternUnits='userSpaceOnUse'><circle cx='18' cy='18' r='3' fill='#10B981' fill-opacity='0.18'/></pattern></defs><rect width='640' height='640' fill='url(#m)'/>",
      '#ECFDF5'
    ),
  },
  {
    id: 'wp-sakura-petals',
    name: 'Sakura Petals',
    nameBn: 'সাকুরা ফুল',
    previewBg: 'linear-gradient(135deg, #FFF1F2, #FBCFE8)',
    url: makeSvgWallpaper(
      "<defs><pattern id='sp' width='90' height='90' patternUnits='userSpaceOnUse'><ellipse cx='24' cy='24' rx='7' ry='4' transform='rotate(25 24 24)' fill='#F472B6' fill-opacity='0.22'/><ellipse cx='66' cy='58' rx='6' ry='3.5' transform='rotate(-30 66 58)' fill='#EC4899' fill-opacity='0.18'/></pattern></defs><rect width='640' height='640' fill='url(#sp)'/>",
      '#FFF5F7'
    ),
  },
  {
    id: 'wp-diagonal-stripes',
    name: 'Midnight Stripes',
    nameBn: 'মিডনাইট স্ট্রাইপ',
    previewBg: 'repeating-linear-gradient(45deg, #111827, #111827 10px, #1E293B 10px, #1E293B 20px)',
    url: makeSvgWallpaper(
      "<defs><pattern id='ds' width='28' height='28' patternTransform='rotate(45)' patternUnits='userSpaceOnUse'><rect width='14' height='28' fill='#FFFFFF' fill-opacity='0.03'/></pattern></defs><rect width='640' height='640' fill='url(#ds)'/>",
      '#0F172A'
    ),
  },
  {
    id: 'wp-mocha-waves',
    name: 'Coffee Cream',
    nameBn: 'কফি ক্রিম',
    previewBg: 'linear-gradient(135deg, #1C130E, #452719)',
    url: makeSvgWallpaper(
      "<path d='M0 200 C180 120 420 280 640 190 L640 640 L0 640 Z' fill='#D97706' fill-opacity='0.12'/><path d='M0 400 C220 320 440 460 640 370 L640 640 L0 640 Z' fill='#F59E0B' fill-opacity='0.1'/>",
      '#140E0B'
    ),
  },
  {
    id: 'wp-geo-diamonds',
    name: 'Geo Diamonds',
    nameBn: 'জিও ডায়মন্ড',
    previewBg: 'linear-gradient(135deg, #1E1B4B, #312E81)',
    url: makeSvgWallpaper(
      "<defs><pattern id='gd' width='48' height='48' patternUnits='userSpaceOnUse'><polygon points='24,4 44,24 24,44 4,24' fill='none' stroke='#818CF8' stroke-opacity='0.16' stroke-width='1.5'/></pattern></defs><rect width='640' height='640' fill='url(#gd)'/>",
      '#0D0F24'
    ),
  },
  {
    id: 'wp-forest-canopy',
    name: 'Forest Leaves',
    nameBn: 'ফরেস্ট পাতা',
    previewBg: 'radial-gradient(circle at 30% 30%, #15803D, #052E16)',
    url: makeSvgWallpaper(
      "<defs><radialGradient id='fc' cx='30%' cy='25%' r='65%'><stop offset='0%' stop-color='#22C55E' stop-opacity='0.28'/><stop offset='100%' stop-color='#08120C' stop-opacity='0'/></radialGradient></defs><rect width='640' height='640' fill='url(#fc)'/><circle cx='500' cy='500' r='160' fill='#16A34A' fill-opacity='0.1'/>",
      '#08120C'
    ),
  },
  {
    id: 'wp-blue-radial',
    name: 'Messenger Glow',
    nameBn: 'মেসেঞ্জার গ্লো',
    previewBg: 'radial-gradient(circle at 80% 20%, #0084FF, #0A0C12 70%)',
    url: makeSvgWallpaper(
      "<defs><radialGradient id='mg1' cx='82%' cy='18%' r='60%'><stop offset='0%' stop-color='#0084FF' stop-opacity='0.45'/><stop offset='100%' stop-color='#0A0C12' stop-opacity='0'/></radialGradient><radialGradient id='mg2' cx='15%' cy='85%' r='55%'><stop offset='0%' stop-color='#A855F7' stop-opacity='0.32'/><stop offset='100%' stop-color='#0A0C12' stop-opacity='0'/></radialGradient></defs><rect width='640' height='640' fill='url(#mg1)'/><rect width='640' height='640' fill='url(#mg2)'/>",
      '#0A0C12'
    ),
  },
  {
    id: 'wp-amoled-minimal',
    name: 'Pure Minimal Dots',
    nameBn: 'মিনিমাল ডটস',
    previewBg: 'radial-gradient(circle at 50% 50%, #18181B, #000000)',
    url: makeSvgWallpaper(
      "<defs><pattern id='pm' width='32' height='32' patternUnits='userSpaceOnUse'><circle cx='16' cy='16' r='1.2' fill='#FFFFFF' fill-opacity='0.15'/></pattern></defs><rect width='640' height='640' fill='url(#pm)'/>",
      '#000000'
    ),
  },
];

export const CALL_AVATAR_PRESETS: Array<{
  id: CallAvatarId;
  label: string;
  labelBn: string;
  emoji: string;
}> = [
  { id: 'none', label: 'Normal', labelBn: 'নরমাল', emoji: '🚫' },
  { id: 'shades', label: 'Shades', labelBn: 'সানগ্লাস', emoji: '😎' },
  { id: 'visor', label: 'Neon Visor', labelBn: 'নিয়ন ভাইজর', emoji: '🕶️' },
  { id: 'cat', label: 'Cat Ears', labelBn: 'বিড়াল', emoji: '🐱' },
  { id: 'crown', label: 'King Crown', labelBn: 'রাজমুকুট', emoji: '👑' },
  { id: 'robot', label: 'Cyber Bot', labelBn: 'রোবট', emoji: '🤖' },
  { id: 'panda', label: 'Panda', labelBn: 'পান্ডা', emoji: '🐼' },
  { id: 'heart', label: 'Heart Eyes', labelBn: 'লাভ আইজ', emoji: '😍' },
  { id: 'cyber', label: 'Anime Aura', labelBn: 'অ্যানিমে গ্লো', emoji: '✨' },
  { id: 'privacy', label: 'Avatar Mask', labelBn: 'ফেস মাস্ক', emoji: '🎭' },
];

export function isValidThemeId(value: string): value is ThemeId {
  return Object.prototype.hasOwnProperty.call(THEME_SPECS, value);
}

export function resolveTheme(value?: string | null): ThemeSpec {
  if (value && isValidThemeId(value)) {
    return THEME_SPECS[value];
  }
  return THEME_SPECS['midnight-violet'];
}

export function generateGuestNickname(seed?: string): string {
  const suffix = seed
    ? seed.replace(/[^a-zA-Z0-9]/g, '').slice(-4).toUpperCase()
    : Math.floor(1000 + Math.random() * 9000).toString();
  return `Guest-${suffix || '1024'}`;
}

export function sanitizeNickname(raw: string): {
  valid: boolean;
  nickname: string;
  error?: string;
} {
  const cleaned = raw.replace(/\s+/g, ' ').trim();
  if (cleaned.length < 2) {
    return {
      valid: false,
      nickname: cleaned,
      error: 'Nickname must be at least 2 characters.',
    };
  }
  if (cleaned.length > 24) {
    return {
      valid: false,
      nickname: cleaned.slice(0, 24),
      error: 'Nickname must be 24 characters or less.',
    };
  }
  return { valid: true, nickname: cleaned };
}

export function sanitizeUsername(raw: string): {
  valid: boolean;
  username: string;
  error?: string;
} {
  const cleaned = raw.trim().replace(/^@+/, '').toLowerCase();
  if (!cleaned) {
    return { valid: true, username: '' };
  }
  if (cleaned.length < 3 || cleaned.length > 20) {
    return {
      valid: false,
      username: cleaned,
      error: 'Username must be 3–20 characters.',
    };
  }
  if (!/^[a-z0-9_]+$/.test(cleaned)) {
    return {
      valid: false,
      username: cleaned,
      error: 'Username can only contain letters, numbers, and underscores.',
    };
  }
  return { valid: true, username: cleaned };
}

export function normalizeNicknameKey(nickname: string): string {
  return nickname.replace(/\s+/g, ' ').trim().toLowerCase();
}

export function validateBangladeshPhone(raw: string): {
  valid: boolean;
  normalized: string;
  display: string;
  error?: string;
} {
  const stripped = (raw ?? '').replace(/[\s\-()]/g, '').trim();
  const match = stripped.match(/^(?:\+?88)?(01[3-9]\d{8})$/);
  if (!match) {
    return {
      valid: false,
      normalized: stripped,
      display: stripped,
      error: 'Enter a valid 11-digit BD phone number (e.g. 017XXXXXXXX).',
    };
  }
  const normalized = match[1];
  const display = `+88 ${normalized.slice(0, 5)}-${normalized.slice(5)}`;
  return {
    valid: true,
    normalized,
    display,
  };
}

export function formatBdPhoneDisplay(phone: string): string {
  const res = validateBangladeshPhone(phone);
  return res.valid ? res.display : phone;
}

export function isUserBlocked(
  blockedList: BlockedUser[],
  clientId: string,
  nickname?: string,
  phoneNumber?: string
): boolean {
  const normalizedName = nickname ? normalizeNicknameKey(nickname) : '';
  const phoneCheck = phoneNumber ? validateBangladeshPhone(phoneNumber) : null;
  const normalizedPhone = phoneCheck?.valid ? phoneCheck.normalized : '';

  return blockedList.some((entry) => {
    if (entry.clientId && clientId && entry.clientId === clientId) {
      return true;
    }
    if (
      normalizedName &&
      normalizeNicknameKey(entry.nickname) === normalizedName
    ) {
      return true;
    }
    if (normalizedPhone && entry.phoneNumber) {
      const entryPhone = validateBangladeshPhone(entry.phoneNumber);
      if (entryPhone.valid && entryPhone.normalized === normalizedPhone) {
        return true;
      }
    }
    return false;
  });
}

const MAX_MESSAGE_TEXT_LENGTH = 2000;
const MAX_MEDIA_DATA_URL_LENGTH = 750_000; // Legacy compatibility cap only

export function isSafeMediaUrl(url: string): boolean {
  const trimmed = (url || '').trim();
  if (!trimmed) return false;
  if (trimmed.startsWith('/api/media/') || trimmed.startsWith('/api/gifs/')) {
    return true;
  }
  if (trimmed.startsWith('data:image/') || trimmed.startsWith('data:audio/')) {
    return trimmed.length <= MAX_MEDIA_DATA_URL_LENGTH;
  }
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

export function validatePollInput(
  question: string,
  options: string[]
): { valid: boolean; poll?: ChatPoll; error?: string } {
  const cleanQuestion = question.replace(/\s+/g, ' ').trim();
  if (cleanQuestion.length < 2 || cleanQuestion.length > 160) {
    return {
      valid: false,
      error: 'Poll question must be 2–160 characters.',
    };
  }

  const cleanOptions = options
    .map((opt) => opt.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .slice(0, 5);

  if (cleanOptions.length < 2) {
    return {
      valid: false,
      error: 'Provide at least 2 poll options.',
    };
  }

  return {
    valid: true,
    poll: {
      question: cleanQuestion,
      options: cleanOptions.map((label, idx) => ({
        id: `opt-${idx + 1}`,
        label: label.slice(0, 80),
        voterIds: [],
      })),
    },
  };
}

export function togglePollVote(
  poll: ChatPoll,
  optionId: string,
  clientId: string
): ChatPoll {
  if (!optionId || !clientId) return poll;
  const targetAlreadyVoted = poll.options.some(
    (opt) => opt.id === optionId && opt.voterIds.includes(clientId)
  );

  return {
    ...poll,
    options: poll.options.map((opt) => {
      const filtered = opt.voterIds.filter((id) => id !== clientId);
      if (opt.id === optionId && !targetAlreadyVoted) {
        return { ...opt, voterIds: [...filtered, clientId] };
      }
      return { ...opt, voterIds: filtered };
    }),
  };
}

export interface ExtendedMessagePayloadInput {
  text: string;
  imageDataUrl?: string;
  imageUrl?: string;
  videoUrl?: string;
  audioDataUrl?: string;
  audioUrl?: string;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  gifUrl?: string;
  stickerUrl?: string;
  poll?: { question: string; options: string[] };
}

export function validateMessagePayload(
  textOrInput: string | ExtendedMessagePayloadInput,
  imageDataUrlArg?: string,
  audioDataUrlArg?: string,
  pollInputArg?: { question: string; options: string[] }
): {
  valid: boolean;
  text: string;
  imageDataUrl?: string;
  imageUrl?: string;
  videoUrl?: string;
  audioDataUrl?: string;
  audioUrl?: string;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  gifUrl?: string;
  stickerUrl?: string;
  poll?: ChatPoll;
  error?: string;
} {
  const input: ExtendedMessagePayloadInput =
    typeof textOrInput === 'string'
      ? {
          text: textOrInput,
          imageDataUrl: imageDataUrlArg,
          audioDataUrl: audioDataUrlArg,
          poll: pollInputArg,
        }
      : textOrInput;

  const trimmedText = (input.text ?? '').trim();
  const hasImageData = Boolean(input.imageDataUrl?.trim());
  const hasImageUrl = Boolean(input.imageUrl?.trim());
  const hasVideoUrl = Boolean(input.videoUrl?.trim());
  const hasAudioData = Boolean(input.audioDataUrl?.trim());
  const hasAudioUrl = Boolean(input.audioUrl?.trim());
  const hasFileUrl = Boolean(input.fileUrl?.trim());
  const hasGifUrl = Boolean(input.gifUrl?.trim());
  const hasStickerUrl = Boolean(input.stickerUrl?.trim());
  const hasPoll = Boolean(input.poll);

  if (
    !trimmedText &&
    !hasImageData &&
    !hasImageUrl &&
    !hasVideoUrl &&
    !hasAudioData &&
    !hasAudioUrl &&
    !hasFileUrl &&
    !hasGifUrl &&
    !hasStickerUrl &&
    !hasPoll
  ) {
    return {
      valid: false,
      text: '',
      error: 'Message cannot be empty.',
    };
  }

  if (trimmedText.length > MAX_MESSAGE_TEXT_LENGTH) {
    return {
      valid: false,
      text: trimmedText,
      error: `Message exceeds ${MAX_MESSAGE_TEXT_LENGTH} characters.`,
    };
  }

  if (hasImageData && input.imageDataUrl) {
    if (!input.imageDataUrl.startsWith('data:image/')) {
      return { valid: false, text: trimmedText, error: 'Invalid image format.' };
    }
    if (input.imageDataUrl.length > MAX_MEDIA_DATA_URL_LENGTH) {
      return {
        valid: false,
        text: trimmedText,
        error: 'Image is too large. Please choose a smaller photo.',
      };
    }
  }

  if (hasAudioData && input.audioDataUrl) {
    if (!input.audioDataUrl.startsWith('data:audio/')) {
      return { valid: false, text: trimmedText, error: 'Invalid voice message format.' };
    }
    if (input.audioDataUrl.length > MAX_MEDIA_DATA_URL_LENGTH) {
      return {
        valid: false,
        text: trimmedText,
        error: 'Voice note is too long.',
      };
    }
  }

  const remoteUrls = [
    input.imageUrl,
    input.videoUrl,
    input.audioUrl,
    input.fileUrl,
    input.gifUrl,
    input.stickerUrl,
  ];
  for (const url of remoteUrls) {
    if (url && !isSafeMediaUrl(url)) {
      return {
        valid: false,
        text: trimmedText,
        error: 'Invalid media attachment URL.',
      };
    }
  }

  let validatedPoll: ChatPoll | undefined;
  if (input.poll) {
    const pollResult = validatePollInput(input.poll.question, input.poll.options);
    if (!pollResult.valid || !pollResult.poll) {
      return {
        valid: false,
        text: trimmedText,
        error: pollResult.error || 'Invalid poll.',
      };
    }
    validatedPoll = pollResult.poll;
  }

  return {
    valid: true,
    text: trimmedText,
    imageDataUrl: hasImageData ? input.imageDataUrl : undefined,
    imageUrl: hasImageUrl ? input.imageUrl?.trim() : undefined,
    videoUrl: hasVideoUrl ? input.videoUrl?.trim() : undefined,
    audioDataUrl: hasAudioData ? input.audioDataUrl : undefined,
    audioUrl: hasAudioUrl ? input.audioUrl?.trim() : undefined,
    fileUrl: hasFileUrl ? input.fileUrl?.trim() : undefined,
    fileName: input.fileName?.trim().slice(0, 140),
    fileSize: typeof input.fileSize === 'number' ? input.fileSize : undefined,
    fileMime: input.fileMime?.trim().slice(0, 120),
    gifUrl: hasGifUrl ? input.gifUrl?.trim() : undefined,
    stickerUrl: hasStickerUrl ? input.stickerUrl?.trim() : undefined,
    poll: validatedPoll,
  };
}

export function canSendUnderSlowMode(
  lastSentAt: number,
  now: number,
  slowModeSec: number,
  isAdmin: boolean
): { allowed: boolean; waitSec: number } {
  if (isAdmin || slowModeSec <= 0 || lastSentAt <= 0) {
    return { allowed: true, waitSec: 0 };
  }
  const elapsedMs = now - lastSentAt;
  const requiredMs = slowModeSec * 1000;
  if (elapsedMs >= requiredMs) {
    return { allowed: true, waitSec: 0 };
  }
  return {
    allowed: false,
    waitSec: Math.ceil((requiredMs - elapsedMs) / 1000),
  };
}

export function filterMessages(
  messages: ChatMessage[],
  query: string
): ChatMessage[] {
  const q = query.trim().toLowerCase();
  if (!q) return messages;
  return messages.filter((msg) => {
    if (msg.text.toLowerCase().includes(q)) return true;
    if (msg.senderName.toLowerCase().includes(q)) return true;
    if (msg.poll?.question.toLowerCase().includes(q)) return true;
    if (msg.fileName?.toLowerCase().includes(q)) return true;
    return false;
  });
}

export function canDeleteForEveryone(
  message: ChatMessage,
  clientId: string,
  isAdmin: boolean
): boolean {
  if (message.type !== 'user') return false;
  if (isAdmin) return true;
  return Boolean(clientId) && message.senderId === clientId;
}

export function canEditMessage(message: ChatMessage, clientId: string): boolean {
  if (message.type !== 'user') return false;
  if (!clientId || message.senderId !== clientId) return false;
  return Boolean(message.text && message.text.trim().length > 0);
}

export function canForwardMessage(message: ChatMessage): boolean {
  return message.type === 'user';
}

export function filterHiddenMessages(
  messages: ChatMessage[],
  hiddenIds: string[]
): ChatMessage[] {
  if (!hiddenIds || hiddenIds.length === 0) return messages;
  const hiddenSet = new Set(hiddenIds);
  return messages.filter((msg) => !hiddenSet.has(msg.id));
}

export function toggleReactionMap(
  reactions: Record<string, string[]>,
  emoji: string,
  clientId: string
): Record<string, string[]> {
  if (!emoji || !clientId) return reactions;
  const next: Record<string, string[]> = { ...reactions };
  const currentUsers = Array.isArray(next[emoji]) ? [...next[emoji]] : [];
  const idx = currentUsers.indexOf(clientId);

  if (idx >= 0) {
    currentUsers.splice(idx, 1);
  } else {
    currentUsers.push(clientId);
  }

  if (currentUsers.length === 0) {
    delete next[emoji];
  } else {
    next[emoji] = currentUsers;
  }

  return next;
}

export function dedupeAppendMessage(
  messages: ChatMessage[],
  incoming: ChatMessage,
  maxMessages = 300
): ChatMessage[] {
  const exists = messages.some((m) => m.id === incoming.id);
  if (exists) {
    return messages;
  }
  const next = [...messages, incoming];
  if (next.length > maxMessages) {
    return next.slice(next.length - maxMessages);
  }
  return next;
}

export function formatTime(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDuration(seconds: number): string {
  const clean = Math.max(0, Math.round(seconds));
  const mins = Math.floor(clean / 60);
  const secs = clean % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatFileSize(bytes?: number): string {
  if (!bytes || bytes <= 0) return '0 KB';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}

export function normalizeServerWsUrl(rawServer: string): string | null {
  const trimmed = rawServer.trim();
  if (!trimmed) return null;

  let candidate = trimmed;
  if (!/^(https?|wss?):\/\//i.test(candidate)) {
    candidate = `wss://${candidate}`;
  }

  try {
    const parsed = new URL(candidate);
    if (parsed.protocol === 'http:') {
      parsed.protocol = 'ws:';
    } else if (parsed.protocol === 'https:') {
      parsed.protocol = 'wss:';
    } else if (parsed.protocol !== 'ws:' && parsed.protocol !== 'wss:') {
      return null;
    }

    if (!parsed.pathname || parsed.pathname === '/') {
      parsed.pathname = '/ws';
    }
    parsed.search = '';
    parsed.hash = '';
    return parsed.toString();
  } catch {
    return null;
  }
}

export function resolveWebSocketUrl(
  locationProtocol: string,
  locationHost: string,
  search: string,
  envWsUrl?: string,
  storedServerUrl?: string | null
): string {
  try {
    const params = new URLSearchParams(search);
    const paramServer = params.get('server');
    if (paramServer) {
      const normalized = normalizeServerWsUrl(paramServer);
      if (normalized) return normalized;
    }
  } catch {
    // Ignore malformed query string
  }

  if (storedServerUrl) {
    const normalized = normalizeServerWsUrl(storedServerUrl);
    if (normalized) return normalized;
  }

  if (envWsUrl) {
    const normalized = normalizeServerWsUrl(envWsUrl);
    if (normalized) return normalized;
  }

  const wsProtocol = locationProtocol === 'https:' ? 'wss:' : 'ws:';
  return `${wsProtocol}//${locationHost}/ws`;
}

export function shouldInitiatePeerOffer(
  localClientId: string,
  remoteClientId: string
): boolean {
  if (!localClientId || !remoteClientId || localClientId === remoteClientId) {
    return false;
  }
  return localClientId < remoteClientId;
}

function sanitizeRoomSegment(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 56);
}

export function getDirectRoomId(clientA: string, clientB: string): string {
  const a = sanitizeRoomSegment(clientA);
  const b = sanitizeRoomSegment(clientB);
  const [first, second] = a <= b ? [a, b] : [b, a];
  return `dm__${first}__${second}`;
}

export function isDirectRoomId(roomId: string): boolean {
  return /^dm__[a-zA-Z0-9_-]+__[a-zA-Z0-9_-]+$/.test(roomId);
}

export function getGroupRoomId(rawSlug: string): string {
  const clean = sanitizeRoomSegment(rawSlug);
  return clean.startsWith('grp__') ? clean : `grp__${clean}`;
}

export function isGroupRoomId(roomId: string): boolean {
  return /^grp__[a-zA-Z0-9_-]+$/.test(roomId);
}

export function getPeerIdFromDirectRoom(
  dmRoomId: string,
  myClientId: string
): string | null {
  if (!isDirectRoomId(dmRoomId)) return null;
  const parts = dmRoomId.split('__');
  if (parts.length !== 3) return null;
  const myClean = sanitizeRoomSegment(myClientId);
  if (parts[1] === myClean) return parts[2];
  if (parts[2] === myClean) return parts[1];
  return null;
}

export function getLatestReadableMessage(
  messages: ChatMessage[]
): ChatMessage | null {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.type === 'user') {
      return messages[i];
    }
  }
  return null;
}

export function shouldMarkMessageRead(
  lastWrittenAt: number,
  lastWrittenMsgId: string | null,
  latestMessage: ChatMessage | null,
  isRoomVisible: boolean,
  isAtBottom: boolean
): boolean {
  if (!isRoomVisible || !isAtBottom || !latestMessage) return false;
  if (latestMessage.type !== 'user') return false;
  if (latestMessage.createdAt > lastWrittenAt) return true;
  if (
    latestMessage.createdAt === lastWrittenAt &&
    latestMessage.id !== lastWrittenMsgId
  ) {
    return true;
  }
  return false;
}

export function getMessageReaders(
  message: ChatMessage,
  receipts: ReadReceipt[],
  currentClientId: string
): ReadReceipt[] {
  if (message.type !== 'user') return [];
  return receipts
    .filter(
      (r) =>
        r.clientId !== currentClientId &&
        r.clientId !== message.senderId &&
        r.lastReadAt >= message.createdAt
    )
    .sort((a, b) => a.nickname.localeCompare(b.nickname));
}

export function getLatestSeenByMessageMap(
  messages: ChatMessage[],
  receipts: ReadReceipt[],
  currentClientId: string
): Record<string, ReadReceipt[]> {
  const result: Record<string, ReadReceipt[]> = {};
  const userMessages = messages.filter((m) => m.type === 'user');
  if (userMessages.length === 0) return result;

  for (const receipt of receipts) {
    if (receipt.clientId === currentClientId) continue;

    let latestSeenMsg: ChatMessage | null = null;
    for (let i = userMessages.length - 1; i >= 0; i -= 1) {
      const m = userMessages[i];
      if (m.createdAt <= receipt.lastReadAt) {
        latestSeenMsg = m;
        break;
      }
    }

    if (latestSeenMsg && latestSeenMsg.senderId !== receipt.clientId) {
      if (!result[latestSeenMsg.id]) {
        result[latestSeenMsg.id] = [];
      }
      result[latestSeenMsg.id].push(receipt);
    }
  }

  for (const key of Object.keys(result)) {
    result[key].sort((a, b) => a.nickname.localeCompare(b.nickname));
  }

  return result;
}

export function canViewProfileField(
  audience: PrivacyAudience | undefined,
  targetUserId: string,
  viewerId: string,
  isBlockedRelation: boolean,
  isContact = true
): boolean {
  if (viewerId === targetUserId) return true;
  if (isBlockedRelation) return false;
  const resolved = audience || 'everyone';
  if (resolved === 'nobody') return false;
  if (resolved === 'contacts') return isContact;
  return true;
}

export function formatLastSeen(
  lastSeenAt: number,
  online: boolean,
  canView: boolean,
  now = Date.now(),
  lang: 'en' | 'bn' = 'en'
): string {
  if (!canView) return lang === 'bn' ? 'লুকানো' : 'Hidden';
  if (online) return lang === 'bn' ? 'অনলাইন' : 'Online';
  if (!lastSeenAt || lastSeenAt <= 0) {
    return lang === 'bn' ? 'অফলাইন' : 'Offline';
  }
  const diffSec = Math.max(0, Math.floor((now - lastSeenAt) / 1000));
  if (diffSec < 60) return lang === 'bn' ? 'এইমাত্র দেখা গেছে' : 'Last seen just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) {
    return lang === 'bn'
      ? `${diffMin} মিনিট আগে`
      : `Last seen ${diffMin}m ago`;
  }
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) {
    return lang === 'bn'
      ? `${diffHr} ঘণ্টা আগে`
      : `Last seen ${diffHr}h ago`;
  }
  const dateStr = new Date(lastSeenAt).toLocaleDateString();
  return lang === 'bn' ? `সর্বশেষ ${dateStr}` : `Last seen ${dateStr}`;
}

export const STORY_TTL_MS = 24 * 60 * 60 * 1000;

export function isStoryActive(story: StoryStatus, now = Date.now()): boolean {
  return story.expiresAt > now;
}

export function canViewStory(
  story: StoryStatus,
  viewerId: string,
  isBlockedRelation: boolean,
  isContact = true,
  now = Date.now()
): boolean {
  if (!isStoryActive(story, now)) return false;
  if (story.authorId === viewerId) return true;
  if (isBlockedRelation) return false;
  if (story.excludedViewerIds?.includes(viewerId)) return false;

  switch (story.privacy) {
    case 'only_me':
      return false;
    case 'contacts':
      return isContact;
    case 'custom':
      return Boolean(story.allowedViewerIds?.includes(viewerId));
    case 'everyone':
    default:
      return true;
  }
}

export function isGroupAdmin(group: ChatGroup | null | undefined, clientId: string): boolean {
  if (!group || !clientId) return false;
  return group.createdBy === clientId || group.adminIds.includes(clientId);
}

export function canManageGroupMembers(
  group: ChatGroup | null | undefined,
  clientId: string,
  isGlobalHost = false
): boolean {
  if (isGlobalHost) return true;
  return isGroupAdmin(group, clientId);
}

export function canManageGroupSettings(
  group: ChatGroup | null | undefined,
  clientId: string,
  isGlobalHost = false
): boolean {
  if (isGlobalHost) return true;
  return isGroupAdmin(group, clientId);
}

export function shouldNotifyForMessage(params: {
  message: ChatMessage;
  viewerId: string;
  roomId: string;
  mutedRoomIds: string[];
  blockedPeerIds: string[];
  soundEnabled: boolean;
}): { playSound: boolean; showBrowserNotification: boolean } {
  const { message, viewerId, roomId, mutedRoomIds, blockedPeerIds, soundEnabled } =
    params;
  if (message.type !== 'user') {
    return { playSound: false, showBrowserNotification: false };
  }
  if (message.senderId === viewerId) {
    return { playSound: false, showBrowserNotification: false };
  }
  if (blockedPeerIds.includes(message.senderId)) {
    return { playSound: false, showBrowserNotification: false };
  }
  if (mutedRoomIds.includes(roomId)) {
    return { playSound: false, showBrowserNotification: false };
  }
  return {
    playSound: soundEnabled,
    showBrowserNotification: true,
  };
}

export function pushRecentItem(list: string[], item: string, maxItems = 18): string[] {
  if (!item) return list;
  const filtered = list.filter((x) => x !== item);
  return [item, ...filtered].slice(0, maxItems);
}

export function isSelfOrHostTarget(params: {
  targetClientId?: string | null;
  targetNickname?: string | null;
  targetPhoneNumber?: string | null;
  selfClientId: string;
  selfNickname?: string | null;
  selfPhoneNumber?: string | null;
  hostUsers?: Array<{
    clientId: string;
    nickname?: string | null;
    displayName?: string | null;
    isAdmin?: boolean;
  }>;
}): boolean {
  const targetId = (params.targetClientId || '').trim();
  const rawNick = (params.targetNickname || '').trim();
  const targetNickKey = normalizeNicknameKey(rawNick);
  const rawPhoneCheck = params.targetPhoneNumber
    ? validateBangladeshPhone(params.targetPhoneNumber)
    : rawNick
      ? validateBangladeshPhone(rawNick)
      : { valid: false, normalized: '' };
  const targetPhone = rawPhoneCheck.valid ? rawPhoneCheck.normalized : '';

  if (targetId && targetId === params.selfClientId) return true;
  if (
    targetNickKey &&
    params.selfNickname &&
    targetNickKey === normalizeNicknameKey(params.selfNickname)
  ) {
    return true;
  }
  if (targetPhone && params.selfPhoneNumber) {
    const selfPhoneCheck = validateBangladeshPhone(params.selfPhoneNumber);
    if (selfPhoneCheck.valid && selfPhoneCheck.normalized === targetPhone) {
      return true;
    }
  }

  for (const host of params.hostUsers || []) {
    if (!host.isAdmin) continue;
    if (targetId && host.clientId === targetId) return true;
    const hostName = host.nickname || host.displayName || '';
    if (targetNickKey && hostName && normalizeNicknameKey(hostName) === targetNickKey) {
      return true;
    }
  }

  return false;
}

export function isDirectRoomParticipant(roomId: string, clientId: string): boolean {
  if (!isDirectRoomId(roomId) || !clientId) return false;
  const parts = roomId.slice(4).split('__');
  return parts.includes(clientId);
}

export function canAccessRoom(params: {
  roomId: string;
  clientId: string;
  isAdmin: boolean;
  group?: ChatGroup | null;
}): boolean {
  const { roomId, clientId, isAdmin, group } = params;
  if (!roomId || !clientId) return false;
  if (isAdmin) return true;
  if (roomId === 'main') return true;
  if (isDirectRoomId(roomId)) {
    return isDirectRoomParticipant(roomId, clientId);
  }
  if (isGroupRoomId(roomId)) {
    return Boolean(
      group && (group.createdBy === clientId || group.memberIds.includes(clientId))
    );
  }
  return false;
}

export function canDeleteContact(params: {
  targetClientId: string;
  selfClientId: string;
  isAdmin: boolean;
}): boolean {
  const { targetClientId, selfClientId, isAdmin } = params;
  if (!isAdmin || !targetClientId) return false;
  return targetClientId !== selfClientId;
}

export function filterExpiredMessages(
  messages: ChatMessage[],
  disappearingHours: number | undefined,
  now = Date.now()
): ChatMessage[] {
  if (!disappearingHours || disappearingHours <= 0) return messages;
  const cutoff = now - disappearingHours * 3600 * 1000;
  return messages.filter((m) => m.createdAt >= cutoff);
}
