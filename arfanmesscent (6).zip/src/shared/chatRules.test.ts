import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CALL_AVATAR_PRESETS,
  STORY_TTL_MS,
  THEME_SPECS,
  WALLPAPER_PRESETS,
  canAccessRoom,
  canDeleteContact,
  canDeleteForEveryone,
  canEditMessage,
  canForwardMessage,
  canManageGroupMembers,
  canManageGroupSettings,
  canSendUnderSlowMode,
  canViewProfileField,
  canViewStory,
  dedupeAppendMessage,
  filterExpiredMessages,
  filterHiddenMessages,
  filterMessages,
  formatBdPhoneDisplay,
  formatDuration,
  formatFileSize,
  formatLastSeen,
  generateGuestNickname,
  getDirectRoomId,
  getGroupRoomId,
  getInitials,
  getLatestReadableMessage,
  getLatestSeenByMessageMap,
  getMessageReaders,
  getPeerIdFromDirectRoom,
  isDirectRoomId,
  isDirectRoomParticipant,
  isGroupAdmin,
  isGroupRoomId,
  isSafeMediaUrl,
  isSelfOrHostTarget,
  isStoryActive,
  isUserBlocked,
  isValidThemeId,
  pushRecentItem,
  resolveTheme,
  resolveWebSocketUrl,
  sanitizeNickname,
  sanitizeUsername,
  shouldInitiatePeerOffer,
  shouldMarkMessageRead,
  shouldNotifyForMessage,
  togglePollVote,
  toggleReactionMap,
  validateBangladeshPhone,
  validateMessagePayload,
} from './chatRules';
import type {
  ChatGroup,
  ChatMessage,
  ChatPoll,
  ReadReceipt,
  StoryStatus,
} from './types';

test('sanitizeNickname validates length and collapses extra spaces', () => {
  assert.equal(sanitizeNickname(' A ').valid, false);
  assert.equal(sanitizeNickname('   Arfan   Khan  ').nickname, 'Arfan Khan');
  assert.equal(sanitizeNickname('   Arfan   Khan  ').valid, true);
  assert.equal(sanitizeNickname('A'.repeat(30)).valid, false);
});

test('sanitizeUsername validates handles cleanly', () => {
  assert.equal(sanitizeUsername('@Arfan_01').username, 'arfan_01');
  assert.equal(sanitizeUsername('@Arfan_01').valid, true);
  assert.equal(sanitizeUsername('').valid, true);
  assert.equal(sanitizeUsername('ab').valid, false);
  assert.equal(sanitizeUsername('bad name!').valid, false);
});

test('generateGuestNickname produces deterministic or random Guest- prefix', () => {
  assert.equal(generateGuestNickname('abc9912'), 'Guest-9912');
  assert.match(generateGuestNickname(), /^Guest-\d{4}$/);
});

test('validateBangladeshPhone normalizes valid BD numbers and rejects invalid ones', () => {
  const p1 = validateBangladeshPhone('01712345678');
  assert.equal(p1.valid, true);
  assert.equal(p1.normalized, '01712345678');
  assert.equal(p1.display, '+88 01712-345678');

  const p2 = validateBangladeshPhone('+880 1812-345678');
  assert.equal(p2.valid, true);
  assert.equal(p2.normalized, '01812345678');

  const p3 = validateBangladeshPhone('8801911223344');
  assert.equal(p3.valid, true);
  assert.equal(p3.normalized, '01911223344');

  assert.equal(formatBdPhoneDisplay('01712345678'), '+88 01712-345678');

  assert.equal(validateBangladeshPhone('01212345678').valid, false);
  assert.equal(validateBangladeshPhone('0171234').valid, false);
  assert.equal(validateBangladeshPhone('12345').valid, false);
  assert.equal(validateBangladeshPhone('abcdefghijk').valid, false);
});

test('isUserBlocked matches by clientId, case-insensitive nickname, or normalized BD phoneNumber', () => {
  const blocked = [
    {
      clientId: 'user-123',
      nickname: 'Spammer',
      phoneNumber: '01799887766',
      blockedAt: 1000,
    },
  ];
  assert.equal(isUserBlocked(blocked, 'user-123', 'SomeoneElse'), true);
  assert.equal(isUserBlocked(blocked, 'other-id', '  spammer '), true);
  assert.equal(
    isUserBlocked(blocked, 'fresh-id', 'FreshName', '+8801799887766'),
    true
  );
  assert.equal(
    isUserBlocked(blocked, 'other-id', 'Arfan', '01811223344'),
    false
  );
});

test('validateMessagePayload accepts text, legacy data URLs, Firebase Storage URLs, videos, files, GIFs, stickers, and rejects unsafe URLs', () => {
  assert.equal(validateMessagePayload('   ').valid, false);
  assert.equal(validateMessagePayload('Hello!').valid, true);
  assert.equal(
    validateMessagePayload('', 'data:image/jpeg;base64,abc123').valid,
    true
  );
  assert.equal(
    validateMessagePayload('', undefined, 'data:audio/webm;base64,xyz').valid,
    true
  );
  assert.equal(
    validateMessagePayload({
      text: '',
      videoUrl: 'https://firebasestorage.googleapis.com/v0/b/demo/o/clip.mp4',
    }).valid,
    true
  );
  assert.equal(
    validateMessagePayload({
      text: '',
      fileUrl: '/api/media/doc-123.pdf',
      fileName: 'notes.pdf',
      fileSize: 2048,
    }).valid,
    true
  );
  assert.equal(
    validateMessagePayload({
      text: '',
      gifUrl: '/api/gifs/asset/party',
    }).valid,
    true
  );
  assert.equal(
    validateMessagePayload({
      text: '',
      gifUrl: 'javascript:alert(1)',
    }).valid,
    false
  );
  assert.equal(
    validateMessagePayload('', undefined, undefined, {
      question: 'Where to eat?',
      options: ['Biryani', 'Pizza'],
    }).valid,
    true
  );
});

test('togglePollVote switches and toggles votes cleanly per user', () => {
  const poll: ChatPoll = {
    question: 'Best time?',
    options: [
      { id: 'opt-1', label: '8 PM', voterIds: [] },
      { id: 'opt-2', label: '9 PM', voterIds: [] },
    ],
  };

  const v1 = togglePollVote(poll, 'opt-1', 'u1');
  assert.deepEqual(v1.options[0].voterIds, ['u1']);
  assert.deepEqual(v1.options[1].voterIds, []);

  const v2 = togglePollVote(v1, 'opt-2', 'u1');
  assert.deepEqual(v2.options[0].voterIds, []);
  assert.deepEqual(v2.options[1].voterIds, ['u1']);

  const v3 = togglePollVote(v2, 'opt-2', 'u1');
  assert.deepEqual(v3.options[1].voterIds, []);
});

test('canSendUnderSlowMode enforces cooldown for members and bypasses for admin', () => {
  assert.deepEqual(canSendUnderSlowMode(1000, 3000, 5, false), {
    allowed: false,
    waitSec: 3,
  });
  assert.deepEqual(canSendUnderSlowMode(1000, 6000, 5, false), {
    allowed: true,
    waitSec: 0,
  });
  assert.deepEqual(canSendUnderSlowMode(1000, 1500, 5, true), {
    allowed: true,
    waitSec: 0,
  });
});

test('filterMessages matches text, senderName, poll question, or fileName', () => {
  const msgs: ChatMessage[] = [
    {
      id: '1',
      type: 'user',
      senderId: 'u1',
      senderName: 'Arfan',
      senderColor: '#7C3AED',
      text: 'Meet at 8pm',
      reactions: {},
      createdAt: 1000,
    },
    {
      id: '2',
      type: 'user',
      senderId: 'u2',
      senderName: 'Rafi',
      senderColor: '#EC4899',
      text: 'Okay!',
      fileName: 'schedule.pdf',
      reactions: {},
      createdAt: 2000,
    },
  ];
  assert.equal(filterMessages(msgs, 'rafi').length, 1);
  assert.equal(filterMessages(msgs, '8pm').length, 1);
  assert.equal(filterMessages(msgs, 'schedule').length, 1);
  assert.equal(filterMessages(msgs, '').length, 2);
});

test('toggleReactionMap adds and removes reactions idempotently', () => {
  const step1 = toggleReactionMap({}, '❤️', 'u1');
  assert.deepEqual(step1, { '❤️': ['u1'] });
  const step2 = toggleReactionMap(step1, '❤️', 'u2');
  assert.deepEqual(step2, { '❤️': ['u1', 'u2'] });
  const step3 = toggleReactionMap(step2, '❤️', 'u1');
  assert.deepEqual(step3, { '❤️': ['u2'] });
  const step4 = toggleReactionMap(step3, '❤️', 'u2');
  assert.deepEqual(step4, {});
});

test('dedupeAppendMessage prevents duplicate message IDs on reconnect', () => {
  const msg1: ChatMessage = {
    id: 'm1',
    type: 'user',
    senderId: 'u1',
    senderName: 'Arfan',
    senderColor: '#7C3AED',
    text: 'Hi',
    reactions: {},
    createdAt: 1000,
  };
  const first = dedupeAppendMessage([], msg1);
  const second = dedupeAppendMessage(first, msg1);
  assert.equal(second.length, 1);
});

test('resolveTheme falls back safely to midnight-violet', () => {
  assert.equal(resolveTheme('unknown-theme').id, 'midnight-violet');
  assert.equal(resolveTheme('clean-daylight').isDark, false);
});

test('formatDuration, formatFileSize, and getInitials format cleanly', () => {
  assert.equal(formatDuration(65), '1:05');
  assert.equal(formatFileSize(512), '512 B');
  assert.equal(formatFileSize(1536), '1.5 KB');
  assert.equal(formatFileSize(2 * 1024 * 1024), '2.0 MB');
  assert.equal(getInitials('Arfan'), 'AR');
  assert.equal(getInitials('Arfan Khan'), 'AK');
});

test('canDeleteForEveryone, canEditMessage, and canForwardMessage enforce ownership', () => {
  const userMsg: ChatMessage = {
    id: 'm-1',
    type: 'user',
    senderId: 'u-sender',
    senderName: 'Arfan',
    senderColor: '#7C3AED',
    text: 'Hello',
    reactions: {},
    createdAt: 1000,
  };
  const systemMsg: ChatMessage = {
    id: 'sys-1',
    type: 'system',
    senderId: 'system',
    senderName: 'ARFANMesscent',
    senderColor: '#7C3AED',
    text: 'Joined',
    reactions: {},
    createdAt: 1000,
  };

  assert.equal(canDeleteForEveryone(userMsg, 'u-sender', false), true);
  assert.equal(canDeleteForEveryone(userMsg, 'u-other', false), false);
  assert.equal(canDeleteForEveryone(userMsg, 'u-other', true), true);
  assert.equal(canDeleteForEveryone(systemMsg, 'u-sender', true), false);

  assert.equal(canEditMessage(userMsg, 'u-sender'), true);
  assert.equal(canEditMessage(userMsg, 'u-other'), false);
  assert.equal(canEditMessage(systemMsg, 'u-sender'), false);

  assert.equal(canForwardMessage(userMsg), true);
  assert.equal(canForwardMessage(systemMsg), false);
});

test('filterHiddenMessages hides only locally deleted message IDs', () => {
  const msgs: ChatMessage[] = [
    {
      id: 'm1',
      type: 'user',
      senderId: 'u1',
      senderName: 'Arfan',
      senderColor: '#7C3AED',
      text: 'One',
      reactions: {},
      createdAt: 1000,
    },
    {
      id: 'm2',
      type: 'user',
      senderId: 'u2',
      senderName: 'Guest-1234',
      senderColor: '#EC4899',
      text: 'Two',
      reactions: {},
      createdAt: 2000,
    },
  ];

  const remaining = filterHiddenMessages(msgs, ['m2']);
  assert.equal(remaining.length, 1);
  assert.equal(remaining[0].id, 'm1');
  assert.equal(filterHiddenMessages(msgs, []).length, 2);
});

test('resolveWebSocketUrl prioritizes ?server= query param, then stored, env, and same-origin', () => {
  assert.equal(
    resolveWebSocketUrl(
      'https:',
      'demo.netlify.app',
      '?invite=1&server=https://chat.onrender.com'
    ),
    'wss://chat.onrender.com/ws'
  );
  assert.equal(
    resolveWebSocketUrl(
      'https:',
      'demo.netlify.app',
      '',
      'https://env.example.com',
      'http://stored.example.com:3000'
    ),
    'ws://stored.example.com:3000/ws'
  );
  assert.equal(
    resolveWebSocketUrl(
      'https:',
      'demo.netlify.app',
      '',
      'https://env.example.com',
      null
    ),
    'wss://env.example.com/ws'
  );
  assert.equal(
    resolveWebSocketUrl('http:', 'localhost:3000', '?invite=1'),
    'ws://localhost:3000/ws'
  );
});

test('shouldInitiatePeerOffer establishes asymmetric glare-free offer side', () => {
  assert.equal(shouldInitiatePeerOffer('u-a', 'u-b'), true);
  assert.equal(shouldInitiatePeerOffer('u-b', 'u-a'), false);
  assert.equal(shouldInitiatePeerOffer('u-a', 'u-a'), false);
  assert.equal(shouldInitiatePeerOffer('', 'u-b'), false);
});

test('getDirectRoomId and getGroupRoomId produce canonical room IDs', () => {
  const r1 = getDirectRoomId('u-alice-1', 'u-bob-2');
  const r2 = getDirectRoomId('u-bob-2', 'u-alice-1');
  assert.equal(r1, r2);
  assert.equal(isDirectRoomId(r1), true);
  assert.equal(isDirectRoomId('main'), false);
  assert.equal(getPeerIdFromDirectRoom(r1, 'u-alice-1'), 'u-bob-2');
  assert.equal(getPeerIdFromDirectRoom(r1, 'u-bob-2'), 'u-alice-1');

  const g1 = getGroupRoomId('study-squad');
  assert.equal(g1, 'grp__study-squad');
  assert.equal(isGroupRoomId(g1), true);
  assert.equal(isGroupRoomId('main'), false);
});

test('getLatestReadableMessage skips system notices and returns latest user message', () => {
  const msgs: ChatMessage[] = [
    {
      id: 'm1',
      type: 'user',
      senderId: 'u1',
      senderName: 'Alice',
      senderColor: '#7C3AED',
      text: 'Hello',
      reactions: {},
      createdAt: 1000,
    },
    {
      id: 'sys-1',
      type: 'system',
      senderId: 'system',
      senderName: 'ARFANMesscent',
      senderColor: '#7C3AED',
      text: 'Joined',
      reactions: {},
      createdAt: 2000,
    },
  ];
  assert.equal(getLatestReadableMessage(msgs)?.id, 'm1');
  assert.equal(getLatestReadableMessage([msgs[1]]), null);
});

test('shouldMarkMessageRead triggers only when visible, at bottom, and monotonic', () => {
  const latest: ChatMessage = {
    id: 'm2',
    type: 'user',
    senderId: 'u1',
    senderName: 'Alice',
    senderColor: '#7C3AED',
    text: 'Hey',
    reactions: {},
    createdAt: 2000,
  };

  assert.equal(shouldMarkMessageRead(1000, 'm1', latest, true, true), true);
  assert.equal(shouldMarkMessageRead(2000, 'm2', latest, true, true), false);
  assert.equal(shouldMarkMessageRead(1000, 'm1', latest, false, true), false);
  assert.equal(shouldMarkMessageRead(1000, 'm1', latest, true, false), false);
});

test('getMessageReaders and getLatestSeenByMessageMap compute recipients cleanly', () => {
  const m1: ChatMessage = {
    id: 'm1',
    type: 'user',
    senderId: 'u-alice',
    senderName: 'Alice',
    senderColor: '#7C3AED',
    text: 'First',
    reactions: {},
    createdAt: 1000,
  };
  const m2: ChatMessage = {
    id: 'm2',
    type: 'user',
    senderId: 'u-alice',
    senderName: 'Alice',
    senderColor: '#7C3AED',
    text: 'Second',
    reactions: {},
    createdAt: 2000,
  };

  const receipts: ReadReceipt[] = [
    {
      clientId: 'u-alice',
      nickname: 'Alice',
      avatarColor: '#7C3AED',
      lastReadMessageId: 'm2',
      lastReadAt: 2000,
      updatedAt: 2000,
    },
    {
      clientId: 'u-bob',
      nickname: 'Bob',
      avatarColor: '#10B981',
      lastReadMessageId: 'm1',
      lastReadAt: 1000,
      updatedAt: 1500,
    },
    {
      clientId: 'u-carol',
      nickname: 'Carol',
      avatarColor: '#EC4899',
      lastReadMessageId: 'm2',
      lastReadAt: 2000,
      updatedAt: 2100,
    },
  ];

  assert.deepEqual(
    getMessageReaders(m1, receipts, 'u-alice').map((r) => r.nickname),
    ['Bob', 'Carol']
  );
  assert.deepEqual(
    getMessageReaders(m2, receipts, 'u-alice').map((r) => r.nickname),
    ['Carol']
  );

  const latestMap = getLatestSeenByMessageMap([m1, m2], receipts, 'u-alice');
  assert.deepEqual(
    latestMap.m1.map((r) => r.nickname),
    ['Bob']
  );
  assert.deepEqual(
    latestMap.m2.map((r) => r.nickname),
    ['Carol']
  );
});

test('canViewProfileField and formatLastSeen respect privacy settings and self access', () => {
  assert.equal(canViewProfileField('nobody', 'u1', 'u1', false), true);
  assert.equal(canViewProfileField('nobody', 'u1', 'u2', false), false);
  assert.equal(canViewProfileField('everyone', 'u1', 'u2', true), false);
  assert.equal(canViewProfileField('contacts', 'u1', 'u2', false, false), false);
  assert.equal(canViewProfileField('contacts', 'u1', 'u2', false, true), true);

  assert.equal(formatLastSeen(1000, true, false), 'Hidden');
  assert.equal(formatLastSeen(1000, true, true), 'Online');
  assert.equal(formatLastSeen(50_000, false, true, 170_000), 'Last seen 2m ago');
});

test('isStoryActive and canViewStory enforce 24h expiration and privacy rules', () => {
  const baseTime = 1_700_000_000_000;
  const story: StoryStatus = {
    id: 'st-1',
    authorId: 'u-author',
    authorName: 'Arfan',
    authorColor: '#7C3AED',
    type: 'text',
    text: 'Good morning!',
    privacy: 'custom',
    allowedViewerIds: ['u-friend'],
    excludedViewerIds: ['u-hidden'],
    viewers: [],
    createdAt: baseTime,
    expiresAt: baseTime + STORY_TTL_MS,
  };

  assert.equal(isStoryActive(story, baseTime + 1000), true);
  assert.equal(isStoryActive(story, baseTime + STORY_TTL_MS + 1), false);

  assert.equal(canViewStory(story, 'u-author', false, true, baseTime + 1000), true);
  assert.equal(canViewStory(story, 'u-friend', false, true, baseTime + 1000), true);
  assert.equal(canViewStory(story, 'u-stranger', false, true, baseTime + 1000), false);
  assert.equal(canViewStory(story, 'u-friend', true, true, baseTime + 1000), false);
  assert.equal(canViewStory(story, 'u-friend', false, true, baseTime + STORY_TTL_MS + 5), false);
});

test('group permissions restrict member and settings management to group admins or host', () => {
  const grp: ChatGroup = {
    id: 'grp__friends',
    name: 'Weekend Crew',
    description: 'Plans',
    avatarColor: '#7C3AED',
    createdBy: 'u-creator',
    adminIds: ['u-creator', 'u-mod'],
    memberIds: ['u-creator', 'u-mod', 'u-member'],
    createdAt: 1000,
    updatedAt: 1000,
  };

  assert.equal(isGroupAdmin(grp, 'u-creator'), true);
  assert.equal(isGroupAdmin(grp, 'u-mod'), true);
  assert.equal(isGroupAdmin(grp, 'u-member'), false);
  assert.equal(canManageGroupMembers(grp, 'u-member', false), false);
  assert.equal(canManageGroupMembers(grp, 'u-member', true), true);
  assert.equal(canManageGroupSettings(grp, 'u-mod', false), true);
});

test('shouldNotifyForMessage suppresses muted conversations, blocked users, and own messages', () => {
  const msg: ChatMessage = {
    id: 'm1',
    type: 'user',
    senderId: 'u-other',
    senderName: 'Rafi',
    senderColor: '#10B981',
    text: 'Ping',
    reactions: {},
    createdAt: 1000,
  };

  assert.deepEqual(
    shouldNotifyForMessage({
      message: msg,
      viewerId: 'u-me',
      roomId: 'main',
      mutedRoomIds: ['main'],
      blockedPeerIds: [],
      soundEnabled: true,
    }),
    { playSound: false, showBrowserNotification: false }
  );

  assert.deepEqual(
    shouldNotifyForMessage({
      message: msg,
      viewerId: 'u-me',
      roomId: 'main',
      mutedRoomIds: [],
      blockedPeerIds: ['u-other'],
      soundEnabled: true,
    }),
    { playSound: false, showBrowserNotification: false }
  );

  assert.deepEqual(
    shouldNotifyForMessage({
      message: msg,
      viewerId: 'u-me',
      roomId: 'main',
      mutedRoomIds: [],
      blockedPeerIds: [],
      soundEnabled: false,
    }),
    { playSound: false, showBrowserNotification: true }
  );
});

test('pushRecentItem maintains deduplicated LRU order', () => {
  assert.deepEqual(pushRecentItem(['👍', '❤️', '🔥'], '❤️', 3), ['❤️', '👍', '🔥']);
  assert.deepEqual(pushRecentItem(['👍', '❤️', '🔥'], '🎉', 3), ['🎉', '👍', '❤️']);
});

test('isSelfOrHostTarget blocks self-targeting by ID, nickname, phone, or active host flag', () => {
  const hosts = [
    { clientId: 'u-host', nickname: 'Arfan', isAdmin: true },
    { clientId: 'u-member', nickname: 'Rafi', isAdmin: false },
  ];

  assert.equal(
    isSelfOrHostTarget({
      targetClientId: 'u-host',
      selfClientId: 'u-host',
      selfNickname: 'Arfan',
      selfPhoneNumber: '01711112222',
      hostUsers: hosts,
    }),
    true
  );
  assert.equal(
    isSelfOrHostTarget({
      targetNickname: '  arfan  ',
      selfClientId: 'u-host',
      selfNickname: 'Arfan',
      selfPhoneNumber: '01711112222',
      hostUsers: hosts,
    }),
    true
  );
  assert.equal(
    isSelfOrHostTarget({
      targetNickname: '+8801711112222',
      selfClientId: 'u-host',
      selfNickname: 'Arfan',
      selfPhoneNumber: '01711112222',
      hostUsers: hosts,
    }),
    true
  );
  assert.equal(
    isSelfOrHostTarget({
      targetClientId: 'u-member',
      targetNickname: 'Rafi',
      selfClientId: 'u-host',
      selfNickname: 'Arfan',
      selfPhoneNumber: '01711112222',
      hostUsers: hosts,
    }),
    false
  );
});

test('canAccessRoom isolates private DMs and custom groups from third parties while allowing Host oversight', () => {
  const dmRoom = getDirectRoomId('u-alice', 'u-bob');
  const grp: ChatGroup = {
    id: 'grp__secret',
    name: 'Private Study',
    description: 'Docs',
    avatarColor: '#7C3AED',
    createdBy: 'u-alice',
    adminIds: ['u-alice'],
    memberIds: ['u-alice', 'u-bob'],
    createdAt: 1000,
    updatedAt: 1000,
  };

  assert.equal(isDirectRoomParticipant(dmRoom, 'u-alice'), true);
  assert.equal(isDirectRoomParticipant(dmRoom, 'u-bob'), true);
  assert.equal(isDirectRoomParticipant(dmRoom, 'u-charlie'), false);

  assert.equal(
    canAccessRoom({ roomId: dmRoom, clientId: 'u-alice', isAdmin: false }),
    true
  );
  assert.equal(
    canAccessRoom({ roomId: dmRoom, clientId: 'u-charlie', isAdmin: false }),
    false
  );
  assert.equal(
    canAccessRoom({ roomId: dmRoom, clientId: 'u-host', isAdmin: true }),
    true
  );
  assert.equal(
    canAccessRoom({ roomId: grp.id, clientId: 'u-charlie', isAdmin: false, group: grp }),
    false
  );
  assert.equal(
    canAccessRoom({ roomId: grp.id, clientId: 'u-host', isAdmin: true, group: grp }),
    true
  );
});

test('THEME_SPECS and WALLPAPER_PRESETS provide 20 unique safe designs each', () => {
  const themeIds = Object.keys(THEME_SPECS);
  assert.equal(themeIds.length, 20);
  for (const id of themeIds) {
    assert.equal(isValidThemeId(id), true);
    assert.equal(resolveTheme(id).id, id);
  }
  assert.equal(WALLPAPER_PRESETS.length, 20);
  const wpIds = new Set(WALLPAPER_PRESETS.map((w) => w.id));
  assert.equal(wpIds.size, 20);
  for (const wp of WALLPAPER_PRESETS) {
    assert.equal(wp.url.startsWith('data:image/svg+xml,'), true);
    assert.equal(wp.url.includes('"'), false);
    assert.equal(isSafeMediaUrl(wp.url), true);
  }
  assert.equal(CALL_AVATAR_PRESETS.length, 10);
});

test('canDeleteContact allows Host to delete other Host contacts while protecting active self', () => {
  assert.equal(
    canDeleteContact({
      targetClientId: 'u-other-host',
      selfClientId: 'u-current-host',
      isAdmin: true,
    }),
    true
  );
  assert.equal(
    canDeleteContact({
      targetClientId: 'u-current-host',
      selfClientId: 'u-current-host',
      isAdmin: true,
    }),
    false
  );
  assert.equal(
    canDeleteContact({
      targetClientId: 'u-other-host',
      selfClientId: 'u-member',
      isAdmin: false,
    }),
    false
  );
});

test('filterExpiredMessages enforces 24h and 7d disappearing timers cleanly', () => {
  const now = 1_700_000_000_000;
  const msgs: ChatMessage[] = [
    {
      id: 'old',
      type: 'user',
      senderId: 'u1',
      senderName: 'Arfan',
      senderColor: '#7C3AED',
      text: 'Old',
      reactions: {},
      createdAt: now - 30 * 3600 * 1000,
    },
    {
      id: 'recent',
      type: 'user',
      senderId: 'u1',
      senderName: 'Arfan',
      senderColor: '#7C3AED',
      text: 'Fresh',
      reactions: {},
      createdAt: now - 2 * 3600 * 1000,
    },
  ];
  assert.equal(filterExpiredMessages(msgs, 0, now).length, 2);
  const filtered24 = filterExpiredMessages(msgs, 24, now);
  assert.equal(filtered24.length, 1);
  assert.equal(filtered24[0].id, 'recent');
  assert.equal(filterExpiredMessages(msgs, 168, now).length, 2);
});

