export type ThemeId =
  | 'midnight-violet'
  | 'obsidian-plum'
  | 'aurora-indigo'
  | 'emerald-dusk'
  | 'clean-daylight'
  | 'whatsapp-dark'
  | 'whatsapp-classic'
  | 'messenger-midnight'
  | 'oled-amoled'
  | 'ocean-teal'
  | 'sunset-rose'
  | 'nordic-slate'
  | 'mocha-espresso'
  | 'crimson-velvet'
  | 'cyber-indigo'
  | 'sakura-blush'
  | 'forest-sage'
  | 'amber-gold'
  | 'lavender-cloud'
  | 'desert-sand';

export type CallAvatarId =
  | 'none'
  | 'shades'
  | 'visor'
  | 'cat'
  | 'crown'
  | 'robot'
  | 'panda'
  | 'heart'
  | 'cyber'
  | 'privacy';

export interface WallpaperPreset {
  id: string;
  name: string;
  nameBn: string;
  previewBg: string;
  url: string;
}

export interface ThemeSpec {
  id: ThemeId;
  name: string;
  nameBn: string;
  isDark: boolean;
  canvasBg: string;
  sidebarBg: string;
  surfaceBg: string;
  surfaceHoverBg: string;
  borderColor: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  accentBg: string;
  accentHoverBg: string;
  accentSoftBg: string;
  accentText: string;
  accentBorder: string;
  ownBubbleBg: string;
  ownBubbleText: string;
  otherBubbleBg: string;
  otherBubbleText: string;
  swatchPrimary: string;
  swatchSecondary: string;
}

export type PrivacyAudience = 'everyone' | 'contacts' | 'nobody';

export interface UserPrivacySettings {
  lastSeen: PrivacyAudience;
  profilePhoto: PrivacyAudience;
  status: PrivacyAudience;
}

export interface UserProfile {
  uid: string;
  clientId: string;
  authUid?: string | null;
  displayName: string;
  username: string;
  bio: string;
  avatarUrl?: string | null;
  avatarColor: string;
  isGuest: boolean;
  isAdmin?: boolean;
  online: boolean;
  lastSeenAt: number;
  privacy: UserPrivacySettings;
  blockedPeerIds?: string[];
  mutedRoomIds?: string[];
  updatedAt: number;
}

export interface ReplyReference {
  messageId: string;
  senderName: string;
  textPreview: string;
  hasImage?: boolean;
  hasVideo?: boolean;
  hasAudio?: boolean;
  hasFile?: boolean;
  hasGif?: boolean;
  hasSticker?: boolean;
  hasPoll?: boolean;
}

export interface ForwardedFrom {
  senderId: string;
  senderName: string;
  originalMessageId: string;
}

export interface PollOption {
  id: string;
  label: string;
  voterIds: string[];
}

export interface ChatPoll {
  question: string;
  options: PollOption[];
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'system';
  senderId: string;
  senderName: string;
  senderColor: string;
  senderAvatarUrl?: string | null;
  isAdmin?: boolean;
  isGuest?: boolean;
  text: string;
  imageDataUrl?: string;
  imageUrl?: string;
  videoUrl?: string;
  audioDataUrl?: string;
  audioUrl?: string;
  audioDurationSec?: number;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
  gifUrl?: string;
  stickerUrl?: string;
  poll?: ChatPoll;
  replyTo?: ReplyReference;
  forwardedFrom?: ForwardedFrom;
  deliveredTo?: string[];
  reactions: Record<string, string[]>; // emoji -> array of clientIds
  editedAt?: number;
  createdAt: number;
}

export interface DmThreadSummary {
  dmRoomId: string;
  participantIds: string[];
  participantNames: Record<string, string>;
  lastMessagePreview: string;
  lastSenderId: string;
  lastSenderName: string;
  lastMessageAt: number;
}

export interface OnlineUser {
  clientId: string;
  nickname: string;
  avatarColor: string;
  avatarUrl?: string | null;
  isAdmin: boolean;
  isGuest: boolean;
  connectedAt: number;
}

export interface BlockedUser {
  clientId: string;
  nickname: string;
  phoneNumber?: string;
  blockedAt: number;
}

export interface RegisteredUser {
  clientId: string;
  nickname: string;
  phoneNumber: string;
  avatarColor: string;
  isGuest: boolean;
  joinedAt: number;
  lastSeenAt: number;
}

export interface DeletedContact {
  clientId: string;
  nickname: string;
  username?: string;
  phoneNumber?: string;
  avatarColor: string;
  avatarUrl?: string | null;
  bio?: string;
  isGuest: boolean;
  isAdmin?: boolean;
  deletedAt: number;
  deletedBy?: string;
}

export interface ReadReceipt {
  clientId: string;
  nickname: string;
  avatarColor: string;
  lastReadMessageId: string;
  lastReadAt: number;
  updatedAt: number;
}

export interface PinnedMessageSummary {
  messageId: string;
  senderName: string;
  previewText: string;
  pinnedAt: number;
}

export interface RoomSettings {
  theme: ThemeId;
  roomLocked: boolean;
  roomTitle: string;
  slowModeSec: number;
  guestAllowed: boolean;
  announcement?: string;
  allowMedia?: boolean;
  allowVoice?: boolean;
  allowPolls?: boolean;
  allowGroupCreation?: boolean;
  disappearingHours?: 0 | 24 | 168;
}

export type StoryType = 'image' | 'video' | 'text';
export type StoryPrivacy = 'everyone' | 'contacts' | 'only_me' | 'custom';

export interface StoryViewer {
  uid: string;
  name: string;
  avatarColor: string;
  avatarUrl?: string | null;
  viewedAt: number;
}

export interface StoryStatus {
  id: string;
  authorId: string;
  authorName: string;
  authorColor: string;
  authorAvatarUrl?: string | null;
  type: StoryType;
  mediaUrl?: string | null;
  text?: string;
  bgColor?: string;
  privacy: StoryPrivacy;
  allowedViewerIds?: string[];
  excludedViewerIds?: string[];
  viewers: StoryViewer[];
  createdAt: number;
  expiresAt: number;
}

export interface ChatGroup {
  id: string; // grp__<slug>
  name: string;
  description: string;
  avatarUrl?: string | null;
  avatarColor: string;
  createdBy: string;
  adminIds: string[];
  memberIds: string[];
  mutedBy?: string[];
  pinnedMessage?: PinnedMessageSummary | null;
  createdAt: number;
  updatedAt: number;
}

export interface UserReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetId: string;
  targetName: string;
  targetType: 'user' | 'message';
  roomId?: string;
  messageId?: string;
  messagePreview?: string;
  reason: string;
  status: 'open' | 'resolved';
  createdAt: number;
}

export interface CustomSticker {
  id: string;
  url: string;
  label: string;
  ownerId: string;
  createdAt: number;
}

export interface GifItem {
  id: string;
  title: string;
  url: string;
  previewUrl: string;
  width?: number;
  height?: number;
}

export interface CallParticipant {
  clientId: string;
  nickname: string;
  avatarColor: string;
  videoEnabled: boolean;
  audioEnabled: boolean;
  screenSharing?: boolean;
  joinedAt: number;
  lastSeenAt: number;
}

export type CallMode = 'group' | 'personal' | 'custom_group';
export type CallMediaKind = 'audio' | 'video';

export interface DirectPeer {
  clientId: string;
  nickname: string;
  avatarColor: string;
  avatarUrl?: string | null;
  dmRoomId: string;
}

export type DirectPingKind = 'dm_message' | 'dm_call' | 'missed_call';

export interface DirectPing {
  id: string;
  toClientId: string;
  fromClientId: string;
  fromNickname: string;
  fromColor: string;
  dmRoomId: string;
  kind: DirectPingKind;
  callKind?: CallMediaKind;
  previewText: string;
  createdAt: number;
}

export type CallSignalKind = 'offer' | 'answer' | 'ice';

export interface CallSignal {
  id: string;
  fromId: string;
  toId: string;
  kind: CallSignalKind;
  payload: string;
  createdAt: number;
}

export type ClientEvent =
  | {
      type: 'room:join';
      payload: {
        clientId: string;
        nickname: string;
        avatarColor: string;
        isGuest?: boolean;
        adminToken?: string;
      };
    }
  | {
      type: 'message:send';
      payload: {
        id: string;
        text: string;
        imageDataUrl?: string;
        audioDataUrl?: string;
        audioDurationSec?: number;
        poll?: {
          question: string;
          options: string[];
        };
        replyTo?: ReplyReference;
      };
    }
  | {
      type: 'message:react';
      payload: {
        messageId: string;
        emoji: string;
      };
    }
  | {
      type: 'poll:vote';
      payload: {
        messageId: string;
        optionId: string;
      };
    }
  | {
      type: 'user:typing';
      payload: {
        isTyping: boolean;
      };
    }
  | {
      type: 'admin:auth';
      payload: {
        password: string;
      };
    }
  | {
      type: 'admin:logout';
      payload: Record<string, never>;
    }
  | {
      type: 'admin:block';
      payload: {
        targetClientId?: string;
        targetNickname: string;
      };
    }
  | {
      type: 'admin:unblock';
      payload: {
        targetNickname: string;
      };
    }
  | {
      type: 'message:delete';
      payload: {
        messageId: string;
      };
    }
  | {
      type: 'admin:delete_message';
      payload: {
        messageId: string;
      };
    }
  | {
      type: 'admin:pin_message';
      payload: {
        messageId: string | null;
      };
    }
  | {
      type: 'admin:clear_chat';
      payload: Record<string, never>;
    }
  | {
      type: 'admin:set_theme';
      payload: {
        theme: ThemeId;
      };
    }
  | {
      type: 'admin:toggle_lock';
      payload: {
        locked: boolean;
      };
    }
  | {
      type: 'admin:update_room';
      payload: {
        roomTitle?: string;
        slowModeSec?: number;
        guestAllowed?: boolean;
      };
    }
  | {
      type: 'admin:change_password';
      payload: {
        newPassword: string;
      };
    };

export type ServerEvent =
  | {
      type: 'room:init';
      payload: {
        messages: ChatMessage[];
        onlineUsers: OnlineUser[];
        theme: ThemeId;
        roomLocked: boolean;
        roomTitle: string;
        slowModeSec: number;
        guestAllowed: boolean;
        pinnedMessage: PinnedMessageSummary | null;
        isAdmin: boolean;
        isBlocked: boolean;
        blockReason?: string;
        blockedUsers?: BlockedUser[];
      };
    }
  | {
      type: 'room:users';
      payload: {
        onlineUsers: OnlineUser[];
      };
    }
  | {
      type: 'message:created';
      payload: {
        message: ChatMessage;
      };
    }
  | {
      type: 'message:updated';
      payload: {
        message: ChatMessage;
      };
    }
  | {
      type: 'message:deleted';
      payload: {
        messageId: string;
      };
    }
  | {
      type: 'room:pinned';
      payload: {
        pinnedMessage: PinnedMessageSummary | null;
      };
    }
  | {
      type: 'room:cleared';
      payload: Record<string, never>;
    }
  | {
      type: 'room:theme';
      payload: {
        theme: ThemeId;
      };
    }
  | {
      type: 'room:settings';
      payload: {
        roomLocked: boolean;
        roomTitle: string;
        slowModeSec: number;
        guestAllowed: boolean;
      };
    }
  | {
      type: 'user:typing';
      payload: {
        clientId: string;
        nickname: string;
        isTyping: boolean;
      };
    }
  | {
      type: 'admin:auth_result';
      payload: {
        success: boolean;
        adminToken?: string;
        blockedUsers?: BlockedUser[];
        error?: string;
      };
    }
  | {
      type: 'admin:blocked_list';
      payload: {
        blockedUsers: BlockedUser[];
      };
    }
  | {
      type: 'admin:password_changed';
      payload: {
        success: boolean;
        error?: string;
      };
    }
  | {
      type: 'user:kicked';
      payload: {
        reason: string;
      };
    }
  | {
      type: 'error';
      payload: {
        message: string;
      };
    };
