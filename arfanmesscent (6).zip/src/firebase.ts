import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, type User } from 'firebase/auth';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const storage = getStorage(app);
storage.maxUploadRetryTime = 4000;
storage.maxOperationRetryTime = 4000;

export const MAIN_ROOM_ID = 'main';

export interface AnonymousIdentityStatus {
  authEnabled: boolean;
  authUid: string | null;
  internalUid: string;
}

export function getOrCreateInternalUid(): string {
  const key = 'arfan_client_id';
  try {
    const existing = localStorage.getItem(key);
    if (existing && existing.length >= 6) return existing;
    const generated =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? `u-${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`
        : `u-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem(key, generated);
    return generated;
  } catch {
    return `u-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }
}

let cachedAuthUser: User | null = auth.currentUser;
let anonymousAuthAvailable = false;

export const ensureAnonymousIdentity: Promise<AnonymousIdentityStatus> = (async () => {
  const internalUid = getOrCreateInternalUid();
  if (auth.currentUser) {
    cachedAuthUser = auth.currentUser;
    anonymousAuthAvailable = true;
    return {
      authEnabled: true,
      authUid: auth.currentUser.uid,
      internalUid,
    };
  }
  try {
    const cred = await signInAnonymously(auth);
    cachedAuthUser = cred.user;
    anonymousAuthAvailable = true;
    return {
      authEnabled: true,
      authUid: cred.user.uid,
      internalUid,
    };
  } catch {
    // Firebase Console may not have Anonymous Sign-In toggled on yet; preserve unique internal UID seamlessly
    anonymousAuthAvailable = false;
    return {
      authEnabled: false,
      authUid: null,
      internalUid,
    };
  }
})();

export function getCurrentAuthUid(): string | null {
  return auth.currentUser?.uid ?? cachedAuthUser?.uid ?? null;
}

export function isAnonymousAuthActive(): boolean {
  return anonymousAuthAvailable && Boolean(getCurrentAuthUid());
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: getCurrentAuthUid(),
      email: null,
      emailVerified: false,
      isAnonymous: true,
      tenantId: null,
      providerInfo: [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();
