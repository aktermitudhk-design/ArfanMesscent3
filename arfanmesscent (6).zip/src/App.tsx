import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { MessageCircle, Video, X } from 'lucide-react';
import { AdminPanelModal, type HostInspectTarget } from './components/AdminPanelModal';
import { BlockedScreen } from './components/BlockedScreen';
import { ChatHeader } from './components/ChatHeader';
import { CreateStoryModal } from './components/CreateStoryModal';
import { ForwardModal } from './components/ForwardModal';
import { GroupModal } from './components/GroupModal';
import { ImageLightbox } from './components/ImageLightbox';
import { IncomingCallModal } from './components/IncomingCallModal';
import { JoinScreen } from './components/JoinScreen';
import { MessageComposer } from './components/MessageComposer';
import { MessageList } from './components/MessageList';
import { ProfileModal } from './components/ProfileModal';
import { ReportModal, type ReportTarget } from './components/ReportModal';
import { SettingsModal } from './components/SettingsModal';
import { SidebarMembers } from './components/SidebarMembers';
import { StoryViewerModal } from './components/StoryViewerModal';
import { VideoCallOverlay } from './components/VideoCallOverlay';
import { MAIN_ROOM_ID } from './firebase';
import { useChatSocket } from './hooks/useChatSocket';
import { useGroups } from './hooks/useGroups';
import { useStories } from './hooks/useStories';
import { useUserProfile } from './hooks/useUserProfile';
import { useVideoCall } from './hooks/useVideoCall';
import {
  AVATAR_COLORS,
  filterHiddenMessages,
  filterMessages,
  getDirectRoomId,
  isDirectRoomId,
  isDirectRoomParticipant,
  isValidThemeId,
  resolveTheme,
  validateBangladeshPhone,
} from './shared/chatRules';
import type {
  CallMediaKind,
  ChatGroup,
  ChatMessage,
  DirectPeer,
  DirectPing,
  ReplyReference,
  ThemeId,
  UserPrivacySettings,
  UserProfile,
} from './shared/types';
import { COPY, type Lang } from './utils/i18n';
import {
  getBrowserNotificationPermission,
  requestBrowserNotificationPermission,
} from './utils/notificationHelper';
import { bindAudioUnlockListeners } from './utils/soundHelper';

function getOrCreateClientId(): string {
  const key = 'arfan_client_id';
  const existing = localStorage.getItem(key);
  if (existing) return existing;
  const generated = `u-${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
  localStorage.setItem(key, generated);
  return generated;
}

function getInitialIdentity(): {
  nickname: string | null;
  phoneNumber: string | null;
  isGuest: boolean;
} {
  const params = new URLSearchParams(window.location.search);
  const savedName = localStorage.getItem('arfan_nickname');
  const savedPhoneRaw = localStorage.getItem('arfan_phone');
  const savedGuest = localStorage.getItem('arfan_is_guest') === '1';

  const savedPhoneCheck = savedPhoneRaw
    ? validateBangladeshPhone(savedPhoneRaw)
    : null;

  if (savedName && savedName.trim().length >= 2 && savedPhoneCheck?.valid) {
    return {
      nickname: savedName,
      phoneNumber: savedPhoneCheck.normalized,
      isGuest: savedGuest,
    };
  }

  // Optional automated test shortcut only when ?autostart=1 AND a valid BD ?phone= are provided
  if (params.get('autostart') === '1') {
    const paramName = params.get('name')?.trim();
    const paramPhoneCheck = validateBangladeshPhone(params.get('phone') || '');
    if (paramPhoneCheck.valid) {
      return {
        nickname: paramName && paramName.length >= 2 ? paramName : 'Arfan',
        phoneNumber: paramPhoneCheck.normalized,
        isGuest: false,
      };
    }
  }

  // Require JoinScreen for everyone else (including ?guest=1 invite links) so BD phone is always collected
  return { nickname: null, phoneNumber: null, isGuest: false };
}

const DEFAULT_PRIVACY: UserPrivacySettings = {
  lastSeen: 'everyone',
  profilePhoto: 'everyone',
  status: 'everyone',
};

export default function App() {
  const clientId = useMemo(() => getOrCreateClientId(), []);
  const initialIdentity = useMemo(() => getInitialIdentity(), []);

  const [nickname, setNickname] = useState<string | null>(
    initialIdentity.nickname
  );
  const [phoneNumber, setPhoneNumber] = useState<string | null>(
    initialIdentity.phoneNumber
  );
  const [isGuest, setIsGuest] = useState<boolean>(initialIdentity.isGuest);
  const [avatarColor, setAvatarColor] = useState<string>(
    () => localStorage.getItem('arfan_color') || AVATAR_COLORS[0]
  );
  const [lang, setLang] = useState<Lang>(
    () => (localStorage.getItem('arfan_lang') as Lang) || 'en'
  );
  const [soundEnabled, setSoundEnabled] = useState<boolean>(
    () => localStorage.getItem('arfan_sound') !== '0'
  );
  const [browserNotifEnabled, setBrowserNotifEnabled] = useState<boolean>(
    () => localStorage.getItem('arfan_browser_notif') !== '0'
  );
  const [notifPermission, setNotifPermission] = useState<
    NotificationPermission | 'unsupported'
  >(() => getBrowserNotificationPermission());

  const [personalThemeId, setPersonalThemeId] = useState<ThemeId | null>(() => {
    const saved = localStorage.getItem('arfan_personal_theme');
    return saved && isValidThemeId(saved) ? saved : null;
  });
  const [personalWallpaperUrl, setPersonalWallpaperUrl] = useState<
    string | null
  >(() => localStorage.getItem('arfan_personal_wallpaper') || null);

  // Sync flags bridged between hooks
  const [isAdminState, setIsAdminState] = useState(false);
  const [inCallState, setInCallState] = useState(false);

  // Active conversation selection
  const [activeDirectPeer, setActiveDirectPeer] = useState<DirectPeer | null>(
    null
  );
  const [activeCustomGroupId, setActiveCustomGroupId] = useState<string | null>(
    null
  );
  const [activeHostInspectRoom, setActiveHostInspectRoom] =
    useState<HostInspectTarget | null>(null);

  // UI & Modal states
  const [isAtBottom, setIsAtBottom] = useState(true);
  const [mobileMembersOpen, setMobileMembersOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [createStoryOpen, setCreateStoryOpen] = useState(false);
  const [storyViewerAuthorId, setStoryViewerAuthorId] = useState<string | null>(
    null
  );
  const [profileModal, setProfileModal] = useState<{
    open: boolean;
    mode: 'self' | 'peer';
    targetClientId?: string;
    fallbackName?: string;
    fallbackColor?: string;
  }>({ open: false, mode: 'self' });
  const [groupModal, setGroupModal] = useState<{
    open: boolean;
    mode: 'create' | 'manage';
    groupId: string | null;
  }>({ open: false, mode: 'create', groupId: null });
  const [forwardMsg, setForwardMsg] = useState<ChatMessage | null>(null);
  const [reportTarget, setReportTarget] = useState<ReportTarget | null>(null);

  const [copiedInvite, setCopiedInvite] = useState(false);
  const [guestLinkMode, setGuestLinkMode] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [droppedFile, setDroppedFile] = useState<File | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{
    src: string;
    senderName: string;
  } | null>(null);

  const userProfile = useUserProfile({
    clientId,
    nickname,
    avatarColor,
    isGuest,
    isAdmin: isAdminState,
  });

  const stories = useStories({
    clientId,
    nickname,
    avatarColor,
    avatarUrl: userProfile.ownProfile?.avatarUrl ?? null,
    blockedPeerIds: userProfile.blockedPeerIds,
    isAdmin: isAdminState,
  });

  const groups = useGroups({
    clientId,
    nickname,
    isAdmin: isAdminState,
  });

  const activeCustomGroup = useMemo(
    () =>
      activeCustomGroupId
        ? groups.myGroups.find((g) => g.id === activeCustomGroupId) || null
        : null,
    [activeCustomGroupId, groups.myGroups]
  );

  const activeRoomId =
    isAdminState && activeHostInspectRoom
      ? activeHostInspectRoom.roomId
      : activeCustomGroup
        ? activeCustomGroup.id
        : activeDirectPeer
          ? activeDirectPeer.dmRoomId
          : MAIN_ROOM_ID;

  const hiddenStorageKey = `arfan_hidden_msgs_${clientId}`;
  const [hiddenMessageIds, setHiddenMessageIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(hiddenStorageKey);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed)
        ? parsed.filter((id): id is string => typeof id === 'string')
        : [];
    } catch {
      return [];
    }
  });

  const invited = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('invite') === '1';
  }, []);

  const inviteUrl = useMemo(() => {
    const base = window.location.origin + window.location.pathname;
    return guestLinkMode ? `${base}?invite=1&guest=1` : `${base}?invite=1`;
  }, [guestLinkMode]);

  const handleOpenDirectRoomFromAlert = useCallback(
    (ping: DirectPing) => {
      setActiveHostInspectRoom(null);
      setActiveCustomGroupId(null);
      setActiveDirectPeer({
        clientId: ping.fromClientId,
        nickname: ping.fromNickname,
        avatarColor: ping.fromColor,
        avatarUrl:
          userProfile.profilesById[ping.fromClientId]?.avatarUrl ?? null,
        dmRoomId: ping.dmRoomId,
      });
      setReplyTo(null);
      setSearchQuery('');
      setSearchOpen(false);
    },
    [userProfile.profilesById]
  );

  const chat = useChatSocket({
    clientId,
    nickname,
    phoneNumber,
    avatarColor,
    avatarUrl: userProfile.ownProfile?.avatarUrl ?? null,
    isGuest,
    soundEnabled,
    browserNotifEnabled,
    mutedRoomIds: userProfile.mutedRoomIds,
    blockedPeerIds: userProfile.blockedPeerIds,
    profilesById: userProfile.profilesById,
    activeRoomId,
    activeDirectPeer,
    isAtBottom,
    inCall: inCallState,
    onOpenDirectRoomFromAlert: handleOpenDirectRoomFromAlert,
  });

  const videoCall = useVideoCall({
    clientId,
    nickname,
    avatarColor,
    isBlocked: chat.isBlocked,
  });

  useEffect(() => {
    bindAudioUnlockListeners();
  }, []);

  useEffect(() => {
    setIsAdminState(chat.isAdmin);
    if (!chat.isAdmin) {
      setActiveHostInspectRoom(null);
    }
  }, [chat.isAdmin]);

  useEffect(() => {
    setInCallState(videoCall.inCall);
  }, [videoCall.inCall]);

  // If user is removed from the active custom group, return to Main Lounge
  useEffect(() => {
    if (activeCustomGroupId && !activeCustomGroup && groups.allGroups.length > 0) {
      setActiveCustomGroupId(null);
    }
  }, [activeCustomGroup, activeCustomGroupId, groups.allGroups.length]);

  const effectiveTheme = useMemo(() => {
    if (!nickname || !phoneNumber) {
      return resolveTheme('midnight-violet');
    }
    return resolveTheme(personalThemeId || chat.themeId);
  }, [chat.themeId, nickname, personalThemeId, phoneNumber]);

  const effectiveBackgroundUrl = personalWallpaperUrl || chat.backgroundImageUrl;

  useEffect(() => {
    document.documentElement.classList.toggle('dark', effectiveTheme.isDark);
  }, [effectiveTheme.isDark]);

  const visibleMessages = useMemo(
    () =>
      filterMessages(
        filterHiddenMessages(chat.messages, hiddenMessageIds),
        searchQuery
      ),
    [chat.messages, hiddenMessageIds, searchQuery]
  );

  const totalUnreadDms = useMemo(
    () => Object.values(chat.unreadByPeerId).reduce((sum, n) => sum + n, 0),
    [chat.unreadByPeerId]
  );

  const activeDirectPeerProfile = useMemo(
    () =>
      activeDirectPeer
        ? userProfile.profilesById[activeDirectPeer.clientId] || null
        : null,
    [activeDirectPeer, userProfile.profilesById]
  );

  const storyViewerBucket = useMemo(
    () =>
      storyViewerAuthorId
        ? stories.storiesByAuthor.find(
            (b) => b.authorId === storyViewerAuthorId
          ) || null
        : null,
    [stories.storiesByAuthor, storyViewerAuthorId]
  );

  const groupModalTarget = useMemo(
    () =>
      groupModal.groupId
        ? groups.allGroups.find((g) => g.id === groupModal.groupId) || null
        : null,
    [groupModal.groupId, groups.allGroups]
  );

  const handleSelectGroupChat = useCallback(() => {
    setActiveHostInspectRoom(null);
    setActiveDirectPeer(null);
    setActiveCustomGroupId(null);
    setReplyTo(null);
    setSearchQuery('');
    setSearchOpen(false);
  }, []);

  const handleSelectCustomGroup = useCallback((group: ChatGroup) => {
    setActiveHostInspectRoom(null);
    setActiveDirectPeer(null);
    setActiveCustomGroupId(group.id);
    setReplyTo(null);
    setSearchQuery('');
    setSearchOpen(false);
  }, []);

  const handleSelectDirectPeer = useCallback(
    (user: {
      clientId: string;
      nickname: string;
      avatarColor: string;
      avatarUrl?: string | null;
    }) => {
      const dmRoomId = getDirectRoomId(clientId, user.clientId);
      setActiveHostInspectRoom(null);
      setActiveCustomGroupId(null);
      setActiveDirectPeer({
        clientId: user.clientId,
        nickname: user.nickname,
        avatarColor: user.avatarColor,
        avatarUrl:
          user.avatarUrl ??
          userProfile.profilesById[user.clientId]?.avatarUrl ??
          null,
        dmRoomId,
      });
      setReplyTo(null);
      setSearchQuery('');
      setSearchOpen(false);
    },
    [clientId, userProfile.profilesById]
  );

  const handleCallDirectPeer = useCallback(
    (
      user: {
        clientId: string;
        nickname: string;
        avatarColor: string;
        avatarUrl?: string | null;
      },
      callKind: CallMediaKind = 'video'
    ) => {
      const dmRoomId = getDirectRoomId(clientId, user.clientId);
      const peer: DirectPeer = {
        clientId: user.clientId,
        nickname: user.nickname,
        avatarColor: user.avatarColor,
        avatarUrl:
          user.avatarUrl ??
          userProfile.profilesById[user.clientId]?.avatarUrl ??
          null,
        dmRoomId,
      };
      setActiveCustomGroupId(null);
      setActiveDirectPeer(peer);
      setReplyTo(null);
      void videoCall.joinCall({
        roomId: dmRoomId,
        mode: 'personal',
        callKind,
        peer,
      });
    },
    [clientId, userProfile.profilesById, videoCall]
  );

  const handleStartRoomCall = useCallback(
    (callKind: CallMediaKind) => {
      if (videoCall.inCall) {
        videoCall.setIsMinimized(false);
        return;
      }
      if (activeDirectPeer) {
        void videoCall.joinCall({
          roomId: activeDirectPeer.dmRoomId,
          mode: 'personal',
          callKind,
          peer: activeDirectPeer,
        });
      } else if (activeCustomGroup) {
        void videoCall.joinCall({
          roomId: activeCustomGroup.id,
          mode: 'custom_group',
          callKind,
          peer: null,
        });
      } else {
        void videoCall.joinCall({
          roomId: MAIN_ROOM_ID,
          mode: 'group',
          callKind,
          peer: null,
        });
      }
    },
    [activeCustomGroup, activeDirectPeer, videoCall]
  );

  const handleDeleteForMe = useCallback(
    (messageId: string) => {
      setHiddenMessageIds((prev) => {
        if (prev.includes(messageId)) return prev;
        const next = [...prev, messageId].slice(-500);
        try {
          localStorage.setItem(hiddenStorageKey, JSON.stringify(next));
        } catch {
          // Ignore storage quota errors
        }
        return next;
      });
    },
    [hiddenStorageKey]
  );

  const handleToggleLang = () => {
    setLang((prev) => {
      const next: Lang = prev === 'en' ? 'bn' : 'en';
      localStorage.setItem('arfan_lang', next);
      return next;
    });
  };

  const handleToggleSound = () => {
    setSoundEnabled((prev) => {
      const next = !prev;
      localStorage.setItem('arfan_sound', next ? '1' : '0');
      return next;
    });
  };

  const handleToggleBrowserNotif = () => {
    setBrowserNotifEnabled((prev) => {
      const next = !prev;
      localStorage.setItem('arfan_browser_notif', next ? '1' : '0');
      return next;
    });
  };

  const handleRequestBrowserNotifPermission = async () => {
    const res = await requestBrowserNotificationPermission();
    setNotifPermission(res);
    if (res === 'granted') {
      setBrowserNotifEnabled(true);
      localStorage.setItem('arfan_browser_notif', '1');
    }
  };

  const handleChangePersonalTheme = (nextThemeId: ThemeId | null) => {
    setPersonalThemeId(nextThemeId);
    if (nextThemeId) {
      localStorage.setItem('arfan_personal_theme', nextThemeId);
    } else {
      localStorage.removeItem('arfan_personal_theme');
    }
  };

  const handleChangePersonalWallpaper = (url: string | null) => {
    setPersonalWallpaperUrl(url);
    if (url) {
      localStorage.setItem('arfan_personal_wallpaper', url);
    } else {
      localStorage.removeItem('arfan_personal_wallpaper');
    }
  };

  const handleJoin = (
    nextNickname: string,
    nextPhone: string,
    nextColor: string,
    nextGuest: boolean
  ) => {
    localStorage.setItem('arfan_nickname', nextNickname);
    localStorage.setItem('arfan_phone', nextPhone);
    localStorage.setItem('arfan_color', nextColor);
    localStorage.setItem('arfan_is_guest', nextGuest ? '1' : '0');
    setNickname(nextNickname);
    setPhoneNumber(nextPhone);
    setAvatarColor(nextColor);
    setIsGuest(nextGuest);
  };

  const handleChangeNickname = () => {
    localStorage.removeItem('arfan_nickname');
    localStorage.removeItem('arfan_is_guest');
    setNickname(null);
    setIsGuest(false);
    setActiveDirectPeer(null);
    setActiveCustomGroupId(null);
  };

  const handleCopyInvite = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopiedInvite(true);
      setTimeout(() => setCopiedInvite(false), 2200);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = inviteUrl;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedInvite(true);
      setTimeout(() => setCopiedInvite(false), 2200);
    }
  };

  const handleShareInvite = async () => {
    if (typeof navigator.share === 'function') {
      try {
        await navigator.share({
          title: 'ARFANMesscent',
          text: 'Join my live chat room on ARFANMesscent!',
          url: inviteUrl,
        });
      } catch {
        // User cancelled share
      }
    } else {
      void handleCopyInvite();
    }
  };

  const handleSendMessage = (payload: {
    text: string;
    imageUrl?: string;
    videoUrl?: string;
    audioUrl?: string;
    audioDataUrl?: string;
    audioDurationSec?: number;
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
    gifUrl?: string;
    stickerUrl?: string;
    poll?: { question: string; options: string[] };
  }) => {
    const replyRef: ReplyReference | undefined = replyTo
      ? {
          messageId: replyTo.id,
          senderName: replyTo.senderName,
          textPreview: replyTo.text.slice(0, 120),
          hasImage: Boolean(replyTo.imageUrl || replyTo.imageDataUrl),
          hasVideo: Boolean(replyTo.videoUrl),
          hasAudio: Boolean(replyTo.audioUrl || replyTo.audioDataUrl),
          hasFile: Boolean(replyTo.fileUrl),
          hasGif: Boolean(replyTo.gifUrl),
          hasSticker: Boolean(replyTo.stickerUrl),
          hasPoll: Boolean(replyTo.poll),
        }
      : undefined;

    chat.sendMessage({ ...payload, replyTo: replyRef });
    setReplyTo(null);
  };

  const handleDropFile = (e: React.DragEvent<HTMLElement>) => {
    e.preventDefault();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      setDroppedFile(file);
    }
  };

  const handleHostPasswordLogin = useCallback(
    async (password: string): Promise<boolean> => {
      const ok = await chat.unlockSelfAsHost(password);
      if (!ok) return false;
      if (!nickname || !phoneNumber) {
        const savedName = localStorage.getItem('arfan_nickname');
        const savedPhoneRaw = localStorage.getItem('arfan_phone');
        const phoneCheck = savedPhoneRaw
          ? validateBangladeshPhone(savedPhoneRaw)
          : null;
        const resolvedName =
          savedName && savedName.trim().length >= 2
            ? savedName.trim()
            : 'ARFAN Host';
        const resolvedPhone = phoneCheck?.valid
          ? phoneCheck.normalized
          : '01700000000';
        handleJoin(resolvedName, resolvedPhone, avatarColor, false);
      }
      return true;
    },
    [avatarColor, chat, nickname, phoneNumber]
  );

  const handleExportChat = useCallback(() => {
    const lines = chat.messages.map((m) => {
      const ts = new Date(m.createdAt).toLocaleString();
      const body =
        m.text ||
        (m.poll ? `[Poll] ${m.poll.question}` : '') ||
        (m.imageUrl || m.imageDataUrl ? '[Photo]' : '') ||
        (m.videoUrl ? '[Video]' : '') ||
        (m.audioUrl || m.audioDataUrl ? '[Voice Note]' : '') ||
        (m.fileName ? `[File: ${m.fileName}]` : '[Media]');
      return `[${ts}] ${m.senderName}: ${body}`;
    });
    const content = `ARFANMesscent Export — ${chat.roomTitle}\nGenerated: ${new Date().toLocaleString()}\n\n${lines.join('\n')}`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `arfanmesscent-${activeRoomId}-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }, [activeRoomId, chat.messages, chat.roomTitle]);

  if (chat.isBlocked) {
    return (
      <BlockedScreen
        reason={chat.kickReason}
        theme={effectiveTheme}
        lang={lang}
        onHostUnlock={chat.unlockSelfAsHost}
      />
    );
  }

  if (!nickname || !phoneNumber) {
    return (
      <JoinScreen
        initialNickname={localStorage.getItem('arfan_nickname') || ''}
        initialPhone={phoneNumber || localStorage.getItem('arfan_phone') || ''}
        initialColor={avatarColor}
        invited={invited}
        hostAuthError={chat.authError}
        theme={effectiveTheme}
        lang={lang}
        onToggleLang={handleToggleLang}
        onHostPasswordLogin={handleHostPasswordLogin}
        onJoin={handleJoin}
      />
    );
  }

  const t = COPY[lang];
  const guestCount = chat.onlineUsers.filter((u) => u.isGuest).length;
  const topIncomingCall = chat.incomingCallPings[0] || null;
  const isCurrentRoomMuted = userProfile.mutedRoomIds.includes(activeRoomId);

  return (
    <div
      className="h-dvh w-full flex overflow-hidden"
      style={{
        backgroundColor: effectiveTheme.canvasBg,
        color: effectiveTheme.textPrimary,
      }}
    >
      {/* Left Sidebar (Desktop) & Mobile Drawer */}
      <SidebarMembers
        onlineUsers={chat.onlineUsers}
        allProfiles={userProfile.allProfiles}
        profilesById={userProfile.profilesById}
        ownProfile={userProfile.ownProfile}
        myGroups={groups.myGroups}
        storiesByAuthor={stories.storiesByAuthor}
        currentClientId={clientId}
        currentNickname={nickname}
        currentAvatarColor={avatarColor}
        isAdmin={chat.isAdmin}
        guestLinkMode={guestLinkMode}
        inviteUrl={inviteUrl}
        copied={copiedInvite}
        activeRoomId={activeRoomId}
        activeDirectPeer={activeDirectPeer}
        unreadByPeerId={chat.unreadByPeerId}
        blockedPeerIds={userProfile.blockedPeerIds}
        blockedUsers={chat.blockedUsers}
        mutedRoomIds={userProfile.mutedRoomIds}
        allowGroupCreation={chat.allowGroupCreation}
        theme={effectiveTheme}
        lang={lang}
        mobileOpen={mobileMembersOpen}
        onCloseMobile={() => setMobileMembersOpen(false)}
        onToggleGuestLinkMode={setGuestLinkMode}
        onCopyInvite={handleCopyInvite}
        onShareInvite={handleShareInvite}
        onSelectGroupChat={handleSelectGroupChat}
        onSelectCustomGroup={handleSelectCustomGroup}
        onOpenCreateGroup={() =>
          setGroupModal({ open: true, mode: 'create', groupId: null })
        }
        onSelectDirectPeer={handleSelectDirectPeer}
        onCallDirectPeer={handleCallDirectPeer}
        onViewProfile={(profile) =>
          setProfileModal({
            open: true,
            mode: profile.clientId === clientId ? 'self' : 'peer',
            targetClientId: profile.clientId,
            fallbackName: profile.displayName,
            fallbackColor: profile.avatarColor,
          })
        }
        onOpenOwnProfile={() =>
          setProfileModal({
            open: true,
            mode: 'self',
            targetClientId: clientId,
            fallbackName: nickname,
            fallbackColor: avatarColor,
          })
        }
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenCreateStory={() => setCreateStoryOpen(true)}
        onOpenStoryBucket={(bucket) => setStoryViewerAuthorId(bucket.authorId)}
        onBlockUser={(user) => chat.blockUser(user.nickname, user.clientId)}
        onDeleteContact={(user) =>
          void chat.deleteContact({
            clientId: user.clientId,
            nickname: user.nickname,
          })
        }
        onOpenAdmin={() => setAdminModalOpen(true)}
        onChangeNickname={handleChangeNickname}
      />

      {/* Main Chat Column */}
      <main
        data-testid="main-chat-column"
        className="flex-1 min-w-0 h-full flex flex-col relative"
        style={
          effectiveBackgroundUrl
            ? {
                backgroundImage: `url("${effectiveBackgroundUrl}")`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
              }
            : undefined
        }
        onDragOver={(e) => {
          e.preventDefault();
          if (!isDraggingFile) setIsDraggingFile(true);
        }}
        onDragLeave={(e) => {
          if (e.currentTarget === e.target) setIsDraggingFile(false);
        }}
        onDrop={handleDropFile}
      >
        {effectiveBackgroundUrl && (
          <div
            aria-hidden="true"
            data-testid="main-chat-bg-scrim"
            className="pointer-events-none absolute inset-0 z-0"
            style={{
              backgroundColor: effectiveTheme.isDark
                ? 'rgba(9, 9, 15, 0.58)'
                : 'rgba(248, 250, 252, 0.65)',
            }}
          />
        )}

        <div className="relative z-10 flex-1 min-h-0 flex flex-col">
          {isDraggingFile && (
            <div
              className="absolute inset-0 z-40 flex items-center justify-center backdrop-blur-xs pointer-events-none"
              style={{
                backgroundColor: effectiveTheme.accentSoftBg,
                border: `2px dashed ${effectiveTheme.accentBg}`,
              }}
            >
              <span
                className="font-display text-base font-semibold px-4 py-2 rounded-xl"
                style={{
                  backgroundColor: effectiveTheme.surfaceBg,
                  color: effectiveTheme.textPrimary,
                }}
              >
                {t.dropImageHint}
              </span>
            </div>
          )}

          <ChatHeader
            roomTitle={chat.roomTitle}
            activeRoomId={activeRoomId}
            onlineCount={chat.onlineUsers.length}
            roomLocked={chat.roomLocked}
            isAdmin={chat.isAdmin}
            connected={chat.connected}
            copied={copiedInvite}
            soundEnabled={soundEnabled}
            isRoomMuted={isCurrentRoomMuted}
            searchOpen={searchOpen}
            searchQuery={searchQuery}
            announcement={chat.announcement}
            disappearingHours={chat.disappearingHours}
            pinnedMessage={activeDirectPeer ? null : chat.pinnedMessage}
            activeCallCount={videoCall.groupCallParticipants.length}
            inCall={videoCall.inCall}
            activeDirectPeer={activeDirectPeer}
            activeDirectPeerProfile={activeDirectPeerProfile}
            activeCustomGroup={activeCustomGroup}
            activeHostInspectRoom={chat.isAdmin ? activeHostInspectRoom : null}
            currentClientId={clientId}
            totalUnreadDms={totalUnreadDms}
            theme={effectiveTheme}
            lang={lang}
            onCopyInvite={handleCopyInvite}
            onOpenMembers={() => setMobileMembersOpen(true)}
            onOpenAdmin={() => setAdminModalOpen(true)}
            onOpenSettings={() => setSettingsOpen(true)}
            onOpenGroupInfo={() => {
              if (activeCustomGroup) {
                setGroupModal({
                  open: true,
                  mode: 'manage',
                  groupId: activeCustomGroup.id,
                });
              }
            }}
            onViewPeerProfile={() => {
              if (activeDirectPeer) {
                setProfileModal({
                  open: true,
                  mode: 'peer',
                  targetClientId: activeDirectPeer.clientId,
                  fallbackName: activeDirectPeer.nickname,
                  fallbackColor: activeDirectPeer.avatarColor,
                });
              }
            }}
            onToggleAudioCall={() => handleStartRoomCall('audio')}
            onToggleCall={() => handleStartRoomCall('video')}
            onToggleRoomMute={() => void userProfile.toggleMuteRoom(activeRoomId)}
            onBackToGroup={handleSelectGroupChat}
            onToggleLang={handleToggleLang}
            onToggleSound={handleToggleSound}
            onToggleSearch={() => {
              setSearchOpen((s) => {
                if (s) setSearchQuery('');
                return !s;
              });
            }}
            onSearchChange={setSearchQuery}
            onUnpin={() => chat.pinMessage(null)}
          />

          {/* Incoming 1-to-1 Call Modal & Missed Call Toast */}
          <IncomingCallModal
            incomingCall={topIncomingCall}
            inCall={videoCall.inCall}
            missedCalls={chat.missedCallAlerts}
            theme={effectiveTheme}
            lang={lang}
            onAccept={(ping, callKind) => {
              const peer: DirectPeer = {
                clientId: ping.fromClientId,
                nickname: ping.fromNickname,
                avatarColor: ping.fromColor,
                avatarUrl:
                  userProfile.profilesById[ping.fromClientId]?.avatarUrl ??
                  null,
                dmRoomId: ping.dmRoomId,
              };
              setActiveCustomGroupId(null);
              setActiveDirectPeer(peer);
              void chat.dismissCallPing(ping.id);
              void videoCall.joinCall({
                roomId: ping.dmRoomId,
                mode: 'personal',
                callKind,
                peer,
              });
            }}
            onReject={(ping) => {
              void chat.dismissCallPing(ping.id);
              void videoCall.rejectIncomingCall(ping);
            }}
            onDismissMissed={(pingId) => void chat.dismissMissedCall(pingId)}
            onCallBackMissed={(ping) => {
              const peer: DirectPeer = {
                clientId: ping.fromClientId,
                nickname: ping.fromNickname,
                avatarColor: ping.fromColor,
                avatarUrl:
                  userProfile.profilesById[ping.fromClientId]?.avatarUrl ??
                  null,
                dmRoomId: ping.dmRoomId,
              };
              setActiveCustomGroupId(null);
              setActiveDirectPeer(peer);
              void videoCall.joinCall({
                roomId: ping.dmRoomId,
                mode: 'personal',
                callKind: ping.callKind || 'video',
                peer,
              });
            }}
          />

          {/* Incoming Personal DM Toast Strip */}
          {chat.latestDmAlert &&
            chat.latestDmAlert.dmRoomId !== activeRoomId && (
              <div
                className="px-3 sm:px-5 py-2 flex items-center justify-between gap-3 shrink-0"
                style={{
                  backgroundColor: effectiveTheme.accentSoftBg,
                  borderBottom: `1px solid ${effectiveTheme.accentBorder}`,
                  color: effectiveTheme.textPrimary,
                }}
              >
                <div className="flex items-center gap-2 min-w-0 text-xs">
                  <MessageCircle
                    className="w-4 h-4 shrink-0"
                    style={{ color: effectiveTheme.accentText }}
                  />
                  <span className="truncate">
                    <strong>
                      {t.incomingDmAlert} {chat.latestDmAlert.fromNickname}:
                    </strong>{' '}
                    {chat.latestDmAlert.previewText}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const alert = chat.latestDmAlert!;
                      handleOpenDirectRoomFromAlert(alert);
                      chat.dismissDmAlert();
                    }}
                    className="h-7 px-2.5 rounded-lg text-xs font-semibold text-white cursor-pointer"
                    style={{ backgroundColor: effectiveTheme.accentBg }}
                  >
                    {t.openChat}
                  </button>
                  <button
                    type="button"
                    onClick={chat.dismissDmAlert}
                    aria-label={t.close}
                    className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
                    style={{ color: effectiveTheme.textMuted }}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

          {/* Live Group Call Join Strip */}
          {videoCall.groupCallParticipants.length > 0 && !videoCall.inCall && (
            <div
              className="px-3 sm:px-5 py-2 flex items-center justify-between gap-3 shrink-0"
              style={{
                backgroundColor: 'rgba(16, 185, 129, 0.14)',
                borderBottom: '1px solid rgba(52, 211, 153, 0.3)',
                color: effectiveTheme.textPrimary,
              }}
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span className="text-xs font-medium truncate">
                  {t.liveCallBanner} (
                  {videoCall.groupCallParticipants
                    .map((p) => p.nickname)
                    .join(', ')}
                  )
                </span>
              </div>

              <button
                type="button"
                onClick={() =>
                  void videoCall.joinCall({
                    roomId: MAIN_ROOM_ID,
                    mode: 'group',
                    callKind: 'video',
                    peer: null,
                  })
                }
                disabled={videoCall.joining}
                className="h-8 px-3 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Video className="w-3.5 h-3.5" />
                <span>{t.joinVideoCall}</span>
              </button>
            </div>
          )}

          <VideoCallOverlay
            inCall={videoCall.inCall}
            isMinimized={videoCall.isMinimized}
            callMode={videoCall.activeCallMode}
            callPeer={videoCall.activeCallPeer}
            micEnabled={videoCall.micEnabled}
            cameraEnabled={videoCall.cameraEnabled}
            canSwitchCamera={videoCall.canSwitchCamera}
            audioOutputs={videoCall.audioOutputs}
            selectedAudioOutputId={videoCall.selectedAudioOutputId}
            screenSharing={videoCall.screenSharing}
            screenAudioActive={videoCall.screenAudioActive}
            avatarFilter={videoCall.avatarFilter}
            callDurationSec={videoCall.callDurationSec}
            localStream={videoCall.localStream}
            remoteStreams={videoCall.remoteStreams}
            callParticipants={videoCall.callParticipants}
            currentClientId={clientId}
            currentNickname={nickname}
            currentAvatarColor={avatarColor}
            callNotice={videoCall.callNotice}
            theme={effectiveTheme}
            lang={lang}
            onToggleMic={videoCall.toggleMic}
            onToggleCamera={videoCall.toggleCamera}
            onSwitchCamera={() => void videoCall.switchCamera()}
            onSelectAudioOutput={videoCall.setSelectedAudioOutputId}
            onToggleScreenShare={() => void videoCall.toggleScreenShare()}
            onSelectAvatarFilter={videoCall.setCallAvatarFilter}
            onSetMinimized={videoCall.setIsMinimized}
            onLeaveCall={() => void videoCall.leaveCall()}
          />

          <MessageList
            key={activeRoomId}
            messages={visibleMessages}
            readReceipts={chat.readReceipts}
            profilesById={userProfile.profilesById}
            isDirectRoom={
              Boolean(activeDirectPeer) || isDirectRoomId(activeRoomId)
            }
            currentClientId={clientId}
            isAdmin={chat.isAdmin}
            pinnedMessageId={
              activeDirectPeer || isDirectRoomId(activeRoomId)
                ? null
                : chat.pinnedMessage?.messageId ?? null
            }
            searchQuery={searchQuery}
            typingUsers={chat.typingUsers}
            hasMoreOlder={chat.hasMoreOlder}
            loadingOlder={chat.loadingOlder}
            theme={effectiveTheme}
            lang={lang}
            onAtBottomChange={setIsAtBottom}
            onLoadOlder={() => void chat.loadOlderMessages()}
            onReply={(msg) => setReplyTo(msg)}
            onEditMessage={(messageId, nextText) =>
              void chat.editMessage(messageId, nextText)
            }
            onForward={(msg) => setForwardMsg(msg)}
            onReportMessage={(msg) =>
              setReportTarget({
                targetId: msg.senderId,
                targetName: msg.senderName,
                targetType: 'message',
                messageId: msg.id,
                messagePreview:
                  msg.text ||
                  (msg.imageUrl || msg.imageDataUrl
                    ? '[Photo]'
                    : msg.videoUrl
                      ? '[Video]'
                      : msg.fileName || '[Media]'),
              })
            }
            onReact={chat.reactToMessage}
            onVotePoll={chat.votePoll}
            onPinMessage={chat.pinMessage}
            onDeleteForMe={handleDeleteForMe}
            onDeleteForEveryone={chat.deleteMessage}
            onOpenImage={(src, senderName) =>
              setLightboxImage({ src, senderName })
            }
            onViewSenderProfile={(senderId, fallbackName, fallbackColor) =>
              setProfileModal({
                open: true,
                mode: senderId === clientId ? 'self' : 'peer',
                targetClientId: senderId,
                fallbackName,
                fallbackColor,
              })
            }
          />

          {activeHostInspectRoom &&
          isDirectRoomId(activeHostInspectRoom.roomId) &&
          !isDirectRoomParticipant(activeHostInspectRoom.roomId, clientId) ? (
            <div
              data-testid="host-oversight-readonly-bar"
              className="px-4 py-3 text-center text-xs font-medium shrink-0"
              style={{
                backgroundColor: effectiveTheme.sidebarBg,
                borderTop: `1px solid ${effectiveTheme.borderColor}`,
                color: effectiveTheme.accentText,
              }}
            >
              {t.hostReadOnlyNotice}
            </div>
          ) : (
            <MessageComposer
              clientId={clientId}
              roomLocked={Boolean(
                !activeDirectPeer &&
                  !activeCustomGroup &&
                  !activeHostInspectRoom &&
                  chat.roomLocked
              )}
              isAdmin={chat.isAdmin}
              allowMedia={chat.allowMedia}
              allowVoice={chat.allowVoice}
              allowPolls={chat.allowPolls}
              roomError={chat.roomError}
              droppedFile={droppedFile}
              replyTo={replyTo}
              customStickers={chat.customStickers}
              theme={effectiveTheme}
              lang={lang}
              onClearDroppedFile={() => setDroppedFile(null)}
              onCancelReply={() => setReplyTo(null)}
              onUploadSticker={chat.uploadCustomSticker}
              onSendMessage={handleSendMessage}
              onTypingChange={chat.sendTyping}
            />
          )}
        </div>
      </main>

      {/* Host Controls Modal */}
      <AdminPanelModal
        open={adminModalOpen}
        isAdmin={chat.isAdmin}
        currentClientId={clientId}
        selfNickname={nickname}
        selfPhoneNumber={phoneNumber}
        profilesById={userProfile.profilesById}
        authError={chat.authError}
        currentThemeId={chat.themeId}
        backgroundImageUrl={chat.backgroundImageUrl}
        roomLocked={chat.roomLocked}
        roomTitle={chat.roomTitle}
        slowModeSec={chat.slowModeSec}
        guestAllowed={chat.guestAllowed}
        announcement={chat.announcement}
        allowMedia={chat.allowMedia}
        allowVoice={chat.allowVoice}
        allowPolls={chat.allowPolls}
        allowGroupCreation={chat.allowGroupCreation}
        disappearingHours={chat.disappearingHours}
        messageCount={chat.messages.length}
        onlineCount={chat.onlineUsers.length}
        guestCount={guestCount}
        storyCount={stories.visibleStories.length}
        onlineUsers={chat.onlineUsers}
        registeredUsers={chat.registeredUsers}
        deletedContacts={chat.deletedContacts}
        allProfiles={userProfile.allProfiles}
        blockedUsers={chat.blockedUsers}
        reports={chat.reports}
        allGroups={groups.allGroups}
        allDmThreads={chat.allDmThreads}
        scanningDmThreads={chat.scanningDmThreads}
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setAdminModalOpen(false)}
        onLogin={chat.loginAdmin}
        onLogout={chat.logoutAdmin}
        onSelectTheme={chat.setRoomTheme}
        onSelectBackgroundPreset={chat.setRoomBackgroundPreset}
        onUploadBackground={chat.uploadRoomBackground}
        onClearBackground={chat.clearRoomBackground}
        onToggleLock={chat.toggleLock}
        onUpdateRoomSettings={chat.updateRoomSettings}
        onClearChat={chat.clearChat}
        onClearRoomCalls={chat.clearRoomCalls}
        onExportChat={handleExportChat}
        onScanAllDmThreads={chat.discoverAllDmThreads}
        onBlockUser={(target) =>
          chat.blockUser(target.nickname, target.clientId, target.phoneNumber)
        }
        onUnblock={chat.unblockUser}
        onDeleteContact={(target) => void chat.deleteContact(target)}
        onRestoreDeletedContact={chat.restoreDeletedContact}
        onResolveReport={chat.resolveReport}
        onDeleteReportedMessage={async (messageId, roomId) => {
          await chat.deleteMessage(messageId, roomId);
        }}
        onDeleteGroup={groups.deleteGroup}
        onInspectRoom={(target) => {
          setActiveDirectPeer(null);
          setActiveCustomGroupId(null);
          setActiveHostInspectRoom(target.roomId === 'main' ? null : target);
          setReplyTo(null);
          setSearchQuery('');
          setSearchOpen(false);
        }}
      />

      {/* Profile Modal (Self Edit or Peer View) */}
      <ProfileModal
        open={profileModal.open}
        mode={profileModal.mode}
        currentClientId={clientId}
        ownProfile={userProfile.ownProfile}
        targetProfile={
          profileModal.targetClientId
            ? userProfile.profilesById[profileModal.targetClientId] || null
            : null
        }
        targetFallbackName={profileModal.fallbackName}
        targetFallbackColor={profileModal.fallbackColor}
        blockedPeerIds={userProfile.blockedPeerIds}
        mutedRoomIds={userProfile.mutedRoomIds}
        dmRoomId={
          profileModal.targetClientId &&
          profileModal.targetClientId !== clientId
            ? getDirectRoomId(clientId, profileModal.targetClientId)
            : null
        }
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setProfileModal((p) => ({ ...p, open: false }))}
        onSaveOwnProfile={async (patch) => {
          const res = await userProfile.updateOwnProfile(patch);
          if (!res.error) {
            if (res.nextDisplayName) {
              localStorage.setItem('arfan_nickname', res.nextDisplayName);
              setNickname(res.nextDisplayName);
            }
            if (res.nextColor) {
              localStorage.setItem('arfan_color', res.nextColor);
              setAvatarColor(res.nextColor);
            }
          }
          return res;
        }}
        onStartDm={(profile) => {
          handleSelectDirectPeer({
            clientId: profile.clientId,
            nickname: profile.displayName,
            avatarColor: profile.avatarColor,
            avatarUrl: profile.avatarUrl,
          });
        }}
        onStartAudioCall={(profile) => {
          handleCallDirectPeer(
            {
              clientId: profile.clientId,
              nickname: profile.displayName,
              avatarColor: profile.avatarColor,
              avatarUrl: profile.avatarUrl,
            },
            'audio'
          );
        }}
        onStartVideoCall={(profile) => {
          handleCallDirectPeer(
            {
              clientId: profile.clientId,
              nickname: profile.displayName,
              avatarColor: profile.avatarColor,
              avatarUrl: profile.avatarUrl,
            },
            'video'
          );
        }}
        onToggleBlockPeer={(peerId) => void userProfile.toggleBlockPeer(peerId)}
        onToggleMuteRoom={(roomId) => void userProfile.toggleMuteRoom(roomId)}
        onReportPeer={(profile) => {
          setReportTarget({
            targetId: profile.clientId,
            targetName: profile.displayName,
            targetType: 'user',
          });
        }}
      />

      {/* Settings & Privacy Modal */}
      <SettingsModal
        open={settingsOpen}
        clientId={clientId}
        theme={effectiveTheme}
        personalThemeId={personalThemeId}
        personalWallpaperUrl={personalWallpaperUrl}
        soundEnabled={soundEnabled}
        browserNotifEnabled={browserNotifEnabled}
        notifPermission={notifPermission}
        privacy={userProfile.ownProfile?.privacy || DEFAULT_PRIVACY}
        blockedPeerIds={userProfile.blockedPeerIds}
        mutedRoomIds={userProfile.mutedRoomIds}
        profilesById={userProfile.profilesById}
        lang={lang}
        onClose={() => setSettingsOpen(false)}
        onChangePersonalTheme={handleChangePersonalTheme}
        onChangePersonalWallpaper={handleChangePersonalWallpaper}
        onToggleSound={handleToggleSound}
        onToggleBrowserNotif={handleToggleBrowserNotif}
        onRequestBrowserNotifPermission={() =>
          void handleRequestBrowserNotifPermission()
        }
        onUpdatePrivacy={async (next) => {
          await userProfile.updateOwnProfile({ privacy: next });
        }}
        onUnblockPeer={(peerId) => void userProfile.toggleBlockPeer(peerId)}
        onUnmuteRoom={(roomId) => void userProfile.toggleMuteRoom(roomId)}
      />

      {/* Create Story Modal */}
      <CreateStoryModal
        open={createStoryOpen}
        currentClientId={clientId}
        contacts={userProfile.allProfiles}
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setCreateStoryOpen(false)}
        onCreateStory={stories.createStory}
      />

      {/* Story Viewer Modal */}
      <StoryViewerModal
        open={Boolean(storyViewerBucket)}
        stories={storyViewerBucket?.stories || []}
        currentClientId={clientId}
        isAdmin={chat.isAdmin}
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setStoryViewerAuthorId(null)}
        onMarkViewed={(st) => void stories.markStoryViewed(st)}
        onDeleteStory={stories.deleteStory}
      />

      {/* Custom Group Create / Manage Modal */}
      <GroupModal
        open={groupModal.open}
        mode={groupModal.mode}
        group={groupModalTarget}
        currentClientId={clientId}
        isGlobalAdmin={chat.isAdmin}
        contacts={userProfile.allProfiles}
        profilesById={userProfile.profilesById}
        mutedRoomIds={userProfile.mutedRoomIds}
        theme={effectiveTheme}
        lang={lang}
        onClose={() =>
          setGroupModal({ open: false, mode: 'create', groupId: null })
        }
        onCreateGroup={groups.createGroup}
        onSelectGroup={handleSelectCustomGroup}
        onUpdateGroup={groups.updateGroupDetails}
        onAddMember={groups.addMemberToGroup}
        onRemoveMember={groups.removeMemberFromGroup}
        onToggleAdmin={groups.toggleGroupAdminRole}
        onToggleMute={(roomId) => void userProfile.toggleMuteRoom(roomId)}
        onStartGroupCall={(grp, callKind) => {
          handleSelectCustomGroup(grp);
          void videoCall.joinCall({
            roomId: grp.id,
            mode: 'custom_group',
            callKind,
            peer: null,
          });
        }}
        onDeleteGroup={groups.deleteGroup}
      />

      {/* Forward Message Modal */}
      <ForwardModal
        message={forwardMsg}
        currentClientId={clientId}
        groups={groups.myGroups}
        contacts={userProfile.allProfiles}
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setForwardMsg(null)}
        onForward={chat.forwardMessage}
      />

      {/* Report User / Message Modal */}
      <ReportModal
        target={reportTarget}
        theme={effectiveTheme}
        lang={lang}
        onClose={() => setReportTarget(null)}
        onSubmitReport={chat.submitReport}
      />

      {/* Image Lightbox */}
      <ImageLightbox
        image={lightboxImage}
        lang={lang}
        onClose={() => setLightboxImage(null)}
      />
    </div>
  );
}

export type { UserProfile };
