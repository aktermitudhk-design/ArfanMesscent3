import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Eye, Trash2, X } from 'lucide-react';
import { formatTime } from '../shared/chatRules';
import type { StoryStatus, ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface StoryViewerModalProps {
  open: boolean;
  stories: StoryStatus[];
  currentClientId: string;
  isAdmin: boolean;
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onMarkViewed: (story: StoryStatus) => void;
  onDeleteStory: (story: StoryStatus) => Promise<void>;
}

export function StoryViewerModal({
  open,
  stories,
  currentClientId,
  isAdmin,
  theme,
  lang,
  onClose,
  onMarkViewed,
  onDeleteStory,
}: StoryViewerModalProps) {
  const t = COPY[lang];
  const [index, setIndex] = useState(0);
  const [showViewers, setShowViewers] = useState(false);

  useEffect(() => {
    setIndex(0);
    setShowViewers(false);
  }, [open, stories.length]);

  const activeStory = stories[index] || null;

  useEffect(() => {
    if (open && activeStory) {
      onMarkViewed(activeStory);
    }
  }, [activeStory, onMarkViewed, open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' && index < stories.length - 1) {
        setIndex((i) => i + 1);
      }
      if (e.key === 'ArrowLeft' && index > 0) {
        setIndex((i) => i - 1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [index, onClose, open, stories.length]);

  if (!open || !activeStory) return null;

  const canDelete =
    activeStory.authorId === currentClientId || isAdmin;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={t.storiesTitle}
    >
      <div className="w-full max-w-md h-full max-h-[88dvh] flex flex-col rounded-3xl overflow-hidden relative bg-zinc-950 border border-white/15">
        {/* Top Progress Bars + Author Header */}
        <div className="p-4 bg-gradient-to-b from-black/80 to-transparent z-20 space-y-3">
          <div className="flex items-center gap-1">
            {stories.map((st, idx) => (
              <div
                key={st.id}
                className="flex-1 h-1 rounded-full overflow-hidden bg-white/25"
              >
                <div
                  className="h-full bg-white transition-all"
                  style={{
                    width: idx < index ? '100%' : idx === index ? '100%' : '0%',
                    opacity: idx === index ? 1 : idx < index ? 0.75 : 0,
                  }}
                />
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between gap-2 text-white">
            <div className="flex items-center gap-2.5 min-w-0">
              <AvatarBadge
                name={activeStory.authorName}
                avatarColor={activeStory.authorColor}
                avatarUrl={activeStory.authorAvatarUrl}
                size="sm"
              />
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">
                  {activeStory.authorName}
                </p>
                <p className="text-[11px] text-white/70 font-mono-nums">
                  {formatTime(activeStory.createdAt)}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {canDelete && (
                <button
                  type="button"
                  onClick={async () => {
                    await onDeleteStory(activeStory);
                    if (stories.length <= 1) onClose();
                  }}
                  aria-label={t.deleteStory}
                  className="w-9 h-9 rounded-xl bg-red-600/80 hover:bg-red-600 text-white flex items-center justify-center cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                aria-label={t.close}
                className="w-9 h-9 rounded-xl bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Media / Text Body */}
        <div
          className="flex-1 min-h-0 flex items-center justify-center relative px-5 py-4"
          style={
            activeStory.type === 'text'
              ? { backgroundColor: activeStory.bgColor || '#6D28D9' }
              : undefined
          }
        >
          {activeStory.type === 'text' && (
            <p className="font-display text-2xl font-bold text-white text-center leading-snug break-words">
              {activeStory.text}
            </p>
          )}

          {activeStory.type === 'image' && activeStory.mediaUrl && (
            <img
              src={activeStory.mediaUrl}
              alt={activeStory.text || 'Story image'}
              referrerPolicy="no-referrer"
              className="max-h-full max-w-full rounded-2xl object-contain"
            />
          )}

          {activeStory.type === 'video' && activeStory.mediaUrl && (
            <video
              src={activeStory.mediaUrl}
              controls
              autoPlay
              playsInline
              className="max-h-full max-w-full rounded-2xl object-contain"
            />
          )}

          {index > 0 && (
            <button
              type="button"
              onClick={() => setIndex((i) => Math.max(0, i - 1))}
              aria-label="Previous story"
              className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/55 text-white flex items-center justify-center cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {index < stories.length - 1 && (
            <button
              type="button"
              onClick={() => setIndex((i) => Math.min(stories.length - 1, i + 1))}
              aria-label="Next story"
              className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/55 text-white flex items-center justify-center cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Caption & Viewers Bar */}
        <div className="p-4 bg-gradient-to-t from-black/90 to-transparent z-20 space-y-2 text-white">
          {activeStory.type !== 'text' && activeStory.text && (
            <p className="text-sm text-center text-white/95">
              {activeStory.text}
            </p>
          )}

          {activeStory.authorId === currentClientId && (
            <div>
              <button
                type="button"
                onClick={() => setShowViewers((v) => !v)}
                className="w-full min-h-[40px] px-3 rounded-xl bg-white/10 hover:bg-white/15 flex items-center justify-center gap-2 text-xs font-medium cursor-pointer"
              >
                <Eye className="w-4 h-4" />
                <span>
                  {t.storyViewers}: {activeStory.viewers.length}
                </span>
              </button>

              {showViewers && (
                <div
                  className="mt-2 max-h-40 overflow-y-auto chat-scroll rounded-xl p-2 space-y-1.5"
                  style={{
                    backgroundColor: theme.surfaceBg,
                    color: theme.textPrimary,
                  }}
                >
                  {activeStory.viewers.length === 0 ? (
                    <p
                      className="text-xs text-center py-2"
                      style={{ color: theme.textMuted }}
                    >
                      {t.noViewersYet}
                    </p>
                  ) : (
                    activeStory.viewers.map((v) => (
                      <div
                        key={v.uid}
                        className="flex items-center justify-between gap-2 px-2 py-1 text-xs"
                      >
                        <span className="flex items-center gap-2 truncate">
                          <AvatarBadge
                            name={v.name}
                            avatarColor={v.avatarColor}
                            avatarUrl={v.avatarUrl}
                            size="xs"
                          />
                          <span className="font-medium truncate">{v.name}</span>
                        </span>
                        <span
                          className="font-mono-nums text-[11px]"
                          style={{ color: theme.textMuted }}
                        >
                          {formatTime(v.viewedAt)}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
