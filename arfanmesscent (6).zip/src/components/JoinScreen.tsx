import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Globe,
  KeyRound,
  MessageSquare,
  Phone,
  ShieldCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  AVATAR_COLORS,
  generateGuestNickname,
  sanitizeNickname,
  validateBangladeshPhone,
} from '../shared/chatRules';
import type { ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

interface JoinScreenProps {
  initialNickname: string;
  initialPhone: string;
  initialColor: string;
  invited: boolean;
  hostAuthError?: string | null;
  theme: ThemeSpec;
  lang: Lang;
  onToggleLang: () => void;
  onHostPasswordLogin?: (password: string) => Promise<boolean>;
  onJoin: (
    nickname: string,
    phoneNumber: string,
    avatarColor: string,
    isGuest: boolean
  ) => void;
}

export function JoinScreen({
  initialNickname,
  initialPhone,
  initialColor,
  invited,
  hostAuthError,
  theme,
  lang,
  onToggleLang,
  onHostPasswordLogin,
  onJoin,
}: JoinScreenProps) {
  const [nickname, setNickname] = useState(initialNickname);
  const [phone, setPhone] = useState(initialPhone);
  const [avatarColor, setAvatarColor] = useState(initialColor);
  const [nameError, setNameError] = useState<string | null>(null);
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [hostMode, setHostMode] = useState(false);
  const [hostPassword, setHostPassword] = useState('');
  const [hostLoggingIn, setHostLoggingIn] = useState(false);
  const [localHostError, setLocalHostError] = useState<string | null>(null);
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const t = COPY[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nameResult = sanitizeNickname(nickname);
    const phoneResult = validateBangladeshPhone(phone);

    let hasError = false;
    if (!nameResult.valid) {
      setNameError(nameResult.error || 'Please enter a valid nickname.');
      hasError = true;
    } else {
      setNameError(null);
    }

    if (!phoneResult.valid) {
      setPhoneError(phoneResult.error || t.bdPhoneRequiredForGuest);
      if (nameResult.valid) {
        phoneInputRef.current?.focus();
      }
      hasError = true;
    } else {
      setPhoneError(null);
    }

    if (hasError) return;
    onJoin(nameResult.nickname, phoneResult.normalized, avatarColor, false);
  };

  const handleInstantGuest = () => {
    const phoneResult = validateBangladeshPhone(phone);
    if (!phoneResult.valid) {
      setPhoneError(phoneResult.error || t.bdPhoneRequiredForGuest);
      phoneInputRef.current?.focus();
      return;
    }
    setPhoneError(null);
    const guestName = generateGuestNickname();
    onJoin(guestName, phoneResult.normalized, avatarColor, true);
  };

  const handleHostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onHostPasswordLogin || hostLoggingIn) return;
    if (!hostPassword.trim()) {
      setLocalHostError(t.wrongPassword);
      return;
    }
    setLocalHostError(null);
    setHostLoggingIn(true);
    try {
      const ok = await onHostPasswordLogin(hostPassword);
      if (!ok) {
        setLocalHostError(t.wrongPassword);
      }
    } finally {
      setHostLoggingIn(false);
    }
  };

  const effectiveHostError =
    localHostError ||
    (hostAuthError === 'wrongPassword' ? t.wrongPassword : hostAuthError);

  return (
    <div
      className="min-h-dvh w-full flex flex-col justify-between px-4 py-6 sm:px-8 relative overflow-hidden"
      style={{ backgroundColor: theme.canvasBg, color: theme.textPrimary }}
    >
      {/* Subtle ambient top luminance */}
      <div
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[720px] h-[360px] rounded-full blur-3xl opacity-20"
        style={{ backgroundColor: theme.accentBg }}
        aria-hidden="true"
      />

      {/* Top minimal bar */}
      <header className="relative z-10 w-full max-w-5xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0"
            style={{ backgroundColor: theme.accentBg }}
          >
            <MessageSquare className="w-4.5 h-4.5" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight whitespace-nowrap">
            {t.appName}
          </span>
        </div>

        <button
          type="button"
          onClick={onToggleLang}
          aria-label="Switch language"
          className="min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
            color: theme.textSecondary,
          }}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>{lang === 'en' ? 'বাংলা' : 'English'}</span>
        </button>
      </header>

      {/* Center Join Card */}
      <main className="relative z-10 w-full max-w-md mx-auto my-auto py-8">
        {invited && (
          <p
            className="text-xs font-medium mb-3 text-center"
            style={{ color: theme.accentText }}
          >
            {t.invitedBanner}
          </p>
        )}

        <div
          className="rounded-2xl p-6 sm:p-8 shadow-2xl"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          <div className="mb-6">
            <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-balance">
              {hostMode ? t.hostLoginToggle : t.appName}
            </h1>
            <p
              className="mt-2 text-sm leading-relaxed"
              style={{ color: theme.textMuted }}
            >
              {hostMode ? t.hostLoginSub : t.tagline}
            </p>
          </div>

          {hostMode && onHostPasswordLogin ? (
            <form onSubmit={handleHostSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="join-host-password-input"
                  className="block text-sm font-medium mb-2"
                  style={{ color: theme.textSecondary }}
                >
                  {t.adminPasswordLabel}
                </label>
                <input
                  id="join-host-password-input"
                  data-testid="join-host-password-input"
                  type="password"
                  autoFocus
                  value={hostPassword}
                  onChange={(e) => {
                    setHostPassword(e.target.value);
                    if (localHostError) setLocalHostError(null);
                  }}
                  placeholder={t.adminPasswordPlaceholder}
                  className="w-full h-12 px-4 rounded-xl text-base outline-none transition-colors"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${
                      effectiveHostError ? '#EF4444' : theme.borderColor
                    }`,
                    color: theme.textPrimary,
                  }}
                />
                {effectiveHostError && (
                  <p className="mt-1.5 text-xs text-red-400" role="alert">
                    {effectiveHostError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={hostLoggingIn}
                data-testid="join-host-submit"
                className="w-full h-12 rounded-xl font-semibold text-sm text-white flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
                style={{ backgroundColor: theme.accentBg }}
              >
                <KeyRound className="w-4 h-4" />
                <span>
                  {hostLoggingIn ? t.loadingOlder : t.hostEnterBtn}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setHostMode(false);
                  setLocalHostError(null);
                }}
                className="w-full h-10 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textSecondary,
                }}
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{t.backToMemberJoin}</span>
              </button>
            </form>
          ) : (
            <>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Bangladesh Phone Number (Mandatory Gate) */}
            <div>
              <label
                htmlFor="bd-phone-input"
                className="block text-sm font-medium mb-2"
                style={{ color: theme.textSecondary }}
              >
                {t.bdPhoneLabel}
              </label>
              <div
                className="flex items-center h-12 rounded-xl overflow-hidden transition-colors"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${phoneError ? '#EF4444' : theme.borderColor}`,
                }}
              >
                <span
                  className="h-full px-3 flex items-center gap-1.5 text-xs font-mono-nums font-semibold shrink-0"
                  style={{
                    backgroundColor: theme.accentSoftBg,
                    color: theme.accentText,
                    borderRight: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>+88</span>
                </span>
                <input
                  ref={phoneInputRef}
                  id="bd-phone-input"
                  type="tel"
                  inputMode="numeric"
                  autoFocus
                  maxLength={16}
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    if (phoneError) setPhoneError(null);
                  }}
                  placeholder={t.bdPhonePlaceholder}
                  className="flex-1 h-full px-3.5 bg-transparent text-base font-mono-nums outline-none"
                  style={{ color: theme.textPrimary }}
                />
              </div>
              {phoneError ? (
                <p className="mt-1.5 text-xs text-red-400" role="alert">
                  {phoneError}
                </p>
              ) : (
                <p
                  className="mt-1.5 text-[11px] leading-snug"
                  style={{ color: theme.textMuted }}
                >
                  {t.bdPhonePrivacyNote}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="nickname-input"
                className="block text-sm font-medium mb-2"
                style={{ color: theme.textSecondary }}
              >
                {t.nicknameLabel}
              </label>
              <input
                id="nickname-input"
                type="text"
                maxLength={24}
                value={nickname}
                onChange={(e) => {
                  setNickname(e.target.value);
                  if (nameError) setNameError(null);
                }}
                placeholder={t.nicknamePlaceholder}
                className="w-full h-12 px-4 rounded-xl text-base outline-none transition-colors"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${nameError ? '#EF4444' : theme.borderColor}`,
                  color: theme.textPrimary,
                }}
              />
              {nameError && (
                <p className="mt-1.5 text-xs text-red-400" role="alert">
                  {nameError}
                </p>
              )}
            </div>

            <div>
              <span
                className="block text-sm font-medium mb-2.5"
                style={{ color: theme.textSecondary }}
              >
                {t.avatarColorLabel}
              </span>
              <div className="flex flex-wrap items-center gap-2.5">
                {AVATAR_COLORS.map((color) => {
                  const active = avatarColor === color;
                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setAvatarColor(color)}
                      aria-label={`Select color ${color}`}
                      className="w-9 h-9 rounded-full flex items-center justify-center transition-transform cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2"
                      style={{
                        backgroundColor: color,
                        transform: active ? 'scale(1.12)' : 'scale(1)',
                        boxShadow: active
                          ? `0 0 0 2px ${theme.surfaceBg}, 0 0 0 4px ${color}`
                          : 'none',
                      }}
                    />
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-12 rounded-xl font-medium text-sm text-white flex items-center justify-center gap-2 transition-colors cursor-pointer"
              style={{ backgroundColor: theme.accentBg }}
            >
              <span>{t.joinRoom}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* 1-Tap Instant Guest Entry (still requires BD phone above) */}
          <div className="my-4 flex items-center gap-3">
            <div
              className="flex-1 h-px"
              style={{ backgroundColor: theme.borderColor }}
            />
            <span className="text-xs" style={{ color: theme.textMuted }}>
              {t.orDivider}
            </span>
            <div
              className="flex-1 h-px"
              style={{ backgroundColor: theme.borderColor }}
            />
          </div>

          <button
            type="button"
            onClick={handleInstantGuest}
            className="w-full h-11 rounded-xl font-medium text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            style={{
              backgroundColor: theme.accentSoftBg,
              border: `1px solid ${theme.accentBorder}`,
              color: theme.accentText,
            }}
          >
            <UserPlus className="w-4 h-4" />
            <span>{t.joinAsGuest}</span>
          </button>

          {onHostPasswordLogin && (
            <button
              type="button"
              data-testid="host-login-toggle"
              onClick={() => {
                setHostMode(true);
                setLocalHostError(null);
              }}
              className="mt-2.5 w-full h-10 rounded-xl font-medium text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textSecondary,
              }}
            >
              <KeyRound className="w-3.5 h-3.5" style={{ color: theme.accentText }} />
              <span>{t.hostLoginToggle}</span>
            </button>
          )}
            </>
          )}

          <div
            className="mt-6 pt-5 flex items-center justify-between text-xs"
            style={{
              borderTop: `1px solid ${theme.borderColor}`,
              color: theme.textMuted,
            }}
          >
            <span className="flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              Voice · Video · Screen
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              Host Protected
            </span>
          </div>
        </div>
      </main>

      <footer
        className="relative z-10 w-full max-w-5xl mx-auto text-center text-xs"
        style={{ color: theme.textMuted }}
      >
        ARFANMesscent · Mobile &amp; Desktop
      </footer>
    </div>
  );
}
