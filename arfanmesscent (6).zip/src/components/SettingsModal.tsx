import React, { useEffect, useRef, useState } from 'react';
import {
  Bell,
  Check,
  Copy,
  Download,
  ExternalLink,
  Globe,
  ImagePlus,
  Moon,
  Palette,
  Shield,
  Sun,
  Trash2,
  UserCheck,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { THEME_SPECS, WALLPAPER_PRESETS } from '../shared/chatRules';
import type {
  PrivacyAudience,
  ThemeId,
  ThemeSpec,
  UserPrivacySettings,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { downloadVerifiedFile } from '../utils/downloadHelper';
import { uploadMediaFile } from '../utils/storageHelper';

interface SettingsModalProps {
  open: boolean;
  clientId: string;
  theme: ThemeSpec;
  personalThemeId: ThemeId | null;
  personalWallpaperUrl: string | null;
  soundEnabled: boolean;
  browserNotifEnabled: boolean;
  notifPermission: NotificationPermission | 'unsupported';
  privacy: UserPrivacySettings;
  blockedPeerIds: string[];
  mutedRoomIds: string[];
  profilesById: Record<string, UserProfile>;
  lang: Lang;
  onClose: () => void;
  onChangePersonalTheme: (themeId: ThemeId | null) => void;
  onChangePersonalWallpaper: (url: string | null) => void;
  onToggleSound: () => void;
  onToggleBrowserNotif: () => void;
  onRequestBrowserNotifPermission: () => void;
  onUpdatePrivacy: (next: UserPrivacySettings) => Promise<void>;
  onUnblockPeer: (peerId: string) => void;
  onUnmuteRoom: (roomId: string) => void;
}

export function SettingsModal({
  open,
  clientId,
  theme,
  personalThemeId,
  personalWallpaperUrl,
  soundEnabled,
  browserNotifEnabled,
  notifPermission,
  privacy,
  blockedPeerIds,
  mutedRoomIds,
  profilesById,
  lang,
  onClose,
  onChangePersonalTheme,
  onChangePersonalWallpaper,
  onToggleSound,
  onToggleBrowserNotif,
  onRequestBrowserNotifPermission,
  onUpdatePrivacy,
  onUnblockPeer,
  onUnmuteRoom,
}: SettingsModalProps) {
  const t = COPY[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingWallpaper, setUploadingWallpaper] = useState(false);
  const [wallpaperError, setWallpaperError] = useState<string | null>(null);
  const [copiedPublicUrl, setCopiedPublicUrl] = useState(false);
  const [downloadingKey, setDownloadingKey] = useState<'zip' | 'html' | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const publicLiveUrl =
    'https://ais-pre-ninkkcapv3lnbh7ktm5ame-417594258398.asia-southeast1.run.app';

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, open]);

  if (!open) return null;

  const handleWallpaperPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setWallpaperError(null);
    setUploadingWallpaper(true);
    try {
      const res = await uploadMediaFile(
        file,
        'wallpapers',
        clientId,
        file.name
      );
      onChangePersonalWallpaper(res.url);
    } catch (err) {
      setWallpaperError(
        err instanceof Error ? err.message : 'Failed to upload wallpaper.'
      );
    } finally {
      setUploadingWallpaper(false);
    }
  };

  const audienceOptions: { value: PrivacyAudience; label: string }[] = [
    { value: 'everyone', label: t.everyoneOption },
    { value: 'contacts', label: t.contactsOption },
    { value: 'nobody', label: t.nobodyOption },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.settingsTitle}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full sm:max-w-lg max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl space-y-6"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold">{t.settingsTitle}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. Appearance, Light/Dark & Personal Wallpaper */}
        <section className="space-y-3">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4" style={{ color: theme.accentText }} />
            <h3 className="text-sm font-semibold">{t.appearanceSection}</h3>
          </div>

          {/* Quick Light / Dark switch */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => onChangePersonalTheme(null)}
              className="min-h-[42px] px-2.5 rounded-xl text-xs font-medium cursor-pointer"
              style={{
                backgroundColor: !personalThemeId
                  ? theme.accentSoftBg
                  : theme.canvasBg,
                border: `1px solid ${
                  !personalThemeId ? theme.accentBorder : theme.borderColor
                }`,
                color: !personalThemeId ? theme.accentText : theme.textSecondary,
              }}
            >
              {t.roomDefaultTheme}
            </button>
            <button
              type="button"
              onClick={() => onChangePersonalTheme('clean-daylight')}
              className="min-h-[42px] px-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor:
                  personalThemeId === 'clean-daylight'
                    ? theme.accentSoftBg
                    : theme.canvasBg,
                border: `1px solid ${
                  personalThemeId === 'clean-daylight'
                    ? theme.accentBorder
                    : theme.borderColor
                }`,
                color:
                  personalThemeId === 'clean-daylight'
                    ? theme.accentText
                    : theme.textSecondary,
              }}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>Light</span>
            </button>
            <button
              type="button"
              onClick={() => onChangePersonalTheme('midnight-violet')}
              className="min-h-[42px] px-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor:
                  personalThemeId && personalThemeId !== 'clean-daylight'
                    ? theme.accentSoftBg
                    : theme.canvasBg,
                border: `1px solid ${
                  personalThemeId && personalThemeId !== 'clean-daylight'
                    ? theme.accentBorder
                    : theme.borderColor
                }`,
                color:
                  personalThemeId && personalThemeId !== 'clean-daylight'
                    ? theme.accentText
                    : theme.textSecondary,
              }}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>Dark</span>
            </button>
          </div>

          {/* All 20 Custom Themes */}
          <div className="space-y-2">
            <span className="text-xs font-medium block" style={{ color: theme.textSecondary }}>
              {t.themesGalleryTitle}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto chat-scroll pr-1">
              {Object.values(THEME_SPECS).map((spec) => {
                const selected = personalThemeId === spec.id;
                return (
                  <button
                    key={spec.id}
                    type="button"
                    data-testid={`settings-theme-${spec.id}`}
                    onClick={() => onChangePersonalTheme(spec.id)}
                    className="min-h-[42px] px-3 rounded-xl flex items-center justify-between gap-2 text-left cursor-pointer"
                    style={{
                      backgroundColor: selected ? theme.accentSoftBg : theme.canvasBg,
                      border: `1px solid ${
                        selected ? theme.accentBorder : theme.borderColor
                      }`,
                    }}
                  >
                    <span className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-5 h-5 rounded-md shrink-0"
                        style={{
                          backgroundColor: spec.swatchPrimary,
                          border: `2px solid ${spec.swatchSecondary}`,
                        }}
                      />
                      <span className="text-xs font-medium truncate">
                        {lang === 'bn' ? spec.nameBn : spec.name}
                      </span>
                    </span>
                    {selected && (
                      <Check
                        className="w-3.5 h-3.5 shrink-0"
                        style={{ color: theme.accentText }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 20 Personal Wallpaper Designs + Custom Upload */}
          <div className="pt-2 space-y-2.5">
            <span className="text-xs font-medium block" style={{ color: theme.textSecondary }}>
              {t.personalWallpaperLabel} · {t.wallpapersGalleryTitle}
            </span>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-48 overflow-y-auto chat-scroll pr-1">
              {WALLPAPER_PRESETS.map((wp) => {
                const active = personalWallpaperUrl === wp.url;
                return (
                  <button
                    key={wp.id}
                    type="button"
                    data-testid={`settings-wallpaper-${wp.id}`}
                    onClick={() => onChangePersonalWallpaper(active ? null : wp.url)}
                    title={lang === 'bn' ? wp.nameBn : wp.name}
                    className="h-12 rounded-xl overflow-hidden relative flex items-end p-1 cursor-pointer transition-transform"
                    style={{
                      backgroundImage: `url("${wp.url}")`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                      border: active
                        ? `2px solid ${theme.accentText}`
                        : `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <span className="text-[9px] font-semibold px-1 py-0.5 rounded bg-black/60 text-white truncate w-full text-center">
                      {lang === 'bn' ? wp.nameBn : wp.name}
                    </span>
                  </button>
                );
              })}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleWallpaperPick}
              className="hidden"
              aria-label={t.personalWallpaperLabel}
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={uploadingWallpaper}
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 min-h-[42px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                style={{ backgroundColor: theme.accentBg }}
              >
                <ImagePlus className="w-4 h-4" />
                <span>
                  {uploadingWallpaper
                    ? t.uploadingBackground
                    : personalWallpaperUrl
                      ? t.changeBackground
                      : t.uploadBackground}
                </span>
              </button>
              {personalWallpaperUrl && (
                <button
                  type="button"
                  onClick={() => onChangePersonalWallpaper(null)}
                  className="min-h-[42px] px-3 rounded-xl text-xs font-medium text-red-400 bg-red-500/15 flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{t.removeBackground}</span>
                </button>
              )}
            </div>
            {wallpaperError && (
              <p className="text-xs text-red-400" role="alert">
                {wallpaperError}
              </p>
            )}
          </div>
        </section>

        {/* 2. Notifications & Sounds */}
        <section
          className="pt-5 space-y-3"
          style={{ borderTop: `1px solid ${theme.borderColor}` }}
        >
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4" style={{ color: theme.accentText }} />
            <h3 className="text-sm font-semibold">{t.notificationsSection}</h3>
          </div>

          <button
            type="button"
            onClick={onToggleSound}
            className="w-full min-h-[44px] px-3.5 rounded-xl flex items-center justify-between gap-2 text-xs font-medium cursor-pointer"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <span className="flex items-center gap-2">
              {soundEnabled ? (
                <Volume2 className="w-4 h-4" style={{ color: theme.accentText }} />
              ) : (
                <VolumeX className="w-4 h-4" style={{ color: theme.textMuted }} />
              )}
              <span>{t.notificationSoundLabel}</span>
            </span>
            <span
              className="font-semibold"
              style={{ color: soundEnabled ? '#34D399' : theme.textMuted }}
            >
              {soundEnabled ? 'ON' : 'OFF'}
            </span>
          </button>

          <div
            className="min-h-[44px] px-3.5 py-2 rounded-xl flex items-center justify-between gap-2 text-xs font-medium"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <span>{t.browserNotifLabel}</span>
            {notifPermission === 'granted' ? (
              <button
                type="button"
                onClick={onToggleBrowserNotif}
                className="px-3 py-1.5 rounded-lg font-semibold cursor-pointer"
                style={{
                  backgroundColor: browserNotifEnabled
                    ? 'rgba(16, 185, 129, 0.16)'
                    : theme.surfaceBg,
                  color: browserNotifEnabled ? '#34D399' : theme.textMuted,
                }}
              >
                {browserNotifEnabled ? t.notifEnabled : 'OFF'}
              </button>
            ) : notifPermission === 'denied' ? (
              <span className="text-red-400">{t.notifDenied}</span>
            ) : notifPermission === 'unsupported' ? (
              <span style={{ color: theme.textMuted }}>Unavailable</span>
            ) : (
              <button
                type="button"
                onClick={onRequestBrowserNotifPermission}
                className="px-3 py-1.5 rounded-lg text-white font-semibold cursor-pointer"
                style={{ backgroundColor: theme.accentBg }}
              >
                {t.enableNotifBtn}
              </button>
            )}
          </div>
        </section>

        {/* 3. Privacy & Safety */}
        <section
          className="pt-5 space-y-3"
          style={{ borderTop: `1px solid ${theme.borderColor}` }}
        >
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4" style={{ color: theme.accentText }} />
            <h3 className="text-sm font-semibold">{t.privacySection}</h3>
          </div>

          {(
            [
              { key: 'lastSeen', label: t.lastSeenPrivacy },
              { key: 'profilePhoto', label: t.photoPrivacy },
              { key: 'status', label: t.statusPrivacyDefault },
            ] as const
          ).map(({ key, label }) => (
            <div key={key} className="space-y-1.5">
              <span
                className="text-xs font-medium block"
                style={{ color: theme.textSecondary }}
              >
                {label}
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {audienceOptions.map((opt) => {
                  const active = privacy[key] === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() =>
                        void onUpdatePrivacy({
                          ...privacy,
                          [key]: opt.value,
                        })
                      }
                      className="min-h-[40px] px-2 rounded-xl text-xs font-medium cursor-pointer"
                      style={{
                        backgroundColor: active ? theme.accentBg : theme.canvasBg,
                        border: `1px solid ${
                          active ? theme.accentBg : theme.borderColor
                        }`,
                        color: active ? '#FFFFFF' : theme.textSecondary,
                      }}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Personal Blocked List */}
          {blockedPeerIds.length > 0 && (
            <div className="pt-2 space-y-2">
              <span className="text-xs font-semibold block">
                {t.blockedUsersTitle} ({blockedPeerIds.length})
              </span>
              <ul className="space-y-1.5">
                {blockedPeerIds.map((pid) => {
                  const prof = profilesById[pid];
                  return (
                    <li
                      key={pid}
                      className="px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
                      style={{
                        backgroundColor: theme.canvasBg,
                        border: `1px solid ${theme.borderColor}`,
                      }}
                    >
                      <span className="truncate font-medium">
                        {prof?.displayName || pid}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUnblockPeer(pid)}
                        className="px-2.5 py-1 rounded-lg text-emerald-400 bg-emerald-500/15 flex items-center gap-1 cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>{t.unblockUser}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}

          {/* Muted Rooms */}
          {mutedRoomIds.length > 0 && (
            <div className="pt-2 space-y-2">
              <span className="text-xs font-semibold block">
                {t.mutedBadge} ({mutedRoomIds.length})
              </span>
              <ul className="space-y-1.5">
                {mutedRoomIds.map((rid) => (
                  <li
                    key={rid}
                    className="px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <span className="truncate font-medium">{rid}</span>
                    <button
                      type="button"
                      onClick={() => onUnmuteRoom(rid)}
                      className="px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer"
                      style={{
                        backgroundColor: theme.accentSoftBg,
                        color: theme.accentText,
                      }}
                    >
                      {t.unmuteRoom}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>

        {/* 4. Free Publish & Download */}
        <section
          className="pt-5 space-y-3"
          style={{ borderTop: `1px solid ${theme.borderColor}` }}
        >
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4" style={{ color: theme.accentText }} />
            <h3 className="text-sm font-semibold">{t.publishFreeTitle}</h3>
          </div>
          <p className="text-xs leading-relaxed" style={{ color: theme.textSecondary }}>
            {t.publishFreeDesc}
          </p>

          <div
            className="p-2.5 rounded-xl flex items-center justify-between gap-2"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <span
              className="text-[11px] font-mono-nums truncate select-all"
              style={{ color: theme.textSecondary }}
            >
              {publicLiveUrl}
            </span>
            <button
              type="button"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(publicLiveUrl);
                  setCopiedPublicUrl(true);
                  window.setTimeout(() => setCopiedPublicUrl(false), 2000);
                } catch {
                  // Ignore clipboard errors
                }
              }}
              className="h-8 px-2.5 rounded-lg text-xs font-medium text-white flex items-center gap-1 shrink-0 cursor-pointer"
              style={{ backgroundColor: theme.accentBg }}
            >
              {copiedPublicUrl ? (
                <Check className="w-3.5 h-3.5" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedPublicUrl ? t.copied : t.copyPublicUrl}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              disabled={downloadingKey !== null}
              onClick={async () => {
                setDownloadingKey('zip');
                setDownloadError(null);
                try {
                  await downloadVerifiedFile(
                    '/api/download/netlify-pack',
                    'arfanmesscent-free-site.zip',
                    'zip'
                  );
                } catch (err) {
                  setDownloadError(
                    err instanceof Error ? err.message : 'ZIP download failed.'
                  );
                } finally {
                  setDownloadingKey(null);
                }
              }}
              className="min-h-[42px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 text-center cursor-pointer disabled:opacity-60"
              style={{ backgroundColor: theme.accentBg }}
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>
                {downloadingKey === 'zip' ? t.downloadingFile : t.downloadZipPack}
              </span>
            </button>

            <button
              type="button"
              disabled={downloadingKey !== null}
              onClick={async () => {
                setDownloadingKey('html');
                setDownloadError(null);
                try {
                  await downloadVerifiedFile(
                    '/api/download/single-html',
                    'index.html',
                    'html'
                  );
                } catch (err) {
                  setDownloadError(
                    err instanceof Error ? err.message : 'HTML download failed.'
                  );
                } finally {
                  setDownloadingKey(null);
                }
              }}
              className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 text-center cursor-pointer disabled:opacity-60"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>
                {downloadingKey === 'html'
                  ? t.downloadingFile
                  : t.downloadSingleHtml}
              </span>
            </button>

            <a
              href="https://app.netlify.com/drop"
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 text-center"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.accentText,
              }}
            >
              <ExternalLink className="w-4 h-4 shrink-0" />
              <span>{t.openNetlifyDrop}</span>
            </a>
          </div>
          {downloadError && (
            <p className="text-xs text-red-400" role="alert">
              {downloadError}
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
