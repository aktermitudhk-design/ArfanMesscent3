import React, { useState } from 'react';
import { Ban, KeyRound, ShieldCheck } from 'lucide-react';
import type { ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

interface BlockedScreenProps {
  reason?: string;
  theme: ThemeSpec;
  lang: Lang;
  onHostUnlock?: (password: string) => Promise<boolean>;
}

export function BlockedScreen({
  reason,
  theme,
  lang,
  onHostUnlock,
}: BlockedScreenProps) {
  const t = COPY[lang];
  const [showHostForm, setShowHostForm] = useState(false);
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleUnlockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onHostUnlock || !password.trim() || submitting) return;
    setSubmitting(true);
    setErrorMsg(null);
    try {
      const ok = await onHostUnlock(password);
      if (!ok) {
        setErrorMsg(t.wrongPassword);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="min-h-dvh w-full flex items-center justify-center px-4"
      style={{ backgroundColor: theme.canvasBg, color: theme.textPrimary }}
    >
      <div
        className="max-w-md w-full rounded-2xl p-8 text-center"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
        }}
      >
        <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto mb-4">
          <Ban className="w-6 h-6" />
        </div>
        <h1 className="font-display text-xl font-bold mb-2">{t.blockedTitle}</h1>
        <p className="text-sm leading-relaxed" style={{ color: theme.textMuted }}>
          {reason || t.blockedSub}
        </p>

        {onHostUnlock && (
          <div
            className="mt-6 pt-5"
            style={{ borderTop: `1px solid ${theme.borderColor}` }}
          >
            {!showHostForm ? (
              <button
                type="button"
                data-testid="blocked-host-unlock-toggle"
                onClick={() => setShowHostForm(true)}
                className="text-xs font-medium inline-flex items-center gap-1.5 px-3 py-2 rounded-xl cursor-pointer transition-colors"
                style={{
                  backgroundColor: theme.accentSoftBg,
                  color: theme.accentText,
                  border: `1px solid ${theme.accentBorder}`,
                }}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.hostUnlockPrompt}</span>
              </button>
            ) : (
              <form onSubmit={handleUnlockSubmit} className="space-y-3 text-left">
                <label
                  htmlFor="blocked-host-password"
                  className="block text-xs font-semibold"
                  style={{ color: theme.textSecondary }}
                >
                  {t.adminPasswordLabel}
                </label>
                <input
                  id="blocked-host-password"
                  type="password"
                  autoFocus
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.adminPasswordPlaceholder}
                  className="w-full h-11 px-3.5 rounded-xl text-sm outline-none"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${errorMsg ? '#EF4444' : theme.borderColor}`,
                    color: theme.textPrimary,
                  }}
                />
                {errorMsg && (
                  <p className="text-xs text-red-400" role="alert">
                    {errorMsg}
                  </p>
                )}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowHostForm(false);
                      setErrorMsg(null);
                    }}
                    className="h-10 px-3 rounded-xl text-xs font-medium cursor-pointer"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                      color: theme.textMuted,
                    }}
                  >
                    {t.cancelReply}
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    data-testid="blocked-host-unlock-submit"
                    className="flex-1 h-10 px-4 rounded-xl text-xs font-semibold text-white inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                    style={{ backgroundColor: theme.accentBg }}
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>{submitting ? t.loadingOlder : t.hostUnlockBtn}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
