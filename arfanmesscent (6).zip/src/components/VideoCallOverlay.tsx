import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Mic,
  MicOff,
  Minimize2,
  MonitorOff,
  MonitorUp,
  PhoneOff,
  Sparkles,
  SwitchCamera,
  Video,
  VideoOff,
  Volume2,
} from 'lucide-react';
import type { AudioOutputDeviceInfo } from '../hooks/useVideoCall';
import {
  CALL_AVATAR_PRESETS,
  formatDuration,
  getInitials,
} from '../shared/chatRules';
import type {
  CallAvatarId,
  CallMode,
  CallParticipant,
  DirectPeer,
  ThemeSpec,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

interface RemoteAudioPlayerProps {
  peerId: string;
  stream: MediaStream;
  selectedSinkId?: string;
  onAutoplayBlocked: () => void;
  registerAudioEl: (peerId: string, el: HTMLAudioElement | null) => void;
}

function RemoteAudioPlayer({
  peerId,
  stream,
  selectedSinkId,
  onAutoplayBlocked,
  registerAudioEl,
}: RemoteAudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const el = audioRef.current;
    registerAudioEl(peerId, el);
    return () => registerAudioEl(peerId, null);
  }, [peerId, registerAudioEl]);

  useEffect(() => {
    const el = audioRef.current as
      | (HTMLAudioElement & { setSinkId?: (id: string) => Promise<void> })
      | null;
    if (!el || !selectedSinkId || typeof el.setSinkId !== 'function') return;
    void el.setSinkId(selectedSinkId).catch(() => {});
  }, [selectedSinkId]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    if (el.srcObject !== stream) {
      el.srcObject = stream;
    }
    el.volume = 1;
    el.muted = false;
    el.play().catch(() => {
      onAutoplayBlocked();
    });
  }, [onAutoplayBlocked, stream]);

  return (
    <audio
      ref={audioRef}
      autoPlay
      playsInline
      data-testid={`remote-audio-${peerId}`}
      className="w-0 h-0 opacity-0 pointer-events-none absolute"
    />
  );
}

interface VideoTileProps {
  stream: MediaStream | null;
  nickname: string;
  rawNickname?: string;
  avatarColor: string;
  videoEnabled: boolean;
  audioEnabled: boolean;
  screenSharing?: boolean;
  screenShareLabel?: string;
  mirrored?: boolean;
  badgeText?: string;
  theme: ThemeSpec;
}

function VideoTile({
  stream,
  nickname,
  rawNickname,
  avatarColor,
  videoEnabled,
  audioEnabled,
  screenSharing = false,
  screenShareLabel,
  mirrored = false,
  badgeText,
  theme,
}: VideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [, setTrackTick] = useState(0);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (el.srcObject !== stream) {
      el.srcObject = stream;
    }
    if (stream) {
      el.play().catch(() => {});
    }
  }, [stream, videoEnabled, screenSharing]);

  useEffect(() => {
    if (!stream) return;
    const bump = () => {
      setTrackTick((c) => c + 1);
      const el = videoRef.current;
      if (el) {
        el.play().catch(() => {});
      }
    };
    stream.addEventListener('addtrack', bump);
    stream.addEventListener('removetrack', bump);
    const tracks = stream.getVideoTracks();
    tracks.forEach((tr) => {
      tr.addEventListener('unmute', bump);
      tr.addEventListener('mute', bump);
      tr.addEventListener('ended', bump);
    });
    return () => {
      stream.removeEventListener('addtrack', bump);
      stream.removeEventListener('removetrack', bump);
      tracks.forEach((tr) => {
        tr.removeEventListener('unmute', bump);
        tr.removeEventListener('mute', bump);
        tr.removeEventListener('ended', bump);
      });
    };
  }, [stream]);

  const hasLiveVideo =
    (videoEnabled || screenSharing) &&
    Boolean(stream) &&
    Boolean(stream?.getVideoTracks().some((t) => t.readyState === 'live'));

  return (
    <div
      className="relative aspect-video rounded-2xl overflow-hidden flex items-center justify-center"
      style={{
        backgroundColor: theme.surfaceBg,
        border: `1px solid ${
          screenSharing ? theme.accentBorder : theme.borderColor
        }`,
      }}
    >
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        onLoadedMetadata={(e) => {
          void e.currentTarget.play().catch(() => {});
        }}
        onCanPlay={(e) => {
          void e.currentTarget.play().catch(() => {});
        }}
        className={`w-full h-full transition-opacity duration-200 ${
          screenSharing ? 'object-contain bg-black' : 'object-cover'
        } ${mirrored && !screenSharing ? '-scale-x-100' : ''} ${
          hasLiveVideo ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      />

      {!hasLiveVideo && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-4">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-lg font-bold text-white shadow-lg"
            style={{ backgroundColor: avatarColor }}
          >
            {getInitials(rawNickname || nickname)}
          </div>
          {badgeText && (
            <span className="text-xs" style={{ color: theme.textMuted }}>
              {badgeText}
            </span>
          )}
        </div>
      )}

      {screenSharing && screenShareLabel && (
        <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold text-white bg-indigo-600/90 backdrop-blur-xs flex items-center gap-1.5 pointer-events-none">
          <MonitorUp className="w-3.5 h-3.5" />
          <span>{screenShareLabel}</span>
        </div>
      )}

      <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2 pointer-events-none">
        <span className="px-2.5 py-1 rounded-lg text-xs font-medium text-white bg-black/60 backdrop-blur-xs truncate">
          {nickname}
        </span>

        {!audioEnabled && (
          <span
            className="w-7 h-7 rounded-lg bg-red-600/90 text-white flex items-center justify-center shrink-0"
            aria-label="Muted"
          >
            <MicOff className="w-3.5 h-3.5" />
          </span>
        )}
      </div>
    </div>
  );
}

interface VideoCallOverlayProps {
  inCall: boolean;
  isMinimized: boolean;
  callMode: CallMode;
  callPeer: DirectPeer | null;
  micEnabled: boolean;
  cameraEnabled: boolean;
  canSwitchCamera: boolean;
  audioOutputs: AudioOutputDeviceInfo[];
  selectedAudioOutputId: string;
  screenSharing: boolean;
  screenAudioActive?: boolean;
  avatarFilter?: CallAvatarId;
  callDurationSec: number;
  localStream: MediaStream | null;
  remoteStreams: Record<string, MediaStream>;
  callParticipants: CallParticipant[];
  currentClientId: string;
  currentNickname: string;
  currentAvatarColor: string;
  callNotice: string | null;
  theme: ThemeSpec;
  lang: Lang;
  onToggleMic: () => void;
  onToggleCamera: () => void;
  onSwitchCamera: () => void;
  onSelectAudioOutput: (deviceId: string) => void;
  onToggleScreenShare: () => void;
  onSelectAvatarFilter?: (avatarId: CallAvatarId) => void;
  onSetMinimized: (minimized: boolean) => void;
  onLeaveCall: () => void;
}

export function VideoCallOverlay({
  inCall,
  isMinimized,
  callMode,
  callPeer,
  micEnabled,
  cameraEnabled,
  canSwitchCamera,
  audioOutputs,
  selectedAudioOutputId,
  screenSharing,
  screenAudioActive = false,
  avatarFilter = 'none',
  callDurationSec,
  localStream,
  remoteStreams,
  callParticipants,
  currentClientId,
  currentNickname,
  currentAvatarColor,
  callNotice,
  theme,
  lang,
  onToggleMic,
  onToggleCamera,
  onSwitchCamera,
  onSelectAudioOutput,
  onToggleScreenShare,
  onSelectAvatarFilter,
  onSetMinimized,
  onLeaveCall,
}: VideoCallOverlayProps) {
  const [audioBlocked, setAudioBlocked] = useState(false);
  const [showAvatarBar, setShowAvatarBar] = useState(false);
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  const registerAudioEl = useCallback(
    (peerId: string, el: HTMLAudioElement | null) => {
      if (el) {
        audioElementsRef.current.set(peerId, el);
      } else {
        audioElementsRef.current.delete(peerId);
      }
    },
    []
  );

  const handleUnlockAudio = useCallback(() => {
    for (const el of audioElementsRef.current.values()) {
      el.muted = false;
      el.volume = 1;
      void el.play().catch(() => {});
    }
    setAudioBlocked(false);
  }, []);

  if (!inCall) return null;

  const t = COPY[lang];
  const remoteParticipants = callParticipants.filter(
    (p) => p.clientId !== currentClientId
  );

  const callHeading =
    callMode === 'personal' && callPeer
      ? `${t.personalCallLabel}: ${callPeer.nickname}`
      : `${t.groupCallLabel} (${callParticipants.length})`;

  const remoteAudioNodes = Object.entries(remoteStreams).map(
    ([peerId, stream]) => (
      <RemoteAudioPlayer
        key={peerId}
        peerId={peerId}
        stream={stream}
        selectedSinkId={selectedAudioOutputId}
        onAutoplayBlocked={() => setAudioBlocked(true)}
        registerAudioEl={registerAudioEl}
      />
    )
  );

  if (isMinimized) {
    return (
      <>
        {remoteAudioNodes}
        <div
          className="px-3 sm:px-5 py-2 flex items-center justify-between gap-2 sm:gap-3 shrink-0"
          style={{
            backgroundColor: 'rgba(16, 185, 129, 0.14)',
            borderBottom: '1px solid rgba(52, 211, 153, 0.3)',
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            <span className="text-xs font-semibold truncate">
              {callMode === 'personal' && callPeer
                ? `${t.inCallLabel} · ${callPeer.nickname}`
                : `${t.inCallLabel} · ${callParticipants.length}`}
            </span>
            <span
              data-testid="call-duration-timer"
              className="text-xs font-mono-nums opacity-80 shrink-0"
            >
              {formatDuration(callDurationSec)}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {audioBlocked && (
              <button
                type="button"
                onClick={handleUnlockAudio}
                className="h-9 px-2.5 rounded-xl text-xs font-semibold bg-amber-500 text-black flex items-center gap-1 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{t.tapToEnableAudio}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onToggleMic}
              aria-label={micEnabled ? t.muteMic : t.unmuteMic}
              className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer"
              style={{
                backgroundColor: micEnabled ? theme.surfaceBg : '#DC2626',
                color: micEnabled ? theme.textPrimary : '#FFFFFF',
              }}
            >
              {micEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={onToggleCamera}
              aria-label={cameraEnabled ? t.cameraOff : t.cameraOn}
              className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer"
              style={{
                backgroundColor: cameraEnabled ? theme.surfaceBg : '#DC2626',
                color: cameraEnabled ? theme.textPrimary : '#FFFFFF',
              }}
            >
              {cameraEnabled ? (
                <Video className="w-4 h-4" />
              ) : (
                <VideoOff className="w-4 h-4" />
              )}
            </button>

            <button
              type="button"
              onClick={onToggleScreenShare}
              aria-label={screenSharing ? t.stopScreenShare : t.screenShare}
              className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer"
              style={{
                backgroundColor: screenSharing
                  ? theme.accentBg
                  : theme.surfaceBg,
                color: screenSharing ? '#FFFFFF' : theme.textPrimary,
              }}
            >
              {screenSharing ? (
                <MonitorOff className="w-4 h-4" />
              ) : (
                <MonitorUp className="w-4 h-4" />
              )}
            </button>

            <button
              type="button"
              onClick={() => onSetMinimized(false)}
              aria-label={t.expandCall}
              className="h-9 px-2.5 rounded-xl text-xs font-medium flex items-center gap-1 cursor-pointer"
              style={{
                backgroundColor: theme.surfaceBg,
                color: theme.textPrimary,
              }}
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.expandCall}</span>
            </button>

            <button
              type="button"
              onClick={onLeaveCall}
              aria-label={t.leaveCall}
              className="w-9 h-9 rounded-xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center cursor-pointer"
            >
              <PhoneOff className="w-4 h-4" />
            </button>
          </div>
        </div>
      </>
    );
  }

  return (
    <div
      data-testid="video-call-overlay"
      className="fixed inset-0 z-50 flex flex-col p-3 sm:p-6 bg-black/85 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={callHeading}
    >
      {remoteAudioNodes}

      {/* Top Bar */}
      <div className="flex items-center justify-between gap-3 mb-4 shrink-0">
        <div className="flex items-center gap-2.5 text-white min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <h2 className="font-display text-base font-bold truncate">
            {callHeading}
          </h2>
          <span
            data-testid="call-duration-timer"
            className="text-xs font-mono-nums text-emerald-300 shrink-0"
          >
            {formatDuration(callDurationSec)}
          </span>
          {screenSharing && screenAudioActive && (
            <span
              data-testid="screen-audio-active-badge"
              className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0"
            >
              <Volume2 className="w-3 h-3" />
              <span>{t.screenAudioActiveBadge}</span>
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {audioBlocked && (
            <button
              type="button"
              onClick={handleUnlockAudio}
              className="h-10 px-3 rounded-xl text-xs font-semibold bg-amber-500 text-black flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-4 h-4" />
              <span>{t.tapToEnableAudio}</span>
            </button>
          )}

          {audioOutputs.length > 0 && (
            <select
              value={selectedAudioOutputId}
              onChange={(e) => onSelectAudioOutput(e.target.value)}
              aria-label={t.speakerOutput}
              className="hidden sm:block h-10 px-2.5 rounded-xl text-xs text-white bg-white/10 outline-none"
            >
              <option value="" className="text-black">
                {t.speakerOutput}
              </option>
              {audioOutputs.map((out) => (
                <option
                  key={out.deviceId}
                  value={out.deviceId}
                  className="text-black"
                >
                  {out.label}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={() => onSetMinimized(true)}
            aria-label={t.minimizeCall}
            className="h-10 px-3 rounded-xl text-xs font-medium text-white bg-white/10 hover:bg-white/15 flex items-center gap-1.5 cursor-pointer"
          >
            <Minimize2 className="w-4 h-4" />
            <span>{t.minimizeCall}</span>
          </button>
        </div>
      </div>

      {callNotice && (
        <div className="mb-3 px-3.5 py-2 rounded-xl text-xs text-amber-200 bg-amber-500/20 border border-amber-400/30 shrink-0">
          {callNotice === 'screenShareUnsupported'
            ? t.screenShareUnsupported
            : t.cameraHintBlocked}
        </div>
      )}

      {/* Video Grid */}
      <div className="flex-1 min-h-0 overflow-y-auto flex flex-col justify-center">
        <div
          className={`grid gap-3 w-full max-w-5xl mx-auto ${
            remoteParticipants.length === 0
              ? 'grid-cols-1 max-w-xl'
              : remoteParticipants.length === 1
                ? 'grid-cols-1 sm:grid-cols-2'
                : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
          }`}
        >
          <VideoTile
            stream={localStream}
            nickname={`${currentNickname} (${t.you})`}
            rawNickname={currentNickname}
            avatarColor={currentAvatarColor}
            videoEnabled={cameraEnabled}
            audioEnabled={micEnabled}
            screenSharing={screenSharing}
            screenShareLabel={t.screenShareBadge}
            mirrored
            badgeText={t.cameraOffBadge}
            theme={theme}
          />

          {remoteParticipants.map((peer) => (
            <VideoTile
              key={peer.clientId}
              stream={remoteStreams[peer.clientId] || null}
              nickname={peer.nickname}
              avatarColor={peer.avatarColor}
              videoEnabled={peer.videoEnabled}
              audioEnabled={peer.audioEnabled}
              screenSharing={Boolean(peer.screenSharing)}
              screenShareLabel={t.screenShareBadge}
              badgeText={
                peer.videoEnabled || peer.screenSharing
                  ? undefined
                  : t.cameraOffBadge
              }
              theme={theme}
            />
          ))}
        </div>

        {remoteParticipants.length === 0 && (
          <p className="mt-4 text-center text-xs text-zinc-400">
            {t.noPeersInCall}
          </p>
        )}
      </div>

      {/* Live Face Avatar Effects Bar */}
      {showAvatarBar && onSelectAvatarFilter && !screenSharing && (
        <div
          data-testid="call-avatar-strip"
          className="mt-3 max-w-2xl mx-auto w-full rounded-2xl p-2 bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-1.5 overflow-x-auto chat-scroll shrink-0"
        >
          {CALL_AVATAR_PRESETS.map((preset) => {
            const active = avatarFilter === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                data-testid={`call-avatar-${preset.id}`}
                onClick={() => onSelectAvatarFilter(preset.id)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 shrink-0 cursor-pointer transition-colors"
                style={{
                  backgroundColor: active ? theme.accentBg : 'rgba(255,255,255,0.08)',
                  color: '#FFFFFF',
                }}
              >
                <span>{preset.emoji}</span>
                <span>{lang === 'bn' ? preset.labelBn : preset.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Bottom Controls */}
      <div className="mt-4 pt-3 flex flex-wrap items-center justify-center gap-2.5 sm:gap-3 shrink-0">
        <button
          type="button"
          onClick={onToggleMic}
          aria-label={micEnabled ? t.muteMic : t.unmuteMic}
          className="h-12 px-4 rounded-2xl text-sm font-medium flex items-center gap-2 transition-colors cursor-pointer"
          style={{
            backgroundColor: micEnabled ? 'rgba(255,255,255,0.14)' : '#DC2626',
            color: '#FFFFFF',
          }}
        >
          {micEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
          <span className="hidden sm:inline">
            {micEnabled ? t.muteMic : t.unmuteMic}
          </span>
        </button>

        <button
          type="button"
          onClick={onToggleCamera}
          aria-label={cameraEnabled ? t.cameraOff : t.cameraOn}
          className="h-12 px-4 rounded-2xl text-sm font-medium flex items-center gap-2 transition-colors cursor-pointer"
          style={{
            backgroundColor: cameraEnabled
              ? 'rgba(255,255,255,0.14)'
              : '#DC2626',
            color: '#FFFFFF',
          }}
        >
          {cameraEnabled ? (
            <Video className="w-5 h-5" />
          ) : (
            <VideoOff className="w-5 h-5" />
          )}
          <span className="hidden sm:inline">
            {cameraEnabled ? t.cameraOff : t.cameraOn}
          </span>
        </button>

        {onSelectAvatarFilter && !screenSharing && (
          <button
            type="button"
            data-testid="toggle-call-avatars-btn"
            onClick={() => setShowAvatarBar((v) => !v)}
            aria-label={t.faceAvatarLabel}
            className="h-12 px-4 rounded-2xl text-sm font-medium flex items-center gap-2 transition-colors cursor-pointer"
            style={{
              backgroundColor:
                avatarFilter !== 'none' || showAvatarBar
                  ? theme.accentBg
                  : 'rgba(255,255,255,0.14)',
              color: '#FFFFFF',
            }}
          >
            <Sparkles className="w-5 h-5" />
            <span className="hidden sm:inline">{t.faceAvatarLabel}</span>
          </button>
        )}

        {(canSwitchCamera || cameraEnabled) && (
          <button
            type="button"
            onClick={onSwitchCamera}
            aria-label={t.switchCamera}
            title={t.switchCamera}
            className="h-12 px-4 rounded-2xl text-sm font-medium text-white bg-white/14 hover:bg-white/20 flex items-center gap-2 transition-colors cursor-pointer"
          >
            <SwitchCamera className="w-5 h-5" />
            <span className="hidden md:inline">{t.switchCamera}</span>
          </button>
        )}

        <button
          type="button"
          onClick={onToggleScreenShare}
          aria-label={screenSharing ? t.stopScreenShare : t.screenShare}
          className="h-12 px-4 rounded-2xl text-sm font-medium flex items-center gap-2 transition-colors cursor-pointer"
          style={{
            backgroundColor: screenSharing
              ? theme.accentBg
              : 'rgba(255,255,255,0.14)',
            color: '#FFFFFF',
          }}
        >
          {screenSharing ? (
            <MonitorOff className="w-5 h-5" />
          ) : (
            <MonitorUp className="w-5 h-5" />
          )}
          <span className="hidden sm:inline">
            {screenSharing ? t.stopScreenShare : t.screenShare}
          </span>
        </button>

        <button
          type="button"
          onClick={onLeaveCall}
          aria-label={t.leaveCall}
          className="h-12 px-5 rounded-2xl text-sm font-semibold bg-red-600 hover:bg-red-500 text-white flex items-center gap-2 transition-colors cursor-pointer"
        >
          <PhoneOff className="w-5 h-5" />
          <span>{t.leaveCall}</span>
        </button>
      </div>
    </div>
  );
}
