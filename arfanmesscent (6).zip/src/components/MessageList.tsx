import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowDown,
  BarChart2,
  Check,
  CheckCheck,
  Copy,
  Download,
  Edit3,
  FileText,
  Flag,
  Forward,
  MessageSquare,
  Pause,
  Pin,
  Play,
  Reply,
  SmilePlus,
  Trash2,
  X,
} from 'lucide-react';
import {
  canDeleteForEveryone,
  canEditMessage,
  canForwardMessage,
  canViewProfileField,
  formatDuration,
  formatFileSize,
  formatTime,
  getInitials,
  getLatestSeenByMessageMap,
  getMessageReaders,
} from '../shared/chatRules';
import type {
  ChatMessage,
  ChatPoll,
  ReadReceipt,
  ThemeSpec,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';
import { EmojiPickerPopover } from './EmojiPickerPopover';

interface VoiceNotePlayerProps {
  src: string;
  durationSec?: number;
  isOwn: boolean;
  theme: ThemeSpec;
}

function VoiceNotePlayer({
  src,
  durationSec,
  isOwn,
  theme,
}: VoiceNotePlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(durationSec || 0);

  const togglePlay = () => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) {
      el.pause();
      setPlaying(false);
    } else {
      void el.play();
      setPlaying(true);
    }
  };

  return (
    <div className="flex items-center gap-2.5 min-w-[200px] sm:min-w-[230px] py-0.5">
      <audio
        ref={audioRef}
        src={src}
        preload="metadata"
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (Number.isFinite(d) && d > 0) {
            setTotalDuration(d);
          }
        }}
        onTimeUpdate={(e) => {
          const el = e.currentTarget;
          setCurrentTime(el.currentTime);
          const d =
            Number.isFinite(el.duration) && el.duration > 0
              ? el.duration
              : totalDuration;
          setProgress(d > 0 ? Math.min(100, (el.currentTime / d) * 100) : 0);
        }}
        onEnded={() => {
          setPlaying(false);
          setProgress(0);
          setCurrentTime(0);
        }}
      />

      <button
        type="button"
        onClick={togglePlay}
        aria-label={playing ? 'Pause voice note' : 'Play voice note'}
        className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 cursor-pointer"
        style={{
          backgroundColor: isOwn ? 'rgba(255,255,255,0.2)' : theme.accentSoftBg,
          color: isOwn ? '#FFFFFF' : theme.accentText,
        }}
      >
        {playing ? (
          <Pause className="w-4 h-4" />
        ) : (
          <Play className="w-4 h-4 ml-0.5" />
        )}
      </button>

      <div className="flex-1 min-w-0">
        <div
          className="h-1.5 rounded-full overflow-hidden"
          style={{
            backgroundColor: isOwn
              ? 'rgba(255,255,255,0.22)'
              : theme.canvasBg,
          }}
        >
          <div
            className="h-full rounded-full transition-all duration-150"
            style={{
              width: `${progress}%`,
              backgroundColor: isOwn ? '#FFFFFF' : theme.accentBg,
            }}
          />
        </div>
        <div className="mt-1 flex items-center justify-between text-[10px] font-mono-nums opacity-80">
          <span>{formatDuration(playing ? currentTime : totalDuration)}</span>
          <span>Voice</span>
        </div>
      </div>
    </div>
  );
}

interface PollCardProps {
  poll: ChatPoll;
  messageId: string;
  currentClientId: string;
  isOwn: boolean;
  theme: ThemeSpec;
  votesLabel: string;
  onVote: (messageId: string, optionId: string) => void;
}

function PollCard({
  poll,
  messageId,
  currentClientId,
  isOwn,
  theme,
  votesLabel,
  onVote,
}: PollCardProps) {
  const totalVotes = poll.options.reduce(
    (sum, opt) => sum + opt.voterIds.length,
    0
  );

  return (
    <div className="min-w-[230px] sm:min-w-[280px] space-y-2">
      <div className="flex items-start gap-2">
        <BarChart2 className="w-4 h-4 shrink-0 mt-0.5 opacity-85" />
        <p className="font-semibold text-sm leading-snug">{poll.question}</p>
      </div>

      <div className="space-y-1.5">
        {poll.options.map((opt) => {
          const votes = opt.voterIds.length;
          const pct = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
          const voted = opt.voterIds.includes(currentClientId);

          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => onVote(messageId, opt.id)}
              className="w-full relative overflow-hidden rounded-xl px-3 py-2 text-left text-xs transition-colors cursor-pointer"
              style={{
                backgroundColor: isOwn
                  ? 'rgba(0,0,0,0.22)'
                  : theme.canvasBg,
                border: `1px solid ${
                  voted
                    ? isOwn
                      ? 'rgba(255,255,255,0.65)'
                      : theme.accentBg
                    : isOwn
                      ? 'rgba(255,255,255,0.16)'
                      : theme.borderColor
                }`,
              }}
            >
              <div
                className="absolute inset-y-0 left-0 transition-all duration-300"
                style={{
                  width: `${pct}%`,
                  backgroundColor: isOwn
                    ? 'rgba(255,255,255,0.16)'
                    : theme.accentSoftBg,
                }}
              />
              <div className="relative z-10 flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 font-medium truncate">
                  {voted && <Check className="w-3.5 h-3.5 shrink-0" />}
                  <span className="truncate">{opt.label}</span>
                </span>
                <span className="font-mono-nums opacity-85 shrink-0">
                  {pct}% ({votes})
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="text-[11px] font-mono-nums opacity-75">
        {totalVotes} {votesLabel}
      </div>
    </div>
  );
}

interface MessageListProps {
  messages: ChatMessage[];
  readReceipts: ReadReceipt[];
  profilesById: Record<string, UserProfile>;
  isDirectRoom: boolean;
  currentClientId: string;
  isAdmin: boolean;
  pinnedMessageId: string | null;
  searchQuery: string;
  typingUsers: { clientId: string; nickname: string }[];
  hasMoreOlder: boolean;
  loadingOlder: boolean;
  theme: ThemeSpec;
  lang: Lang;
  onAtBottomChange?: (atBottom: boolean) => void;
  onLoadOlder: () => void;
  onReply: (msg: ChatMessage) => void;
  onEditMessage: (messageId: string, nextText: string) => void;
  onForward: (msg: ChatMessage) => void;
  onReportMessage: (msg: ChatMessage) => void;
  onReact: (messageId: string, emoji: string) => void;
  onVotePoll: (messageId: string, optionId: string) => void;
  onPinMessage: (messageId: string | null) => void;
  onDeleteForMe: (messageId: string) => void;
  onDeleteForEveryone: (messageId: string) => void;
  onOpenImage: (src: string, senderName: string) => void;
  onViewSenderProfile: (senderId: string, fallbackName: string, fallbackColor: string) => void;
}

export function MessageList({
  messages,
  readReceipts,
  profilesById,
  isDirectRoom,
  currentClientId,
  isAdmin,
  pinnedMessageId,
  searchQuery,
  typingUsers,
  hasMoreOlder,
  loadingOlder,
  theme,
  lang,
  onAtBottomChange,
  onLoadOlder,
  onReply,
  onEditMessage,
  onForward,
  onReportMessage,
  onReact,
  onVotePoll,
  onPinMessage,
  onDeleteForMe,
  onDeleteForEveryone,
  onOpenImage,
  onViewSenderProfile,
}: MessageListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [atBottom, setAtBottom] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);
  const [activeReactionPickerId, setActiveReactionPickerId] = useState<string | null>(
    null
  );
  const [pendingDeleteMsg, setPendingDeleteMsg] = useState<ChatMessage | null>(
    null
  );
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const prevLenRef = useRef(messages.length);
  const t = COPY[lang];

  const latestSeenByMessage = useMemo(
    () => getLatestSeenByMessageMap(messages, readReceipts, currentClientId),
    [messages, readReceipts, currentClientId]
  );

  useEffect(() => {
    if (!pendingDeleteMsg) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setPendingDeleteMsg(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pendingDeleteMsg]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const isNearBottom = distanceFromBottom < 80;
    setAtBottom(isNearBottom);
    onAtBottomChange?.(isNearBottom);
    if (isNearBottom) {
      setUnreadCount(0);
    }
  };

  useEffect(() => {
    const grew = messages.length > prevLenRef.current;
    prevLenRef.current = messages.length;
    if (!grew) return;

    if (atBottom) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    } else {
      setUnreadCount((c) => c + 1);
    }
  }, [messages.length, atBottom]);

  const lastMsgReactionsKey = messages.length
    ? JSON.stringify(messages[messages.length - 1].reactions || {})
    : '';
  const readReceiptsKey = useMemo(
    () => readReceipts.map((r) => `${r.clientId}:${r.lastReadMessageId}`).join('|'),
    [readReceipts]
  );

  useEffect(() => {
    if (atBottom) {
      bottomRef.current?.scrollIntoView({ behavior: 'auto' });
    }
  }, [atBottom, lastMsgReactionsKey, readReceiptsKey]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'auto' });
    onAtBottomChange?.(true);
  }, [onAtBottomChange]);

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    setUnreadCount(0);
    setAtBottom(true);
    onAtBottomChange?.(true);
  };

  const handleCopyText = async (msg: ChatMessage) => {
    if (!msg.text) return;
    try {
      await navigator.clipboard.writeText(msg.text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = msg.text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopiedId(msg.id);
    window.setTimeout(() => setCopiedId((prev) => (prev === msg.id ? null : prev)), 1500);
  };

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3"
          style={{
            backgroundColor: theme.accentSoftBg,
            color: theme.accentText,
          }}
        >
          <MessageSquare className="w-6 h-6" />
        </div>
        <h2
          className="font-display text-base font-semibold mb-1"
          style={{ color: theme.textPrimary }}
        >
          {searchQuery ? t.noSearchMatches : t.emptyChatTitle}
        </h2>
        {!searchQuery && (
          <p className="text-sm max-w-xs" style={{ color: theme.textMuted }}>
            {isDirectRoom ? t.emptyDmSub : t.emptyChatSub}
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="relative flex-1 min-h-0 flex flex-col">
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto chat-scroll px-3 sm:px-6 py-4 space-y-3"
      >
        {hasMoreOlder && (
          <div className="flex justify-center pb-2">
            <button
              type="button"
              disabled={loadingOlder}
              onClick={onLoadOlder}
              className="min-h-[36px] px-4 rounded-xl text-xs font-medium cursor-pointer disabled:opacity-60"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textSecondary,
              }}
            >
              {loadingOlder ? t.loadingOlder : t.loadOlderMessages}
            </button>
          </div>
        )}

        {messages.map((msg, index) => {
          if (msg.type === 'system') {
            return (
              <div
                key={msg.id}
                className="py-1.5 flex items-center justify-center text-center"
              >
                <span
                  className="text-xs px-3 py-1"
                  style={{ color: theme.textMuted }}
                >
                  {msg.text} ·{' '}
                  <span className="font-mono-nums">
                    {formatTime(msg.createdAt)}
                  </span>
                </span>
              </div>
            );
          }

          const isOwn = msg.senderId === currentClientId;
          const prev = index > 0 ? messages[index - 1] : null;
          const isGrouped =
            Boolean(prev) &&
            prev?.type === 'user' &&
            prev?.senderId === msg.senderId &&
            msg.createdAt - (prev?.createdAt || 0) < 120_000;

          const senderProf = profilesById[msg.senderId];
          const senderDisplayName = senderProf?.displayName || msg.senderName;
          const senderAvatarUrl = senderProf?.avatarUrl ?? msg.senderAvatarUrl;
          const canSeeSenderPhoto = senderProf
            ? canViewProfileField(
                senderProf.privacy?.profilePhoto,
                msg.senderId,
                currentClientId,
                false,
                true
              )
            : true;

          const reactionEntries = Object.entries(msg.reactions || {}).filter(
            ([, users]) => users.length > 0
          );
          const isPinned = pinnedMessageId === msg.id;
          const readers = isOwn
            ? getMessageReaders(msg, readReceipts, currentClientId)
            : [];
          const isDelivered =
            isOwn &&
            ((msg.deliveredTo && msg.deliveredTo.some((id) => id !== currentClientId)) ||
              readers.length > 0);
          const latestReadersHere = latestSeenByMessage[msg.id] || [];
          const pickerPlacement =
            index >= messages.length - 2 ? 'top' : 'bottom';

          const resolvedImage = msg.imageUrl || msg.imageDataUrl;
          const resolvedAudio = msg.audioUrl || msg.audioDataUrl;
          const isStickerOnly = Boolean(msg.stickerUrl && !msg.text);

          return (
            <motion.div
              key={msg.id}
              data-testid="chat-message"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className={`group flex gap-2.5 ${
                isOwn ? 'flex-row-reverse' : 'flex-row'
              } ${isGrouped ? 'mt-1' : 'mt-3'}`}
            >
              {/* Avatar column */}
              {!isOwn && (
                <div className="w-8 shrink-0 flex flex-col items-center">
                  {!isGrouped && (
                    <button
                      type="button"
                      onClick={() =>
                        onViewSenderProfile(
                          msg.senderId,
                          senderDisplayName,
                          msg.senderColor
                        )
                      }
                      aria-label={`View profile of ${senderDisplayName}`}
                      className="mt-0.5 cursor-pointer"
                    >
                      <AvatarBadge
                        name={senderDisplayName}
                        avatarColor={senderProf?.avatarColor || msg.senderColor}
                        avatarUrl={senderAvatarUrl}
                        canViewPhoto={canSeeSenderPhoto}
                        size="sm"
                      />
                    </button>
                  )}
                </div>
              )}

              {/* Message content column */}
              <div
                className={`relative max-w-[85%] sm:max-w-[72%] flex flex-col ${
                  isOwn ? 'items-end' : 'items-start'
                }`}
              >
                {!isGrouped && (
                  <div
                    className={`flex items-center gap-1.5 mb-1 px-1 text-xs ${
                      isOwn ? 'flex-row-reverse' : 'flex-row'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() =>
                        !isOwn &&
                        onViewSenderProfile(
                          msg.senderId,
                          senderDisplayName,
                          msg.senderColor
                        )
                      }
                      className={`font-semibold ${!isOwn ? 'cursor-pointer hover:underline' : ''}`}
                      style={{ color: theme.textPrimary }}
                    >
                      {isOwn ? t.you : senderDisplayName}
                    </button>
                    {msg.isAdmin && (
                      <span
                        className="text-[11px] font-semibold"
                        style={{ color: theme.accentText }}
                      >
                        · {t.adminBadge}
                      </span>
                    )}
                    {msg.isGuest && !msg.isAdmin && (
                      <span
                        className="text-[11px]"
                        style={{ color: theme.textMuted }}
                      >
                        · {t.guestBadge}
                      </span>
                    )}
                    <span
                      className="text-[11px] font-mono-nums"
                      style={{ color: theme.textMuted }}
                    >
                      {formatTime(msg.createdAt)}
                    </span>
                  </div>
                )}

                <div
                  className={`relative flex flex-col sm:items-end gap-1 sm:gap-1.5 ${
                    isOwn
                      ? 'items-end sm:flex-row-reverse'
                      : 'items-start sm:flex-row'
                  }`}
                >
                  <div
                    className={`rounded-2xl ${
                      isStickerOnly ? 'p-1.5' : 'px-3.5 py-2.5'
                    } text-sm leading-relaxed break-words`}
                    style={{
                      backgroundColor: isStickerOnly
                        ? 'transparent'
                        : isOwn
                          ? theme.ownBubbleBg
                          : theme.otherBubbleBg,
                      color: isOwn ? theme.ownBubbleText : theme.otherBubbleText,
                      border:
                        isOwn || isStickerOnly
                          ? 'none'
                          : `1px solid ${theme.borderColor}`,
                    }}
                  >
                    {msg.forwardedFrom && (
                      <div className="mb-1.5 flex items-center gap-1 text-[11px] opacity-75 italic">
                        <Forward className="w-3 h-3" />
                        <span>
                          {t.forwardedLabel} · {msg.forwardedFrom.senderName}
                        </span>
                      </div>
                    )}

                    {msg.replyTo && (
                      <div
                        className="mb-2 px-2.5 py-1.5 rounded-xl text-xs"
                        style={{
                          backgroundColor: isOwn
                            ? 'rgba(0, 0, 0, 0.22)'
                            : theme.canvasBg,
                          border: `1px solid ${
                            isOwn ? 'rgba(255,255,255,0.16)' : theme.borderColor
                          }`,
                        }}
                      >
                        <div className="font-semibold opacity-90">
                          {msg.replyTo.senderName}
                        </div>
                        <div className="opacity-75 truncate max-w-[220px] sm:max-w-[300px]">
                          {msg.replyTo.textPreview ||
                            (msg.replyTo.hasPoll ? '📊 Poll' : '') ||
                            (msg.replyTo.hasAudio ? '🎙️ Voice Note' : '') ||
                            (msg.replyTo.hasVideo ? '🎬 Video' : '') ||
                            (msg.replyTo.hasGif ? 'GIF' : '') ||
                            (msg.replyTo.hasSticker ? 'Sticker' : '') ||
                            (msg.replyTo.hasFile ? '📎 Document' : '') ||
                            (msg.replyTo.hasImage ? '📷 Photo' : '')}
                        </div>
                      </div>
                    )}

                    {resolvedImage && (
                      <button
                        type="button"
                        onClick={() =>
                          onOpenImage(resolvedImage, senderDisplayName)
                        }
                        aria-label={`View photo from ${senderDisplayName}`}
                        className="block mb-1.5 last:mb-0 rounded-xl overflow-hidden cursor-pointer focus-visible:outline-2"
                      >
                        <img
                          src={resolvedImage}
                          alt={`Shared by ${senderDisplayName}`}
                          referrerPolicy="no-referrer"
                          className="max-h-72 w-auto max-w-full rounded-xl object-cover"
                        />
                      </button>
                    )}

                    {msg.gifUrl && (
                      <div className="mb-1.5 last:mb-0 rounded-xl overflow-hidden">
                        <img
                          src={msg.gifUrl}
                          alt="GIF"
                          referrerPolicy="no-referrer"
                          className="max-h-60 w-auto max-w-full rounded-xl object-contain"
                        />
                      </div>
                    )}

                    {msg.stickerUrl && (
                      <div className="mb-1 last:mb-0">
                        <img
                          src={msg.stickerUrl}
                          alt="Sticker"
                          referrerPolicy="no-referrer"
                          className="w-32 h-32 object-contain rounded-xl"
                        />
                      </div>
                    )}

                    {msg.videoUrl && (
                      <video
                        src={msg.videoUrl}
                        controls
                        playsInline
                        preload="metadata"
                        className="max-h-72 max-w-full rounded-xl mb-1.5 last:mb-0 bg-black"
                      />
                    )}

                    {resolvedAudio && (
                      <VoiceNotePlayer
                        src={resolvedAudio}
                        durationSec={msg.audioDurationSec}
                        isOwn={isOwn}
                        theme={theme}
                      />
                    )}

                    {msg.fileUrl && (
                      <a
                        href={msg.fileUrl}
                        download={msg.fileName || 'file'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mb-1.5 last:mb-0 flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs"
                        style={{
                          backgroundColor: isOwn
                            ? 'rgba(0,0,0,0.2)'
                            : theme.canvasBg,
                          border: `1px solid ${
                            isOwn ? 'rgba(255,255,255,0.2)' : theme.borderColor
                          }`,
                        }}
                      >
                        <FileText className="w-5 h-5 shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold truncate max-w-[190px]">
                            {msg.fileName || 'Document'}
                          </p>
                          <p className="text-[10px] opacity-75 font-mono-nums">
                            {formatFileSize(msg.fileSize)}
                          </p>
                        </div>
                        <Download className="w-4 h-4 shrink-0" />
                      </a>
                    )}

                    {msg.poll && (
                      <PollCard
                        poll={msg.poll}
                        messageId={msg.id}
                        currentClientId={currentClientId}
                        isOwn={isOwn}
                        theme={theme}
                        votesLabel={t.votesLabel}
                        onVote={onVotePoll}
                      />
                    )}

                    {/* Inline Editing Input OR Message Text */}
                    {editingId === msg.id ? (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (editDraft.trim()) {
                            onEditMessage(msg.id, editDraft.trim());
                          }
                          setEditingId(null);
                        }}
                        className="space-y-2 min-w-[200px]"
                      >
                        <input
                          type="text"
                          autoFocus
                          value={editDraft}
                          onChange={(e) => setEditDraft(e.target.value)}
                          aria-label={t.editMessage}
                          className="w-full h-9 px-2.5 rounded-lg text-xs outline-none bg-black/25 text-white border border-white/25"
                        />
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="px-2 py-1 rounded text-[11px] opacity-80 cursor-pointer"
                          >
                            {t.cancelReply}
                          </button>
                          <button
                            type="submit"
                            className="px-2.5 py-1 rounded bg-white/20 text-[11px] font-semibold cursor-pointer"
                          >
                            {t.saveEdit}
                          </button>
                        </div>
                      </form>
                    ) : (
                      msg.text && (
                        <div>
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                          {msg.editedAt && (
                            <span className="text-[10px] opacity-70 ml-1">
                              ({t.editedLabel})
                            </span>
                          )}
                        </div>
                      )
                    )}

                    {/* Emoji Reactions with Total Count Inside Chat Bubble */}
                    {reactionEntries.length > 0 && (
                      <div
                        data-testid="bubble-reactions"
                        className="mt-2 pt-1.5 flex flex-wrap items-center gap-1.5"
                        style={{
                          borderTop: isOwn
                            ? '1px solid rgba(255, 255, 255, 0.16)'
                            : `1px solid ${theme.borderColor}`,
                        }}
                      >
                        {reactionEntries.map(([emoji, users]) => {
                          const iReacted = users.includes(currentClientId);
                          return (
                            <button
                              key={emoji}
                              type="button"
                              onClick={() => onReact(msg.id, emoji)}
                              aria-label={`Toggle ${emoji} reaction (${users.length})`}
                              title={`${emoji} · ${users.length}`}
                              className="h-6 px-2 rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                              style={
                                isOwn
                                  ? {
                                      backgroundColor: iReacted
                                        ? 'rgba(255, 255, 255, 0.28)'
                                        : 'rgba(0, 0, 0, 0.22)',
                                      border: `1px solid ${
                                        iReacted
                                          ? 'rgba(255, 255, 255, 0.52)'
                                          : 'rgba(255, 255, 255, 0.16)'
                                      }`,
                                      color: '#FFFFFF',
                                    }
                                  : {
                                      backgroundColor: iReacted
                                        ? theme.accentSoftBg
                                        : theme.canvasBg,
                                      border: `1px solid ${
                                        iReacted
                                          ? theme.accentBorder
                                          : theme.borderColor
                                      }`,
                                      color: iReacted
                                        ? theme.accentText
                                        : theme.textSecondary,
                                    }
                              }
                            >
                              <span className="leading-none">{emoji}</span>
                              <span
                                data-testid="reaction-count"
                                className="font-mono-nums font-bold text-[11px] leading-none"
                              >
                                {users.length}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Action Buttons (Hover / Focus) */}
                  <div
                    className={`flex items-center gap-0.5 opacity-80 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-within:opacity-100 transition-opacity shrink-0 ${
                      isOwn ? 'flex-row-reverse' : 'flex-row'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() =>
                        setActiveReactionPickerId((prevId) =>
                          prevId === msg.id ? null : msg.id
                        )
                      }
                      aria-label={`React to message from ${senderDisplayName}`}
                      className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                      style={{ color: theme.textMuted }}
                    >
                      <SmilePlus className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onReply(msg)}
                      aria-label={`${t.reply} to ${senderDisplayName}`}
                      className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                      style={{ color: theme.textMuted }}
                    >
                      <Reply className="w-4 h-4" />
                    </button>

                    {canForwardMessage(msg) && (
                      <button
                        type="button"
                        onClick={() => onForward(msg)}
                        aria-label={`${t.forwardMessage} message from ${senderDisplayName}`}
                        title={t.forwardMessage}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                        style={{ color: theme.textMuted }}
                      >
                        <Forward className="w-4 h-4" />
                      </button>
                    )}

                    {msg.text && (
                      <button
                        type="button"
                        onClick={() => void handleCopyText(msg)}
                        aria-label={`${t.copyText} message from ${senderDisplayName}`}
                        title={copiedId === msg.id ? t.copiedText : t.copyText}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                        style={{
                          color: copiedId === msg.id ? '#34D399' : theme.textMuted,
                        }}
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                    )}

                    {canEditMessage(msg, currentClientId) && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(msg.id);
                          setEditDraft(msg.text);
                        }}
                        aria-label={`${t.editMessage} message`}
                        title={t.editMessage}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                        style={{ color: theme.textMuted }}
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => onPinMessage(isPinned ? null : msg.id)}
                        aria-label={`${isPinned ? t.unpinMessage : t.pinMessage} message from ${senderDisplayName}`}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                        style={{
                          color: isPinned ? theme.accentText : theme.textMuted,
                        }}
                      >
                        <Pin className="w-4 h-4" />
                      </button>
                    )}

                    {!isOwn && (
                      <button
                        type="button"
                        onClick={() => onReportMessage(msg)}
                        aria-label={`${t.reportAction} message from ${senderDisplayName}`}
                        title={t.reportAction}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-amber-400 hover:bg-amber-500/15 transition-colors cursor-pointer"
                      >
                        <Flag className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setPendingDeleteMsg(msg)}
                      aria-label={`${t.deleteMessage} message from ${senderDisplayName}`}
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-500/15 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Robust Emoji Reaction Picker */}
                <EmojiPickerPopover
                  open={activeReactionPickerId === msg.id}
                  theme={theme}
                  lang={lang}
                  reactionsMode={true}
                  align={isOwn ? 'right' : 'left'}
                  placement={pickerPlacement}
                  ariaLabel={`Emoji reactions for ${senderDisplayName}`}
                  onSelectEmoji={(emoji) => {
                    onReact(msg.id, emoji);
                    setActiveReactionPickerId(null);
                  }}
                  onClose={() => setActiveReactionPickerId(null)}
                />

                {/* Delivery / Read Receipts */}
                {(isOwn || latestReadersHere.length > 0) && (
                  <div
                    className={`mt-1 px-1 flex items-center gap-1.5 text-[11px] ${
                      isOwn ? 'justify-end' : 'justify-start'
                    }`}
                    style={{ color: theme.textMuted }}
                  >
                    {isOwn && (
                      readers.length > 0 ? (
                        <span
                          data-testid="read-receipt-seen"
                          title={`${t.seenByLabel} ${readers.map((r) => r.nickname).join(', ')}`}
                          aria-label={`${t.seenByLabel} ${readers.map((r) => r.nickname).join(', ')}`}
                          className="inline-flex items-center gap-1"
                          style={{ color: theme.accentText }}
                        >
                          <CheckCheck className="w-3.5 h-3.5" />
                        </span>
                      ) : isDelivered ? (
                        <span
                          data-testid="read-receipt-delivered"
                          title={t.deliveredLabel}
                          aria-label={t.deliveredLabel}
                          className="inline-flex items-center gap-1 opacity-75"
                        >
                          <CheckCheck className="w-3.5 h-3.5" />
                        </span>
                      ) : (
                        <span
                          data-testid="read-receipt-sent"
                          title={t.sentLabel}
                          aria-label={t.sentLabel}
                          className="inline-flex items-center gap-1 opacity-75"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </span>
                      )
                    )}

                    {latestReadersHere.length > 0 && (
                      <span
                        data-testid="read-receipt-names"
                        className="inline-flex items-center gap-1 truncate max-w-[240px]"
                      >
                        <span className="inline-flex items-center -space-x-1 shrink-0">
                          {latestReadersHere.slice(0, 3).map((r) => (
                            <span
                              key={r.clientId}
                              title={r.nickname}
                              className="w-4 h-4 rounded-full text-[8px] font-bold text-white flex items-center justify-center ring-1"
                              style={{
                                backgroundColor: r.avatarColor,
                                borderColor: theme.canvasBg,
                              }}
                            >
                              {getInitials(r.nickname)}
                            </span>
                          ))}
                        </span>
                        <span className="truncate">
                          {isDirectRoom
                            ? t.seenLabel
                            : latestReadersHere.length <= 2
                              ? `${t.seenByLabel} ${latestReadersHere.map((r) => r.nickname).join(', ')}`
                              : `${t.seenByLabel} ${latestReadersHere
                                  .slice(0, 2)
                                  .map((r) => r.nickname)
                                  .join(', ')} +${latestReadersHere.length - 2} ${t.othersLabel}`}
                        </span>
                      </span>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}

        {/* Typing indicator */}
        {typingUsers.length > 0 && (
          <div className="px-2 py-1 text-xs" style={{ color: theme.textMuted }}>
            {typingUsers.map((u) => u.nickname).join(', ')}{' '}
            {typingUsers.length === 1 ? t.typingOne : t.typingMany}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Scroll to bottom button */}
      {!atBottom && (
        <button
          type="button"
          onClick={scrollToBottom}
          className="absolute bottom-4 right-4 h-10 px-3.5 rounded-xl text-xs font-medium text-white shadow-lg flex items-center gap-1.5 cursor-pointer"
          style={{ backgroundColor: theme.accentBg }}
        >
          <ArrowDown className="w-3.5 h-3.5" />
          <span>
            {unreadCount > 0
              ? `${unreadCount} ${t.newMessages}`
              : t.newMessages}
          </span>
        </button>
      )}

      {/* Delete Options Modal */}
      {pendingDeleteMsg && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
          aria-label={t.deleteTitle}
          onClick={() => setPendingDeleteMsg(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-display text-base font-bold">
                  {t.deleteTitle}
                </h3>
                <p
                  className="text-xs mt-1"
                  style={{ color: theme.textMuted }}
                >
                  {t.deleteForMeHint}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPendingDeleteMsg(null)}
                aria-label={t.close}
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 cursor-pointer"
                style={{ color: theme.textMuted }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div
              className="rounded-xl px-3 py-2 text-xs truncate"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textSecondary,
              }}
            >
              <span className="font-semibold" style={{ color: theme.textPrimary }}>
                {pendingDeleteMsg.senderId === currentClientId
                  ? t.you
                  : pendingDeleteMsg.senderName}
                :{' '}
              </span>
              {pendingDeleteMsg.text ||
                (pendingDeleteMsg.poll
                  ? `Poll: ${pendingDeleteMsg.poll.question}`
                  : '') ||
                (pendingDeleteMsg.audioUrl || pendingDeleteMsg.audioDataUrl
                  ? 'Voice Note'
                  : '') ||
                (pendingDeleteMsg.videoUrl ? 'Video' : '') ||
                (pendingDeleteMsg.fileName ? pendingDeleteMsg.fileName : '') ||
                (pendingDeleteMsg.imageUrl || pendingDeleteMsg.imageDataUrl
                  ? 'Photo'
                  : '')}
            </div>

            <div className="flex flex-col gap-2">
              {canDeleteForEveryone(
                pendingDeleteMsg,
                currentClientId,
                isAdmin
              ) && (
                <button
                  type="button"
                  onClick={() => {
                    onDeleteForEveryone(pendingDeleteMsg.id);
                    setPendingDeleteMsg(null);
                  }}
                  className="w-full min-h-[44px] px-4 rounded-xl text-sm font-semibold bg-red-600 hover:bg-red-500 text-white transition-colors cursor-pointer"
                >
                  {t.deleteForEveryone}
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  onDeleteForMe(pendingDeleteMsg.id);
                  setPendingDeleteMsg(null);
                }}
                className="w-full min-h-[44px] px-4 rounded-xl text-sm font-semibold transition-colors cursor-pointer"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textPrimary,
                }}
              >
                {t.deleteForMe}
              </button>

              <button
                type="button"
                onClick={() => setPendingDeleteMsg(null)}
                className="w-full min-h-[40px] px-4 rounded-xl text-sm font-medium transition-colors cursor-pointer"
                style={{ color: theme.textMuted }}
              >
                {t.cancelReply}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
