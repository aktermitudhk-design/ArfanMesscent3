import React, { useEffect, useRef, useState } from 'react';
import {
  Ban,
  Camera,
  Flag,
  MessageCircle,
  Phone,
  Trash2,
  UserCheck,
  Video,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  AVATAR_COLORS,
  canViewProfileField,
  formatLastSeen,
} from '../shared/chatRules';
import type { ThemeSpec, UserProfile } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface ProfileModalProps {
  open: boolean;
  mode: 'self' | 'peer';
  currentClientId: string;
  ownProfile: UserProfile | null;
  targetProfile: UserProfile | null;
  targetFallbackName?: string;
  targetFallbackColor?: string;
  blockedPeerIds: string[];
  mutedRoomIds: string[];
  dmRoomId?: string | null;
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onSaveOwnProfile: (patch: {
    displayName: string;
    username: string;
    bio: string;
    avatarColor: string;
    avatarFile?: File | null;
    removeAvatar?: boolean;
  }) => Promise<{ error?: string; nextDisplayName?: string; nextColor?: string }>;
  onStartDm?: (profile: UserProfile) => void;
  onStartAudioCall?: (profile: UserProfile) => void;
  onStartVideoCall?: (profile: UserProfile) => void;
  onToggleBlockPeer?: (peerId: string) => void;
  onToggleMuteRoom?: (roomId: string) => void;
  onReportPeer?: (profile: UserProfile) => void;
}

export function ProfileModal({
  open,
  mode,
  currentClientId,
  ownProfile,
  targetProfile,
  targetFallbackName,
  targetFallbackColor,
  blockedPeerIds,
  mutedRoomIds,
  dmRoomId,
  theme,
  lang,
  onClose,
  onSaveOwnProfile,
  onStartDm,
  onStartAudioCall,
  onStartVideoCall,
  onToggleBlockPeer,
  onToggleMuteRoom,
  onReportPeer,
}: ProfileModalProps) {
  const t = COPY[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState(ownProfile?.displayName || '');
  const [username, setUsername] = useState(ownProfile?.username || '');
  const [bio, setBio] = useState(ownProfile?.bio || '');
  const [avatarColor, setAvatarColor] = useState(
    ownProfile?.avatarColor || AVATAR_COLORS[0]
  );
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState<string | null>(
    ownProfile?.avatarUrl || null
  );
  const [removeAvatar, setRemoveAvatar] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || mode !== 'self') return;
    setDisplayName(ownProfile?.displayName || '');
    setUsername(ownProfile?.username || '');
    setBio(ownProfile?.bio || '');
    setAvatarColor(ownProfile?.avatarColor || AVATAR_COLORS[0]);
    setAvatarFile(null);
    setAvatarPreviewUrl(ownProfile?.avatarUrl || null);
    setRemoveAvatar(false);
    setError(null);
  }, [mode, open, ownProfile]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, open]);

  if (!open) return null;

  const handleAvatarFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please pick a valid image file.');
      return;
    }
    setError(null);
    setAvatarFile(file);
    setRemoveAvatar(false);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatarPreviewUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitSelf = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const res = await onSaveOwnProfile({
        displayName,
        username,
        bio,
        avatarColor,
        avatarFile,
        removeAvatar,
      });
      if (res.error) {
        setError(res.error);
      } else {
        onClose();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  // Peer View
  if (mode === 'peer') {
    const peer: UserProfile = targetProfile || {
      uid: '',
      clientId: '',
      displayName: targetFallbackName || 'Member',
      username: '',
      bio: '',
      avatarUrl: null,
      avatarColor: targetFallbackColor || AVATAR_COLORS[0],
      isGuest: false,
      online: false,
      lastSeenAt: 0,
      privacy: { lastSeen: 'everyone', profilePhoto: 'everyone', status: 'everyone' },
      updatedAt: 0,
    };
    const peerBlocked = Boolean(peer.clientId && blockedPeerIds.includes(peer.clientId));
    const canSeePhoto = canViewProfileField(
      peer.privacy?.profilePhoto,
      peer.clientId,
      currentClientId,
      peerBlocked,
      true
    );
    const canSeeLastSeen = canViewProfileField(
      peer.privacy?.lastSeen,
      peer.clientId,
      currentClientId,
      peerBlocked,
      true
    );
    const isMuted = Boolean(dmRoomId && mutedRoomIds.includes(dmRoomId));

    return (
      <div
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        role="dialog"
        aria-modal="true"
        aria-label={t.viewProfile}
      >
        <div
          className="fixed inset-0 bg-black/65 backdrop-blur-xs"
          onClick={onClose}
          aria-hidden="true"
        />
        <div
          className="relative z-10 w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-5"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold">{t.viewProfile}</h2>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.close}
              className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col items-center text-center gap-2.5">
            <AvatarBadge
              name={peer.displayName}
              avatarColor={peer.avatarColor}
              avatarUrl={peer.avatarUrl}
              canViewPhoto={canSeePhoto}
              online={peer.online && canSeeLastSeen}
              size="xl"
              dotBorderColor={theme.surfaceBg}
            />
            <div>
              <h3 className="font-display text-lg font-bold">{peer.displayName}</h3>
              <div
                className="text-xs mt-0.5 flex items-center justify-center gap-1.5"
                style={{ color: theme.textMuted }}
              >
                {peer.username && <span>@{peer.username}</span>}
                {peer.username && <span aria-hidden="true">·</span>}
                <span>
                  {formatLastSeen(
                    peer.lastSeenAt,
                    peer.online,
                    canSeeLastSeen,
                    Date.now(),
                    lang
                  )}
                </span>
              </div>
            </div>
            {peer.bio && (
              <p
                className="text-sm leading-relaxed max-w-sm mt-1"
                style={{ color: theme.textSecondary }}
              >
                {peer.bio}
              </p>
            )}
          </div>

          {peer.clientId && peer.clientId !== currentClientId && (
            <div className="space-y-2.5 pt-2">
              <div className="grid grid-cols-3 gap-2">
                {onStartDm && (
                  <button
                    type="button"
                    onClick={() => {
                      onStartDm(peer);
                      onClose();
                    }}
                    className="min-h-[44px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer"
                    style={{ backgroundColor: theme.accentBg }}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{t.messageFriend}</span>
                  </button>
                )}
                {onStartAudioCall && (
                  <button
                    type="button"
                    onClick={() => {
                      onStartAudioCall(peer);
                      onClose();
                    }}
                    className="min-h-[44px] px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                      color: theme.textPrimary,
                    }}
                  >
                    <Phone className="w-4 h-4" />
                    <span>{t.audioCallFriend}</span>
                  </button>
                )}
                {onStartVideoCall && (
                  <button
                    type="button"
                    onClick={() => {
                      onStartVideoCall(peer);
                      onClose();
                    }}
                    className="min-h-[44px] px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: 'rgba(16, 185, 129, 0.16)',
                      border: '1px solid rgba(52, 211, 153, 0.35)',
                      color: '#34D399',
                    }}
                  >
                    <Video className="w-4 h-4" />
                    <span>{t.callFriend}</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                {dmRoomId && onToggleMuteRoom && (
                  <button
                    type="button"
                    onClick={() => onToggleMuteRoom(dmRoomId)}
                    className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                      color: theme.textSecondary,
                    }}
                  >
                    {isMuted ? (
                      <Volume2 className="w-4 h-4" />
                    ) : (
                      <VolumeX className="w-4 h-4" />
                    )}
                    <span>{isMuted ? t.unmuteRoom : t.muteRoom}</span>
                  </button>
                )}

                {onToggleBlockPeer && (
                  <button
                    type="button"
                    onClick={() => onToggleBlockPeer(peer.clientId)}
                    className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: peerBlocked
                        ? 'rgba(16, 185, 129, 0.14)'
                        : 'rgba(239, 68, 68, 0.14)',
                      color: peerBlocked ? '#34D399' : '#F87171',
                    }}
                  >
                    {peerBlocked ? (
                      <UserCheck className="w-4 h-4" />
                    ) : (
                      <Ban className="w-4 h-4" />
                    )}
                    <span>{peerBlocked ? t.unblockUser : t.blockUser}</span>
                  </button>
                )}
              </div>

              {onReportPeer && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onReportPeer(peer);
                  }}
                  className="w-full min-h-[40px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 text-amber-400 hover:bg-amber-500/10 cursor-pointer"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>{t.reportAction}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Edit Own Profile Mode
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.editProfile}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <form
        onSubmit={handleSubmitSelf}
        className="relative z-10 w-full sm:max-w-md max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold">{t.editProfile}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Avatar preview + picker */}
        <div className="flex items-center gap-4">
          <AvatarBadge
            name={displayName || ownProfile?.displayName || 'U'}
            avatarColor={avatarColor}
            avatarUrl={removeAvatar ? null : avatarPreviewUrl}
            canViewPhoto={true}
            size="lg"
            dotBorderColor={theme.surfaceBg}
          />
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleAvatarFilePick}
            className="hidden"
            aria-label={t.uploadAvatar}
            data-testid="avatar-upload-input"
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[40px] px-3.5 rounded-xl text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            >
              <Camera className="w-4 h-4" />
              <span>{t.uploadAvatar}</span>
            </button>

            {(avatarPreviewUrl || ownProfile?.avatarUrl) && !removeAvatar && (
              <button
                type="button"
                onClick={() => {
                  setAvatarFile(null);
                  setAvatarPreviewUrl(null);
                  setRemoveAvatar(true);
                }}
                aria-label={t.removeBackground}
                className="min-h-[40px] px-3 rounded-xl text-xs font-medium text-red-400 bg-red-500/10 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.removeBackground}</span>
              </button>
            )}
          </div>
        </div>

        <div>
          <label
            htmlFor="profile-display-name"
            className="block text-xs font-semibold mb-1.5"
            style={{ color: theme.textSecondary }}
          >
            {t.displayNameLabel}
          </label>
          <input
            id="profile-display-name"
            type="text"
            required
            maxLength={24}
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="w-full h-11 px-3.5 rounded-xl text-sm outline-none"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />
        </div>

        <div>
          <label
            htmlFor="profile-username"
            className="block text-xs font-semibold mb-1.5"
            style={{ color: theme.textSecondary }}
          >
            {t.usernameLabel}
          </label>
          <input
            id="profile-username"
            type="text"
            maxLength={21}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="e.g. arfan_bd"
            className="w-full h-11 px-3.5 rounded-xl text-sm outline-none"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />
        </div>

        <div>
          <label
            htmlFor="profile-bio"
            className="block text-xs font-semibold mb-1.5"
            style={{ color: theme.textSecondary }}
          >
            {t.bioLabel}
          </label>
          <textarea
            id="profile-bio"
            rows={2}
            maxLength={180}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder={t.bioPlaceholder}
            className="w-full p-3 rounded-xl text-sm outline-none resize-none"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />
        </div>

        <div>
          <span
            className="block text-xs font-semibold mb-2"
            style={{ color: theme.textSecondary }}
          >
            {t.avatarColorLabel}
          </span>
          <div className="flex flex-wrap gap-2">
            {AVATAR_COLORS.map((c) => {
              const selected = c === avatarColor;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setAvatarColor(c)}
                  aria-label={`Badge color ${c}`}
                  className="w-8 h-8 rounded-full transition-transform cursor-pointer"
                  style={{
                    backgroundColor: c,
                    transform: selected ? 'scale(1.12)' : 'scale(1)',
                    boxShadow: selected
                      ? `0 0 0 2px ${theme.surfaceBg}, 0 0 0 4px ${c}`
                      : 'none',
                  }}
                />
              );
            })}
          </div>
        </div>

        {error && (
          <p className="text-xs text-red-400" role="alert">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-4 rounded-xl text-sm font-medium cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            {t.cancelReply}
          </button>
          <button
            type="submit"
            disabled={saving}
            data-testid="save-profile-btn"
            className="min-h-[44px] px-5 rounded-xl text-sm font-semibold text-white cursor-pointer disabled:opacity-60"
            style={{ backgroundColor: theme.accentBg }}
          >
            {saving ? t.loadingOlder : t.saveProfile}
          </button>
        </div>
      </form>
    </div>
  );
}
