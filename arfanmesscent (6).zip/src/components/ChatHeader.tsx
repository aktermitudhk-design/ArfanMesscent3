import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Clock,
  Eye,
  Globe,
  Info,
  Link2,
  Lock,
  Megaphone,
  Phone,
  Pin,
  Search,
  Settings,
  Shield,
  ShieldCheck,
  Users,
  Video,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { canViewProfileField, formatLastSeen } from '../shared/chatRules';
import type { HostInspectTarget } from './AdminPanelModal';
import type {
  ChatGroup,
  DirectPeer,
  PinnedMessageSummary,
  ThemeSpec,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface ChatHeaderProps {
  roomTitle: string;
  activeRoomId: string;
  onlineCount: number;
  roomLocked: boolean;
  isAdmin: boolean;
  connected: boolean;
  copied: boolean;
  soundEnabled: boolean;
  isRoomMuted: boolean;
  searchOpen: boolean;
  searchQuery: string;
  announcement?: string;
  disappearingHours?: 0 | 24 | 168;
  pinnedMessage: PinnedMessageSummary | null;
  activeCallCount: number;
  inCall: boolean;
  activeDirectPeer: DirectPeer | null;
  activeDirectPeerProfile: UserProfile | null;
  activeCustomGroup: ChatGroup | null;
  activeHostInspectRoom?: HostInspectTarget | null;
  currentClientId: string;
  totalUnreadDms: number;
  theme: ThemeSpec;
  lang: Lang;
  onCopyInvite: () => void;
  onOpenMembers: () => void;
  onOpenAdmin: () => void;
  onOpenSettings: () => void;
  onOpenGroupInfo: () => void;
  onViewPeerProfile: () => void;
  onToggleAudioCall: () => void;
  onToggleCall: () => void;
  onToggleRoomMute: () => void;
  onBackToGroup: () => void;
  onToggleLang: () => void;
  onToggleSound: () => void;
  onToggleSearch: () => void;
  onSearchChange: (value: string) => void;
  onUnpin: () => void;
}

export function ChatHeader({
  roomTitle,
  onlineCount,
  roomLocked,
  isAdmin,
  connected,
  copied,
  soundEnabled,
  isRoomMuted,
  searchOpen,
  searchQuery,
  announcement = '',
  disappearingHours = 0,
  pinnedMessage,
  activeCallCount,
  inCall,
  activeDirectPeer,
  activeDirectPeerProfile,
  activeCustomGroup,
  activeHostInspectRoom,
  currentClientId,
  totalUnreadDms,
  theme,
  lang,
  onCopyInvite,
  onOpenMembers,
  onOpenAdmin,
  onOpenSettings,
  onOpenGroupInfo,
  onViewPeerProfile,
  onToggleAudioCall,
  onToggleCall,
  onToggleRoomMute,
  onBackToGroup,
  onToggleLang,
  onToggleSound,
  onToggleSearch,
  onSearchChange,
  onUnpin,
}: ChatHeaderProps) {
  const t = COPY[lang];
  const [dismissedAnnouncement, setDismissedAnnouncement] = useState('');

  useEffect(() => {
    setDismissedAnnouncement('');
  }, [announcement]);

  const callLabel = inCall
    ? t.inCallLabel
    : activeDirectPeer
      ? t.personalCallLabel
      : activeCallCount > 0
        ? `${t.joinVideoCall} (${activeCallCount})`
        : t.startVideoCall;

  const peerCanSeePhoto = activeDirectPeerProfile
    ? canViewProfileField(
        activeDirectPeerProfile.privacy?.profilePhoto,
        activeDirectPeerProfile.clientId,
        currentClientId,
        false,
        true
      )
    : true;
  const peerCanSeeLastSeen = activeDirectPeerProfile
    ? canViewProfileField(
        activeDirectPeerProfile.privacy?.lastSeen,
        activeDirectPeerProfile.clientId,
        currentClientId,
        false,
        true
      )
    : true;

  return (
    <div className="shrink-0">
      <header
        className="h-14 px-3 sm:px-5 flex items-center justify-between gap-2 sm:gap-3"
        style={{
          backgroundColor: theme.sidebarBg,
          borderBottom: `1px solid ${theme.borderColor}`,
        }}
      >
        {/* Left: Back / Mobile Menu + Room or Peer Identity */}
        <div className="flex items-center gap-2 min-w-0">
          {activeDirectPeer || activeCustomGroup || activeHostInspectRoom ? (
            <button
              type="button"
              onClick={onBackToGroup}
              aria-label={t.backToGroup}
              className="min-h-[40px] px-2.5 rounded-xl flex items-center gap-1.5 text-xs font-medium cursor-pointer shrink-0"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">{t.backToGroup}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onOpenMembers}
              aria-label={t.membersButton}
              className="relative lg:hidden min-h-[40px] min-w-[40px] px-2.5 rounded-xl flex items-center gap-1.5 text-xs font-medium cursor-pointer shrink-0"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            >
              <Users className="w-4 h-4" />
              <span className="font-mono-nums">{onlineCount}</span>
              {totalUnreadDms > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-emerald-500 text-[10px] font-bold text-white flex items-center justify-center">
                  {totalUnreadDms}
                </span>
              )}
            </button>
          )}

          {activeHostInspectRoom ? (
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                style={{
                  backgroundColor: theme.accentSoftBg,
                  color: theme.accentText,
                }}
              >
                <Eye className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h1
                  className="font-display text-sm sm:text-base font-bold truncate"
                  style={{ color: theme.textPrimary }}
                >
                  {activeHostInspectRoom.title}
                </h1>
                <div
                  className="text-[11px] font-semibold truncate"
                  style={{ color: theme.accentText }}
                >
                  {t.hostOversightBadge}
                </div>
              </div>
            </div>
          ) : activeDirectPeer ? (
            <button
              type="button"
              onClick={onViewPeerProfile}
              className="flex items-center gap-2.5 min-w-0 text-left cursor-pointer"
            >
              <AvatarBadge
                name={activeDirectPeer.nickname}
                avatarColor={activeDirectPeer.avatarColor}
                avatarUrl={activeDirectPeerProfile?.avatarUrl ?? activeDirectPeer.avatarUrl}
                canViewPhoto={peerCanSeePhoto}
                online={Boolean(activeDirectPeerProfile?.online) && peerCanSeeLastSeen}
                size="sm"
                dotBorderColor={theme.sidebarBg}
              />
              <div className="min-w-0">
                <h1
                  className="font-display text-sm sm:text-base font-bold truncate"
                  style={{ color: theme.textPrimary }}
                >
                  {activeDirectPeerProfile?.displayName || activeDirectPeer.nickname}
                </h1>
                <div
                  className="text-[11px] truncate"
                  style={{ color: theme.accentText }}
                >
                  {activeDirectPeerProfile
                    ? formatLastSeen(
                        activeDirectPeerProfile.lastSeenAt,
                        activeDirectPeerProfile.online,
                        peerCanSeeLastSeen,
                        Date.now(),
                        lang
                      )
                    : t.personalChatLabel}
                </div>
              </div>
            </button>
          ) : activeCustomGroup ? (
            <button
              type="button"
              onClick={onOpenGroupInfo}
              className="flex items-center gap-2.5 min-w-0 text-left cursor-pointer"
            >
              <AvatarBadge
                name={activeCustomGroup.name}
                avatarColor={activeCustomGroup.avatarColor}
                avatarUrl={activeCustomGroup.avatarUrl}
                size="sm"
              />
              <div className="min-w-0">
                <h1
                  className="font-display text-sm sm:text-base font-bold truncate"
                  style={{ color: theme.textPrimary }}
                >
                  {activeCustomGroup.name}
                </h1>
                <div
                  className="text-[11px] truncate"
                  style={{ color: theme.textMuted }}
                >
                  {activeCustomGroup.memberIds.length} {t.groupMembersLabel} · {t.groupInfo}
                </div>
              </div>
            </button>
          ) : (
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1
                  className="font-display text-sm sm:text-base font-bold truncate"
                  style={{ color: theme.textPrimary }}
                >
                  {roomTitle}
                </h1>
                {roomLocked && (
                  <Lock
                    className="w-3.5 h-3.5 shrink-0 text-amber-400"
                    aria-label="Room paused"
                  />
                )}
              </div>
              <div
                className="flex items-center gap-1.5 text-[11px] sm:text-xs"
                style={{ color: theme.textMuted }}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                    connected ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                  aria-hidden="true"
                />
                <span className="font-mono-nums">
                  {connected ? `${onlineCount} ${t.onlineNow}` : t.reconnecting}
                </span>
                {disappearingHours > 0 && (
                  <span
                    className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold"
                    style={{
                      backgroundColor: theme.accentSoftBg,
                      color: theme.accentText,
                    }}
                    title={t.disappearingLabel}
                  >
                    <Clock className="w-2.5 h-2.5" />
                    <span>{disappearingHours === 168 ? '7d' : '24h'}</span>
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right: Audio Call + Video Call + Search + Mute + Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {!activeHostInspectRoom && (
            <>
              <button
                type="button"
                onClick={onToggleAudioCall}
                aria-label={t.startAudioCall}
                title={t.startAudioCall}
                className="min-h-[38px] min-w-[38px] sm:min-h-[40px] sm:min-w-[40px] rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                style={{
                  backgroundColor: theme.surfaceBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textSecondary,
                }}
              >
                <Phone className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onToggleCall}
                aria-label={callLabel}
                title={callLabel}
                className="min-h-[38px] min-w-[38px] sm:min-h-[40px] sm:min-w-[40px] px-2 sm:px-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                style={{
                  backgroundColor:
                    inCall || (!activeDirectPeer && !activeCustomGroup && activeCallCount > 0)
                      ? 'rgba(16, 185, 129, 0.16)'
                      : theme.surfaceBg,
                  border: `1px solid ${
                    inCall || (!activeDirectPeer && !activeCustomGroup && activeCallCount > 0)
                      ? 'rgba(52, 211, 153, 0.4)'
                      : theme.borderColor
                  }`,
                  color:
                    inCall || (!activeDirectPeer && !activeCustomGroup && activeCallCount > 0)
                      ? '#34D399'
                      : theme.textSecondary,
                }}
              >
                <Video className="w-4 h-4 shrink-0" />
                <span className="hidden md:inline">{callLabel}</span>
              </button>
            </>
          )}

          {activeCustomGroup && (
            <button
              type="button"
              onClick={onOpenGroupInfo}
              aria-label={t.groupInfo}
              title={t.groupInfo}
              className="hidden sm:flex min-h-[40px] min-w-[40px] rounded-xl items-center justify-center shrink-0 cursor-pointer"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textSecondary,
              }}
            >
              <Info className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={onToggleSearch}
            aria-label={t.searchToggle}
            aria-expanded={searchOpen}
            title={t.searchToggle}
            className="min-h-[38px] min-w-[38px] sm:min-h-[40px] sm:min-w-[40px] rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer"
            style={{
              backgroundColor: searchOpen ? theme.accentSoftBg : theme.surfaceBg,
              border: `1px solid ${
                searchOpen ? theme.accentBorder : theme.borderColor
              }`,
              color: searchOpen ? theme.accentText : theme.textSecondary,
            }}
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onToggleRoomMute}
            aria-label={isRoomMuted ? t.unmuteRoom : t.muteRoom}
            title={isRoomMuted ? t.unmuteRoom : t.muteRoom}
            className="hidden md:flex min-h-[40px] min-w-[40px] rounded-xl items-center justify-center shrink-0 cursor-pointer"
            style={{
              backgroundColor: isRoomMuted ? 'rgba(245, 158, 11, 0.14)' : theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: isRoomMuted ? '#FBBF24' : theme.textSecondary,
            }}
          >
            {isRoomMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onCopyInvite}
            aria-label={copied ? t.copied : t.copyLink}
            title={copied ? t.copied : t.copyLink}
            className="hidden sm:flex min-h-[40px] px-2.5 py-1.5 rounded-xl text-xs font-medium items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: copied
                ? 'rgba(16, 185, 129, 0.16)'
                : theme.accentSoftBg,
              color: copied ? '#34D399' : theme.accentText,
              border: `1px solid ${
                copied ? 'rgba(52, 211, 153, 0.35)' : theme.accentBorder
              }`,
            }}
          >
            {copied ? <Check className="w-4 h-4" /> : <Link2 className="w-4 h-4" />}
            <span className="hidden xl:inline">{copied ? t.copied : t.copyLink}</span>
          </button>

          <button
            type="button"
            onClick={onToggleLang}
            aria-label="Switch language"
            className="hidden sm:flex min-h-[40px] min-w-[40px] px-2 rounded-xl text-xs font-medium items-center justify-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'BN' : 'EN'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label={t.settingsTitle}
            title={t.settingsTitle}
            className="hidden sm:flex min-h-[40px] min-w-[40px] rounded-xl items-center justify-center shrink-0 cursor-pointer"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenAdmin}
            aria-label={t.adminControls}
            className="min-h-[38px] min-w-[38px] sm:min-h-[40px] px-2 sm:px-3 py-1.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: isAdmin ? theme.accentBg : theme.surfaceBg,
              border: `1px solid ${isAdmin ? theme.accentBg : theme.borderColor}`,
              color: isAdmin ? '#FFFFFF' : theme.textPrimary,
            }}
          >
            {isAdmin ? (
              <ShieldCheck className="w-3.5 h-3.5" />
            ) : (
              <Shield className="w-3.5 h-3.5" />
            )}
            <span className="hidden sm:inline">
              {isAdmin ? t.adminActive : 'Host'}
            </span>
          </button>
        </div>
      </header>

      {/* Expandable Live Search Bar */}
      {searchOpen && (
        <div
          className="px-3 sm:px-5 py-2 flex items-center gap-2"
          style={{
            backgroundColor: theme.surfaceBg,
            borderBottom: `1px solid ${theme.borderColor}`,
          }}
        >
          <Search
            className="w-4 h-4 shrink-0"
            style={{ color: theme.textMuted }}
          />
          <input
            type="text"
            autoFocus
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.searchPlaceholder}
            aria-label={t.searchPlaceholder}
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: theme.textPrimary }}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              aria-label="Clear search"
              className="p-1.5 rounded-lg cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* Host Live Broadcast Announcement Banner */}
      {announcement && dismissedAnnouncement !== announcement && (
        <div
          data-testid="host-broadcast-banner"
          className="px-3 sm:px-5 py-2 flex items-center justify-between gap-3 text-xs"
          style={{
            backgroundColor: 'rgba(245, 158, 11, 0.14)',
            borderBottom: '1px solid rgba(251, 191, 36, 0.3)',
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Megaphone className="w-3.5 h-3.5 shrink-0 text-amber-400" />
            <span className="truncate font-medium">{announcement}</span>
          </div>
          <button
            type="button"
            onClick={() => setDismissedAnnouncement(announcement)}
            aria-label={t.close}
            className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0 cursor-pointer hover:bg-white/10"
            style={{ color: theme.textMuted }}
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Pinned Announcement Strip (Group Room only) */}
      {!activeDirectPeer && !activeCustomGroup && pinnedMessage && (
        <div
          className="px-3 sm:px-5 py-2 flex items-center justify-between gap-3 text-xs"
          style={{
            backgroundColor: theme.accentSoftBg,
            borderBottom: `1px solid ${theme.accentBorder}`,
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Pin
              className="w-3.5 h-3.5 shrink-0"
              style={{ color: theme.accentText }}
            />
            <span
              className="font-semibold shrink-0"
              style={{ color: theme.accentText }}
            >
              {pinnedMessage.senderName}:
            </span>
            <span className="truncate opacity-90">
              {pinnedMessage.previewText}
            </span>
          </div>

          {isAdmin && (
            <button
              type="button"
              onClick={onUnpin}
              aria-label={t.unpinMessage}
              className="px-2 py-1 rounded-lg text-[11px] font-medium shrink-0 cursor-pointer hover:bg-white/10"
              style={{ color: theme.accentText }}
            >
              {t.unpinMessage}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
