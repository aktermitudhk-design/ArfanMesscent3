import React, { useEffect, useRef, useState } from 'react';
import { ImagePlus, Type, Video, X } from 'lucide-react';
import { STORY_BG_COLORS } from '../shared/chatRules';
import type {
  StoryPrivacy,
  StoryType,
  ThemeSpec,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

interface CreateStoryModalProps {
  open: boolean;
  currentClientId: string;
  contacts: UserProfile[];
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onCreateStory: (input: {
    type: StoryType;
    text?: string;
    bgColor?: string;
    file?: File | null;
    privacy: StoryPrivacy;
    allowedViewerIds?: string[];
  }) => Promise<void>;
}

export function CreateStoryModal({
  open,
  currentClientId,
  contacts,
  theme,
  lang,
  onClose,
  onCreateStory,
}: CreateStoryModalProps) {
  const t = COPY[lang];
  const [storyType, setStoryType] = useState<StoryType>('text');
  const [text, setText] = useState('');
  const [bgColor, setBgColor] = useState<string>(STORY_BG_COLORS[0]);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [privacy, setPrivacy] = useState<StoryPrivacy>('everyone');
  const [allowedIds, setAllowedIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setStoryType('text');
    setText('');
    setBgColor(STORY_BG_COLORS[0]);
    setFile(null);
    setPreviewUrl(null);
    setPrivacy('everyone');
    setAllowedIds([]);
    setError(null);
  }, [open]);

  if (!open) return null;

  const otherContacts = contacts.filter((c) => c.clientId !== currentClientId);

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = e.target.files?.[0];
    e.target.value = '';
    if (!picked) return;
    setError(null);
    setFile(picked);
    if (picked.type.startsWith('video/')) {
      setStoryType('video');
      setPreviewUrl(URL.createObjectURL(picked));
    } else if (picked.type.startsWith('image/')) {
      setStoryType('image');
      setPreviewUrl(URL.createObjectURL(picked));
    } else {
      setError('Pick an image or video file.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (storyType === 'text' && !text.trim()) {
      setError('Please enter some text for your story.');
      return;
    }
    if ((storyType === 'image' || storyType === 'video') && !file) {
      setError('Please select a photo or video first.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onCreateStory({
        type: storyType,
        text: text.trim(),
        bgColor,
        file,
        privacy,
        allowedViewerIds: privacy === 'custom' ? allowedIds : undefined,
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to post story.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.addStory}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <form
        onSubmit={handleSubmit}
        className="relative z-10 w-full sm:max-w-md max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold">{t.addStory}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switch */}
        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              { id: 'text', label: t.storyTextMode, Icon: Type },
              { id: 'image', label: t.storyPhotoMode, Icon: ImagePlus },
              { id: 'video', label: t.storyVideoMode, Icon: Video },
            ] as const
          ).map(({ id, label, Icon }) => {
            const active = storyType === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => {
                  setStoryType(id);
                  if (id !== 'text') {
                    setTimeout(() => fileRef.current?.click(), 50);
                  } else {
                    setFile(null);
                    setPreviewUrl(null);
                  }
                }}
                className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                style={{
                  backgroundColor: active ? theme.accentBg : theme.canvasBg,
                  border: `1px solid ${
                    active ? theme.accentBg : theme.borderColor
                  }`,
                  color: active ? '#FFFFFF' : theme.textSecondary,
                }}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>

        <input
          ref={fileRef}
          type="file"
          accept={storyType === 'video' ? 'video/*' : 'image/*,video/*'}
          onChange={handleFilePick}
          className="hidden"
          aria-label="Pick story media"
        />

        {storyType === 'text' ? (
          <div className="space-y-3">
            <div
              className="rounded-2xl p-5 min-h-[160px] flex items-center justify-center"
              style={{ backgroundColor: bgColor }}
            >
              <textarea
                rows={4}
                maxLength={400}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={t.storyPlaceholder}
                aria-label={t.storyPlaceholder}
                className="w-full bg-transparent text-white text-center font-display text-lg font-bold placeholder:text-white/60 outline-none resize-none"
              />
            </div>

            <div className="flex items-center gap-2">
              {STORY_BG_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setBgColor(c)}
                  aria-label={`Story color ${c}`}
                  className="w-8 h-8 rounded-full cursor-pointer transition-transform"
                  style={{
                    backgroundColor: c,
                    transform: c === bgColor ? 'scale(1.12)' : 'scale(1)',
                    boxShadow:
                      c === bgColor
                        ? `0 0 0 2px ${theme.surfaceBg}, 0 0 0 4px ${c}`
                        : 'none',
                  }}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {previewUrl ? (
              <div
                className="relative rounded-2xl overflow-hidden bg-black flex items-center justify-center max-h-64"
                style={{ border: `1px solid ${theme.borderColor}` }}
              >
                {storyType === 'video' ? (
                  <video
                    src={previewUrl}
                    controls
                    className="max-h-64 w-full object-contain"
                  />
                ) : (
                  <img
                    src={previewUrl}
                    alt="Story preview"
                    className="max-h-64 w-full object-contain"
                  />
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="w-full h-36 rounded-2xl border-dashed flex flex-col items-center justify-center gap-2 text-xs font-medium cursor-pointer"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1.5px dashed ${theme.borderColor}`,
                  color: theme.textMuted,
                }}
              >
                <ImagePlus className="w-6 h-6" />
                <span>{t.storyPhotoMode} / {t.storyVideoMode}</span>
              </button>
            )}

            <input
              type="text"
              maxLength={200}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Add caption (optional)..."
              aria-label="Story caption"
              className="w-full h-11 px-3.5 rounded-xl text-sm outline-none"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            />
          </div>
        )}

        {/* Privacy selector */}
        <div className="space-y-2">
          <span
            className="text-xs font-semibold block"
            style={{ color: theme.textSecondary }}
          >
            {t.statusPrivacyDefault}
          </span>
          <div className="grid grid-cols-4 gap-1.5">
            {(
              [
                { value: 'everyone', label: t.everyoneOption },
                { value: 'contacts', label: t.contactsOption },
                { value: 'only_me', label: t.onlyMeOption },
                { value: 'custom', label: 'Custom' },
              ] as const
            ).map((opt) => {
              const active = privacy === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setPrivacy(opt.value)}
                  className="min-h-[38px] px-2 rounded-xl text-xs font-medium cursor-pointer truncate"
                  style={{
                    backgroundColor: active ? theme.accentBg : theme.canvasBg,
                    border: `1px solid ${
                      active ? theme.accentBg : theme.borderColor
                    }`,
                    color: active ? '#FFFFFF' : theme.textSecondary,
                  }}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          {privacy === 'custom' && otherContacts.length > 0 && (
            <div
              className="max-h-32 overflow-y-auto chat-scroll rounded-xl p-2 space-y-1"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
              }}
            >
              {otherContacts.map((c) => {
                const checked = allowedIds.includes(c.clientId);
                return (
                  <label
                    key={c.clientId}
                    className="flex items-center gap-2 px-2 py-1 rounded-lg text-xs cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() =>
                        setAllowedIds((prev) =>
                          checked
                            ? prev.filter((id) => id !== c.clientId)
                            : [...prev, c.clientId]
                        )
                      }
                    />
                    <span className="truncate">{c.displayName}</span>
                  </label>
                );
              })}
            </div>
          )}
        </div>

        {error && (
          <p className="text-xs text-red-400" role="alert">
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-4 rounded-xl text-sm font-medium cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            {t.cancelReply}
          </button>
          <button
            type="submit"
            disabled={submitting}
            data-testid="post-story-btn"
            className="min-h-[44px] px-5 rounded-xl text-sm font-semibold text-white cursor-pointer disabled:opacity-60"
            style={{ backgroundColor: theme.accentBg }}
          >
            {submitting ? t.loadingOlder : t.postStory}
          </button>
        </div>
      </form>
    </div>
  );
}
