import React, { useEffect, useRef, useState } from 'react';
import EmojiPicker, {
  EmojiStyle,
  Theme as EmojiTheme,
  type EmojiClickData,
} from 'emoji-picker-react';
import { ImagePlus, Search, Smile, Sparkles, Sticker } from 'lucide-react';
import { BUILTIN_STICKERS, pushRecentItem } from '../shared/chatRules';
import type { CustomSticker, GifItem, ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

interface EmojiPickerPopoverProps {
  open: boolean;
  theme: ThemeSpec;
  lang?: Lang;
  reactionsMode?: boolean;
  align?: 'left' | 'right';
  placement?: 'top' | 'bottom';
  ariaLabel?: string;
  customStickers?: CustomSticker[];
  onSelectEmoji: (emoji: string) => void;
  onSelectGif?: (gifUrl: string) => void;
  onSelectSticker?: (stickerUrl: string) => void;
  onUploadSticker?: (file: File) => Promise<CustomSticker | null>;
  onClose: () => void;
}

const DEFAULT_REACTION_UNIFIED = [
  '2764-fe0f', // ❤️
  '1f602',     // 😂
  '1f44d',     // 👍
  '1f525',     // 🔥
  '1f62e',     // 😮
  '1f44f',     // 👏
];

const RECENT_EMOJI_KEY = 'arfan_recent_emojis';
const RECENT_STICKER_KEY = 'arfan_recent_stickers';

function readRecentList(key: string): string[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed)
      ? parsed.filter((x): x is string => typeof x === 'string')
      : [];
  } catch {
    return [];
  }
}

function writeRecentList(key: string, items: string[]) {
  try {
    localStorage.setItem(key, JSON.stringify(items));
  } catch {
    // ignore quota errors
  }
}

function builtinStickerToDataUrl(stk: (typeof BUILTIN_STICKERS)[number]): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160"><rect width="160" height="160" rx="28" fill="${stk.bg}"/><text x="80" y="84" text-anchor="middle" dominant-baseline="central" font-size="64">${stk.emoji}</text><text x="80" y="136" text-anchor="middle" fill="${stk.accent}" font-family="sans-serif" font-weight="700" font-size="18">${stk.label}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function EmojiPickerPopover({
  open,
  theme,
  lang = 'en',
  reactionsMode = false,
  align = 'left',
  placement = 'bottom',
  ariaLabel = 'Emoji picker',
  customStickers = [],
  onSelectEmoji,
  onSelectGif,
  onSelectSticker,
  onUploadSticker,
  onClose,
}: EmojiPickerPopoverProps) {
  const t = COPY[lang];
  const containerRef = useRef<HTMLDivElement>(null);
  const stickerInputRef = useRef<HTMLInputElement>(null);

  const [tab, setTab] = useState<'emoji' | 'gifs' | 'stickers'>('emoji');
  const [recentEmojis, setRecentEmojis] = useState<string[]>(() =>
    readRecentList(RECENT_EMOJI_KEY)
  );
  const [recentStickers, setRecentStickers] = useState<string[]>(() =>
    readRecentList(RECENT_STICKER_KEY)
  );
  const [gifQuery, setGifQuery] = useState('');
  const [gifs, setGifs] = useState<GifItem[]>([]);
  const [loadingGifs, setLoadingGifs] = useState(false);
  const [uploadingSticker, setUploadingSticker] = useState(false);

  useEffect(() => {
    if (!open) return;

    const handlePointerDown = (e: PointerEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose, open]);

  // Load GIFs when switching to GIFs tab or typing query (with static data-URI fallback for Netlify Drop)
  useEffect(() => {
    if (!open || reactionsMode || tab !== 'gifs') return;
    let cancelled = false;
    setLoadingGifs(true);

    const makeLocalGif = (
      id: string,
      title: string,
      emoji: string,
      bg1: string,
      bg2: string,
      subtitle: string
    ): GifItem => {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="160" viewBox="0 0 240 160"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${bg1}"/><stop offset="100%" stop-color="${bg2}"/></linearGradient></defs><rect width="240" height="160" rx="18" fill="url(#g)"/><text x="120" y="84" text-anchor="middle" font-size="56">${emoji}<animateTransform attributeName="transform" type="scale" additive="sum" values="1 1;1.12 1.12;1 1" dur="1.1s" repeatCount="indefinite"/></text><rect x="64" y="114" width="112" height="28" rx="10" fill="rgba(0,0,0,0.34)"/><text x="120" y="133" text-anchor="middle" fill="#FFFFFF" font-size="14" font-weight="800" font-family="system-ui, sans-serif">${subtitle}</text></svg>`;
      const dataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
      return { id, title, url: dataUrl, previewUrl: dataUrl, width: 240, height: 160 };
    };

    const fallbackCatalog: GifItem[] = [
      makeLocalGif('happy-dance', 'Happy Dance', '💃', '#7C3AED', '#EC4899', 'YAY!!'),
      makeLocalGif('laugh-cry', 'LOL Laughing', '🤣', '#F59E0B', '#EF4444', 'HAHAHA'),
      makeLocalGif('heart-eyes', 'Sending Love', '😍', '#EC4899', '#E11D48', 'LOVE U'),
      makeLocalGif('fire-hype', 'Pure Fire', '🔥', '#EA580C', '#DC2626', 'ON FIRE!'),
      makeLocalGif('thumbs-cool', 'Approved', '👍', '#059669', '#0EA5E9', 'NICE!'),
      makeLocalGif('party-confetti', 'Celebrate', '🎉', '#8B5CF6', '#F59E0B', 'PARTY!'),
      makeLocalGif('wave-hello', 'Hey There', '👋', '#0284C7', '#10B981', 'HEY!'),
      makeLocalGif('mind-blown', 'Mind Blown', '🤯', '#9333EA', '#2563EB', 'WHOA!'),
    ];

    const q = gifQuery.trim().toLowerCase();
    const endpoint = q
      ? `/api/gifs/search?q=${encodeURIComponent(q)}`
      : '/api/gifs/trending';
    const timer = window.setTimeout(() => {
      void fetch(endpoint)
        .then(async (res) => {
          const ct = res.headers.get('content-type') || '';
          if (!res.ok || !ct.includes('application/json')) {
            throw new Error('Static host');
          }
          return (await res.json()) as { items?: GifItem[]; results?: GifItem[] };
        })
        .then((data) => {
          const list = Array.isArray(data.items)
            ? data.items
            : Array.isArray(data.results)
              ? data.results
              : [];
          if (!cancelled) {
            setGifs(list.length > 0 ? list : fallbackCatalog);
          }
        })
        .catch(() => {
          if (!cancelled) {
            setGifs(
              q
                ? fallbackCatalog.filter((g) => g.title.toLowerCase().includes(q))
                : fallbackCatalog
            );
          }
        })
        .finally(() => {
          if (!cancelled) setLoadingGifs(false);
        });
    }, 180);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [gifQuery, open, reactionsMode, tab]);

  if (!open) return null;

  const handleEmojiPick = (data: EmojiClickData) => {
    if (!data.emoji) return;
    const next = pushRecentItem(recentEmojis, data.emoji, 14);
    setRecentEmojis(next);
    writeRecentList(RECENT_EMOJI_KEY, next);
    onSelectEmoji(data.emoji);
  };

  const handleRecentEmojiPick = (emoji: string) => {
    const next = pushRecentItem(recentEmojis, emoji, 14);
    setRecentEmojis(next);
    writeRecentList(RECENT_EMOJI_KEY, next);
    onSelectEmoji(emoji);
  };

  const handleStickerPick = (url: string) => {
    const next = pushRecentItem(recentStickers, url, 12);
    setRecentStickers(next);
    writeRecentList(RECENT_STICKER_KEY, next);
    onSelectSticker?.(url);
    onClose();
  };

  const handleCustomStickerUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !onUploadSticker) return;
    setUploadingSticker(true);
    try {
      const created = await onUploadSticker(file);
      if (created?.url) {
        handleStickerPick(created.url);
      }
    } finally {
      setUploadingSticker(false);
    }
  };

  const pickerVars = {
    '--epr-bg-color': theme.surfaceBg,
    '--epr-category-label-bg-color': theme.surfaceBg,
    '--epr-search-input-bg-color': theme.canvasBg,
    '--epr-search-input-text-color': theme.textPrimary,
    '--epr-hover-bg-color': theme.surfaceHoverBg,
    '--epr-focus-bg-color': theme.accentSoftBg,
    '--epr-highlight-color': theme.accentBg,
    '--epr-text-color': theme.textPrimary,
    '--epr-picker-border-color': theme.borderColor,
    '--epr-reactions-bg-color': theme.surfaceBg,
    '--epr-picker-border-radius': '16px',
  } as React.CSSProperties;

  const positionClass =
    placement === 'top'
      ? `bottom-full mb-2 ${align === 'right' ? 'right-0' : 'left-0'}`
      : `top-full mt-1.5 ${align === 'right' ? 'right-0' : 'left-0'}`;

  if (reactionsMode) {
    return (
      <div
        ref={containerRef}
        role="dialog"
        aria-label={ariaLabel}
        data-testid="emoji-picker-popover"
        className={`absolute ${positionClass} z-40 shadow-2xl rounded-2xl max-w-[calc(100vw-24px)]`}
      >
        <EmojiPicker
          open={open}
          colorScheme={theme.isDark ? EmojiTheme.DARK : EmojiTheme.LIGHT}
          emojiStyle={EmojiStyle.NATIVE}
          reactionsDefaultOpen={true}
          allowExpandReactions={true}
          reactions={DEFAULT_REACTION_UNIFIED}
          lazyLoadEmojis={true}
          autoFocusSearch={false}
          previewConfig={{ showPreview: false }}
          width={320}
          height={360}
          style={pickerVars}
          onReactionClick={handleEmojiPick}
          onEmojiClick={handleEmojiPick}
        />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      role="dialog"
      aria-label={ariaLabel}
      data-testid="emoji-picker-popover"
      className={`absolute ${positionClass} z-40 shadow-2xl rounded-2xl overflow-hidden w-[336px] max-w-[calc(100vw-24px)]`}
      style={{
        backgroundColor: theme.surfaceBg,
        border: `1px solid ${theme.borderColor}`,
        color: theme.textPrimary,
      }}
    >
      {/* Tabs Header */}
      <div
        className="grid grid-cols-3 gap-1 p-1.5"
        style={{
          backgroundColor: theme.canvasBg,
          borderBottom: `1px solid ${theme.borderColor}`,
        }}
      >
        <button
          type="button"
          onClick={() => setTab('emoji')}
          className="h-9 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          style={{
            backgroundColor: tab === 'emoji' ? theme.accentBg : 'transparent',
            color: tab === 'emoji' ? '#FFFFFF' : theme.textSecondary,
          }}
        >
          <Smile className="w-3.5 h-3.5" />
          <span>{t.emojiTab}</span>
        </button>

        <button
          type="button"
          onClick={() => setTab('gifs')}
          className="h-9 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          style={{
            backgroundColor: tab === 'gifs' ? theme.accentBg : 'transparent',
            color: tab === 'gifs' ? '#FFFFFF' : theme.textSecondary,
          }}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{t.gifsTab}</span>
        </button>

        <button
          type="button"
          onClick={() => setTab('stickers')}
          className="h-9 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          style={{
            backgroundColor: tab === 'stickers' ? theme.accentBg : 'transparent',
            color: tab === 'stickers' ? '#FFFFFF' : theme.textSecondary,
          }}
        >
          <Sticker className="w-3.5 h-3.5" />
          <span>{t.stickersTab}</span>
        </button>
      </div>

      {/* Tab 1: Emoji Picker + Recents */}
      {tab === 'emoji' && (
        <div>
          {recentEmojis.length > 0 && (
            <div
              className="px-2.5 py-2 flex items-center gap-1 overflow-x-auto"
              style={{ borderBottom: `1px solid ${theme.borderColor}` }}
            >
              <span
                className="text-[10px] font-semibold mr-1 shrink-0"
                style={{ color: theme.textMuted }}
              >
                {t.recentLabel}
              </span>
              {recentEmojis.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => handleRecentEmojiPick(em)}
                  className="w-7 h-7 rounded-lg hover:bg-white/10 flex items-center justify-center text-base shrink-0 cursor-pointer"
                >
                  {em}
                </button>
              ))}
            </div>
          )}
          <EmojiPicker
            open={open}
            colorScheme={theme.isDark ? EmojiTheme.DARK : EmojiTheme.LIGHT}
            emojiStyle={EmojiStyle.NATIVE}
            lazyLoadEmojis={true}
            autoFocusSearch={true}
            previewConfig={{ showPreview: false }}
            width={334}
            height={320}
            style={pickerVars}
            onEmojiClick={handleEmojiPick}
          />
        </div>
      )}

      {/* Tab 2: Animated GIFs */}
      {tab === 'gifs' && (
        <div className="p-3 h-[340px] flex flex-col gap-2.5">
          <div
            className="flex items-center h-9 px-3 rounded-xl gap-2 shrink-0"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <Search className="w-3.5 h-3.5 shrink-0" style={{ color: theme.textMuted }} />
            <input
              type="text"
              value={gifQuery}
              onChange={(e) => setGifQuery(e.target.value)}
              placeholder={t.searchGifsPlaceholder}
              aria-label={t.searchGifsPlaceholder}
              className="flex-1 bg-transparent text-xs outline-none"
              style={{ color: theme.textPrimary }}
            />
          </div>

          <div className="flex-1 overflow-y-auto chat-scroll">
            {loadingGifs ? (
              <p className="text-xs text-center py-8" style={{ color: theme.textMuted }}>
                {t.loadingOlder}
              </p>
            ) : gifs.length === 0 ? (
              <p className="text-xs text-center py-8" style={{ color: theme.textMuted }}>
                No GIFs matched.
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {gifs.map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => {
                      onSelectGif?.(g.url);
                      onClose();
                    }}
                    className="relative rounded-xl overflow-hidden aspect-[4/3] bg-black/20 hover:opacity-90 transition-opacity cursor-pointer"
                    style={{ border: `1px solid ${theme.borderColor}` }}
                  >
                    <img
                      src={g.previewUrl || g.url}
                      alt={g.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Built-in + Custom Stickers + Recents */}
      {tab === 'stickers' && (
        <div className="p-3 h-[340px] flex flex-col gap-2.5">
          {onUploadSticker && (
            <>
              <input
                ref={stickerInputRef}
                type="file"
                accept="image/*"
                onChange={handleCustomStickerUpload}
                className="hidden"
              />
              <button
                type="button"
                disabled={uploadingSticker}
                onClick={() => stickerInputRef.current?.click()}
                className="min-h-[38px] px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-60"
                style={{
                  backgroundColor: theme.accentSoftBg,
                  border: `1px solid ${theme.accentBorder}`,
                  color: theme.accentText,
                }}
              >
                <ImagePlus className="w-3.5 h-3.5" />
                <span>
                  {uploadingSticker ? t.uploadingBackground : t.uploadSticker}
                </span>
              </button>
            </>
          )}

          <div className="flex-1 overflow-y-auto chat-scroll space-y-3">
            {recentStickers.length > 0 && (
              <div>
                <span
                  className="text-[11px] font-semibold block mb-1.5"
                  style={{ color: theme.textMuted }}
                >
                  {t.recentLabel}
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {recentStickers.map((url, idx) => (
                    <button
                      key={`${url}-${idx}`}
                      type="button"
                      onClick={() => handleStickerPick(url)}
                      className="aspect-square rounded-xl overflow-hidden p-1 hover:scale-105 transition-transform cursor-pointer"
                      style={{ backgroundColor: theme.canvasBg }}
                    >
                      <img
                        src={url}
                        alt="Recent sticker"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {customStickers.length > 0 && (
              <div>
                <span
                  className="text-[11px] font-semibold block mb-1.5"
                  style={{ color: theme.textMuted }}
                >
                  Custom
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {customStickers.map((stk) => (
                    <button
                      key={stk.id}
                      type="button"
                      onClick={() => handleStickerPick(stk.url)}
                      title={stk.label}
                      className="aspect-square rounded-xl overflow-hidden p-1 hover:scale-105 transition-transform cursor-pointer"
                      style={{ backgroundColor: theme.canvasBg }}
                    >
                      <img
                        src={stk.url}
                        alt={stk.label}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <span
                className="text-[11px] font-semibold block mb-1.5"
                style={{ color: theme.textMuted }}
              >
                Stickers
              </span>
              <div className="grid grid-cols-4 gap-2">
                {BUILTIN_STICKERS.map((stk) => {
                  const dataUrl = builtinStickerToDataUrl(stk);
                  return (
                    <button
                      key={stk.id}
                      type="button"
                      onClick={() => handleStickerPick(dataUrl)}
                      className="aspect-square rounded-2xl flex flex-col items-center justify-center p-1 hover:scale-105 transition-transform cursor-pointer"
                      style={{ backgroundColor: stk.bg }}
                      title={stk.label}
                    >
                      <span className="text-2xl leading-none">{stk.emoji}</span>
                      <span
                        className="text-[9px] font-bold mt-1"
                        style={{ color: stk.accent }}
                      >
                        {stk.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
