import React, { useEffect, useState } from 'react';
import { Flag, X } from 'lucide-react';
import type { ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';

export interface ReportTarget {
  targetId: string;
  targetName: string;
  targetType: 'user' | 'message';
  messageId?: string;
  messagePreview?: string;
}

interface ReportModalProps {
  target: ReportTarget | null;
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onSubmitReport: (input: ReportTarget & { reason: string }) => Promise<void>;
}

export function ReportModal({
  target,
  theme,
  lang,
  onClose,
  onSubmitReport,
}: ReportModalProps) {
  const t = COPY[lang];
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setReason('');
  }, [target]);

  if (!target) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (reason.trim().length < 2) return;
    setSubmitting(true);
    try {
      await onSubmitReport({ ...target, reason: reason.trim() });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.reportModalTitle}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <form
        onSubmit={handleSubmit}
        className="relative z-10 w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flag className="w-4 h-4 text-amber-400" />
            <h2 className="font-display text-base font-bold">
              {t.reportModalTitle}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          className="px-3 py-2 rounded-xl text-xs"
          style={{
            backgroundColor: theme.canvasBg,
            border: `1px solid ${theme.borderColor}`,
            color: theme.textSecondary,
          }}
        >
          <strong>{target.targetName}</strong>
          {target.messagePreview ? `: ${target.messagePreview}` : ''}
        </div>

        <textarea
          rows={3}
          required
          minLength={2}
          maxLength={300}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder={t.reportReasonPlaceholder}
          aria-label={t.reportReasonPlaceholder}
          className="w-full p-3 rounded-xl text-sm outline-none resize-none"
          style={{
            backgroundColor: theme.canvasBg,
            border: `1px solid ${theme.borderColor}`,
            color: theme.textPrimary,
          }}
        />

        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[42px] px-4 rounded-xl text-sm font-medium cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            {t.cancelReply}
          </button>
          <button
            type="submit"
            disabled={submitting || reason.trim().length < 2}
            className="min-h-[42px] px-4 rounded-xl text-sm font-semibold text-white bg-amber-600 hover:bg-amber-500 cursor-pointer disabled:opacity-60"
          >
            {t.submitReport}
          </button>
        </div>
      </form>
    </div>
  );
}
