import React, { useEffect, useState } from 'react';
import { Hash, Send, Users, X } from 'lucide-react';
import { MAIN_ROOM_ID } from '../firebase';
import { getDirectRoomId } from '../shared/chatRules';
import type {
  ChatGroup,
  ChatMessage,
  DirectPeer,
  ThemeSpec,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface ForwardModalProps {
  message: ChatMessage | null;
  currentClientId: string;
  groups: ChatGroup[];
  contacts: UserProfile[];
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onForward: (
    sourceMsg: ChatMessage,
    targetRoomId: string,
    targetPeer: DirectPeer | null
  ) => Promise<void>;
}

export function ForwardModal({
  message,
  currentClientId,
  groups,
  contacts,
  theme,
  lang,
  onClose,
  onForward,
}: ForwardModalProps) {
  const t = COPY[lang];
  const [sentIds, setSentIds] = useState<string[]>([]);

  useEffect(() => {
    setSentIds([]);
  }, [message]);

  useEffect(() => {
    if (!message) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [message, onClose]);

  if (!message) return null;

  const otherContacts = contacts.filter((c) => c.clientId !== currentClientId);

  const handleSendTo = async (
    targetRoomId: string,
    targetPeer: DirectPeer | null
  ) => {
    await onForward(message, targetRoomId, targetPeer);
    setSentIds((prev) => [...prev, targetRoomId]);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.forwardTitle}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full sm:max-w-md max-h-[85dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold">{t.forwardTitle}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <ul className="space-y-2">
          <li
            className="px-3 py-2.5 rounded-xl flex items-center justify-between gap-2"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <span className="flex items-center gap-2 text-sm font-medium">
              <Hash className="w-4 h-4" style={{ color: theme.accentText }} />
              <span>{t.groupChatTitle}</span>
            </span>
            <button
              type="button"
              disabled={sentIds.includes(MAIN_ROOM_ID)}
              onClick={() => void handleSendTo(MAIN_ROOM_ID, null)}
              className="min-h-[36px] px-3 rounded-xl text-xs font-semibold text-white flex items-center gap-1 cursor-pointer disabled:opacity-60"
              style={{
                backgroundColor: sentIds.includes(MAIN_ROOM_ID)
                  ? '#059669'
                  : theme.accentBg,
              }}
            >
              <Send className="w-3.5 h-3.5" />
              <span>{sentIds.includes(MAIN_ROOM_ID) ? 'Sent' : t.send}</span>
            </button>
          </li>

          {groups.map((grp) => (
            <li
              key={grp.id}
              className="px-3 py-2.5 rounded-xl flex items-center justify-between gap-2"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
              }}
            >
              <span className="flex items-center gap-2 text-sm font-medium truncate">
                <Users className="w-4 h-4 shrink-0" style={{ color: theme.accentText }} />
                <span className="truncate">{grp.name}</span>
              </span>
              <button
                type="button"
                disabled={sentIds.includes(grp.id)}
                onClick={() => void handleSendTo(grp.id, null)}
                className="min-h-[36px] px-3 rounded-xl text-xs font-semibold text-white flex items-center gap-1 shrink-0 cursor-pointer disabled:opacity-60"
                style={{
                  backgroundColor: sentIds.includes(grp.id)
                    ? '#059669'
                    : theme.accentBg,
                }}
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sentIds.includes(grp.id) ? 'Sent' : t.send}</span>
              </button>
            </li>
          ))}

          {otherContacts.map((c) => {
            const dmRoomId = getDirectRoomId(currentClientId, c.clientId);
            const peer: DirectPeer = {
              clientId: c.clientId,
              nickname: c.displayName,
              avatarColor: c.avatarColor,
              avatarUrl: c.avatarUrl,
              dmRoomId,
            };
            const isSent = sentIds.includes(dmRoomId);
            return (
              <li
                key={c.clientId}
                className="px-3 py-2.5 rounded-xl flex items-center justify-between gap-2"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                }}
              >
                <span className="flex items-center gap-2.5 text-sm font-medium truncate">
                  <AvatarBadge
                    name={c.displayName}
                    avatarColor={c.avatarColor}
                    avatarUrl={c.avatarUrl}
                    online={c.online}
                    size="xs"
                  />
                  <span className="truncate">{c.displayName}</span>
                </span>
                <button
                  type="button"
                  disabled={isSent}
                  onClick={() => void handleSendTo(dmRoomId, peer)}
                  className="min-h-[36px] px-3 rounded-xl text-xs font-semibold text-white flex items-center gap-1 shrink-0 cursor-pointer disabled:opacity-60"
                  style={{
                    backgroundColor: isSent ? '#059669' : theme.accentBg,
                  }}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSent ? 'Sent' : t.send}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
