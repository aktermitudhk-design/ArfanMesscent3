import React from 'react';
import { Phone, PhoneIncoming, PhoneOff, Video, X } from 'lucide-react';
import type { CallMediaKind, DirectPing, ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface IncomingCallModalProps {
  incomingCall: DirectPing | null;
  inCall: boolean;
  missedCalls: DirectPing[];
  theme: ThemeSpec;
  lang: Lang;
  onAccept: (ping: DirectPing, callKind: CallMediaKind) => void;
  onReject: (ping: DirectPing) => void;
  onDismissMissed: (pingId: string) => void;
  onCallBackMissed: (ping: DirectPing) => void;
}

export function IncomingCallModal({
  incomingCall,
  inCall,
  missedCalls,
  theme,
  lang,
  onAccept,
  onReject,
  onDismissMissed,
  onCallBackMissed,
}: IncomingCallModalProps) {
  const t = COPY[lang];
  const latestMissed = missedCalls[0] || null;

  return (
    <>
      {/* Missed call notification toast strip */}
      {latestMissed && !incomingCall && (
        <div
          data-testid="missed-call-alert"
          className="px-3 sm:px-5 py-2 flex items-center justify-between gap-3 shrink-0"
          style={{
            backgroundColor: 'rgba(239, 68, 68, 0.14)',
            borderBottom: '1px solid rgba(239, 68, 68, 0.3)',
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center gap-2 min-w-0 text-xs">
            <PhoneOff className="w-4 h-4 text-red-400 shrink-0" />
            <span className="truncate">
              <strong>{t.missedCallLabel}</strong> {latestMissed.fromNickname}
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                onCallBackMissed(latestMissed);
                onDismissMissed(latestMissed.id);
              }}
              className="h-7 px-2.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 cursor-pointer"
            >
              {t.callFriend}
            </button>
            <button
              type="button"
              onClick={() => onDismissMissed(latestMissed.id)}
              aria-label={t.close}
              className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Full Messenger-style Incoming Call Dialog */}
      {incomingCall && !inCall && (
        <div
          data-testid="incoming-call-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md"
          role="dialog"
          aria-modal="true"
          aria-label={`${incomingCall.fromNickname} ${t.incomingCallAlert}`}
        >
          <div
            className="w-full max-w-sm rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center space-y-5"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          >
            <div className="relative">
              <AvatarBadge
                name={incomingCall.fromNickname}
                avatarColor={incomingCall.fromColor}
                size="xl"
              />
              <span
                className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg"
                aria-hidden="true"
              >
                <PhoneIncoming className="w-4 h-4" />
              </span>
            </div>

            <div>
              <h2 className="font-display text-xl font-bold">
                {incomingCall.fromNickname}
              </h2>
              <p
                className="text-sm mt-1"
                style={{ color: theme.textSecondary }}
              >
                {incomingCall.callKind === 'audio'
                  ? t.incomingAudioCallAlert
                  : t.incomingVideoCallAlert}{' '}
                · {t.incomingCallAlert}
              </p>
            </div>

            <div className="w-full flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => onReject(incomingCall)}
                aria-label={t.declineCall}
                className="min-h-[48px] flex-1 px-4 rounded-2xl text-sm font-semibold bg-red-600 hover:bg-red-500 text-white flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <PhoneOff className="w-4 h-4" />
                <span>{t.declineCall}</span>
              </button>

              {incomingCall.callKind === 'audio' ? (
                <button
                  type="button"
                  onClick={() => onAccept(incomingCall, 'audio')}
                  aria-label={t.acceptCall}
                  className="min-h-[48px] flex-1 px-4 rounded-2xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Phone className="w-4 h-4" />
                  <span>{t.acceptCall}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onAccept(incomingCall, 'video')}
                  aria-label={t.acceptCall}
                  className="min-h-[48px] flex-1 px-4 rounded-2xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Video className="w-4 h-4" />
                  <span>{t.acceptCall}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
