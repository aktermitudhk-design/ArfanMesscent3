import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Phone,
  Shield,
  Trash2,
  UserMinus,
  UserPlus,
  Users,
  Video,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  canManageGroupMembers,
  canManageGroupSettings,
  isGroupAdmin,
} from '../shared/chatRules';
import type { ChatGroup, ThemeSpec, UserProfile } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface GroupModalProps {
  open: boolean;
  mode: 'create' | 'manage';
  group: ChatGroup | null;
  currentClientId: string;
  isGlobalAdmin: boolean;
  contacts: UserProfile[];
  profilesById: Record<string, UserProfile>;
  mutedRoomIds: string[];
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onCreateGroup: (input: {
    name: string;
    description?: string;
    memberIds: string[];
    avatarFile?: File | null;
  }) => Promise<ChatGroup | null>;
  onSelectGroup?: (group: ChatGroup) => void;
  onUpdateGroup: (
    group: ChatGroup,
    patch: { name?: string; description?: string; avatarFile?: File | null }
  ) => Promise<void>;
  onAddMember: (group: ChatGroup, memberId: string) => Promise<void>;
  onRemoveMember: (group: ChatGroup, memberId: string) => Promise<void>;
  onToggleAdmin: (group: ChatGroup, memberId: string) => Promise<void>;
  onToggleMute: (roomId: string) => void;
  onStartGroupCall: (group: ChatGroup, callKind: 'audio' | 'video') => void;
  onDeleteGroup: (group: ChatGroup) => Promise<void>;
}

export function GroupModal({
  open,
  mode,
  group,
  currentClientId,
  isGlobalAdmin,
  contacts,
  profilesById,
  mutedRoomIds,
  theme,
  lang,
  onClose,
  onCreateGroup,
  onSelectGroup,
  onUpdateGroup,
  onAddMember,
  onRemoveMember,
  onToggleAdmin,
  onToggleMute,
  onStartGroupCall,
  onDeleteGroup,
}: GroupModalProps) {
  const t = COPY[lang];
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    if (mode === 'manage' && group) {
      setName(group.name);
      setDescription(group.description || '');
      setAvatarPreview(group.avatarUrl || null);
      setAvatarFile(null);
    } else {
      setName('');
      setDescription('');
      setSelectedIds([]);
      setAvatarPreview(null);
      setAvatarFile(null);
    }
    setError(null);
  }, [group, mode, open]);

  if (!open) return null;

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !file.type.startsWith('image/')) return;
    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError('Group name must be at least 2 characters.');
      return;
    }
    setSaving(true);
    try {
      const created = await onCreateGroup({
        name: name.trim(),
        description: description.trim(),
        memberIds: selectedIds,
        avatarFile,
      });
      if (created && onSelectGroup) {
        onSelectGroup(created);
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create group.');
    } finally {
      setSaving(false);
    }
  };

  if (mode === 'create') {
    const otherContacts = contacts.filter((c) => c.clientId !== currentClientId);

    return (
      <div
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        role="dialog"
        aria-modal="true"
        aria-label={t.createGroup}
      >
        <div
          className="fixed inset-0 bg-black/65 backdrop-blur-xs"
          onClick={onClose}
          aria-hidden="true"
        />

        <form
          onSubmit={handleCreateSubmit}
          className="relative z-10 w-full sm:max-w-md max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
            color: theme.textPrimary,
          }}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold">{t.createGroup}</h2>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.close}
              className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <AvatarBadge
              name={name || 'GP'}
              avatarColor={theme.accentBg}
              avatarUrl={avatarPreview}
              size="lg"
            />
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              onChange={handleFilePick}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="min-h-[40px] px-3 rounded-xl text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            >
              <Camera className="w-4 h-4" />
              <span>{t.uploadAvatar}</span>
            </button>
          </div>

          <div>
            <label
              htmlFor="create-group-name"
              className="block text-xs font-semibold mb-1.5"
              style={{ color: theme.textSecondary }}
            >
              {t.groupNameLabel}
            </label>
            <input
              id="create-group-name"
              type="text"
              required
              maxLength={50}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Dhaka Squad"
              className="w-full h-11 px-3.5 rounded-xl text-sm outline-none"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            />
          </div>

          <div>
            <label
              htmlFor="create-group-desc"
              className="block text-xs font-semibold mb-1.5"
              style={{ color: theme.textSecondary }}
            >
              {t.groupDescLabel}
            </label>
            <textarea
              id="create-group-desc"
              rows={2}
              maxLength={240}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-3 rounded-xl text-sm outline-none resize-none"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.textPrimary,
              }}
            />
          </div>

          <div>
            <span
              className="block text-xs font-semibold mb-1.5"
              style={{ color: theme.textSecondary }}
            >
              {t.addMember} ({selectedIds.length})
            </span>
            <div
              className="max-h-40 overflow-y-auto chat-scroll rounded-xl p-2 space-y-1"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
              }}
            >
              {otherContacts.length === 0 ? (
                <p className="text-xs px-2 py-2" style={{ color: theme.textMuted }}>
                  No contacts discovered yet. You can add friends after they join.
                </p>
              ) : (
                otherContacts.map((c) => {
                  const checked = selectedIds.includes(c.clientId);
                  return (
                    <label
                      key={c.clientId}
                      className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg text-xs cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() =>
                          setSelectedIds((prev) =>
                            checked
                              ? prev.filter((id) => id !== c.clientId)
                              : [...prev, c.clientId]
                          )
                        }
                      />
                      <AvatarBadge
                        name={c.displayName}
                        avatarColor={c.avatarColor}
                        avatarUrl={c.avatarUrl}
                        online={c.online}
                        size="xs"
                      />
                      <span className="truncate font-medium">{c.displayName}</span>
                    </label>
                  );
                })
              )}
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-400" role="alert">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-4 rounded-xl text-sm font-medium cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              {t.cancelReply}
            </button>
            <button
              type="submit"
              disabled={saving}
              data-testid="create-group-submit"
              className="min-h-[44px] px-5 rounded-xl text-sm font-semibold text-white cursor-pointer disabled:opacity-60"
              style={{ backgroundColor: theme.accentBg }}
            >
              {t.createGroup}
            </button>
          </div>
        </form>
      </div>
    );
  }

  // Manage existing Group mode
  if (!group) return null;
  const canEdit = canManageGroupSettings(group, currentClientId, isGlobalAdmin);
  const canMembers = canManageGroupMembers(group, currentClientId, isGlobalAdmin);
  const isMuted = mutedRoomIds.includes(group.id);
  const addableContacts = contacts.filter(
    (c) => !group.memberIds.includes(c.clientId)
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.groupInfo}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full sm:max-w-lg max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-5"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold">{t.groupInfo}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Group Call + Mute bar */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => {
              onStartGroupCall(group, 'audio');
              onClose();
            }}
            className="min-h-[42px] px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <Phone className="w-4 h-4" />
            <span>{t.startAudioCall}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onStartGroupCall(group, 'video');
              onClose();
            }}
            className="min-h-[42px] px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              backgroundColor: 'rgba(16, 185, 129, 0.16)',
              border: '1px solid rgba(52, 211, 153, 0.35)',
              color: '#34D399',
            }}
          >
            <Video className="w-4 h-4" />
            <span>{t.startVideoCall}</span>
          </button>
          <button
            type="button"
            onClick={() => onToggleMute(group.id)}
            className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            {isMuted ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
            <span>{isMuted ? t.unmuteRoom : t.muteRoom}</span>
          </button>
        </div>

        {/* Edit Group Details */}
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <AvatarBadge
              name={group.name}
              avatarColor={group.avatarColor}
              avatarUrl={avatarPreview || group.avatarUrl}
              size="lg"
            />
            {canEdit && (
              <>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFilePick}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="min-h-[40px] px-3 rounded-xl text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <Camera className="w-4 h-4" />
                  <span>{t.uploadAvatar}</span>
                </button>
              </>
            )}
          </div>

          <input
            type="text"
            disabled={!canEdit}
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={50}
            aria-label={t.groupNameLabel}
            className="w-full h-11 px-3.5 rounded-xl text-sm outline-none disabled:opacity-75"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />

          <textarea
            rows={2}
            disabled={!canEdit}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={240}
            placeholder={t.groupDescLabel}
            aria-label={t.groupDescLabel}
            className="w-full p-3 rounded-xl text-sm outline-none resize-none disabled:opacity-75"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />

          {canEdit && (
            <button
              type="button"
              disabled={saving}
              onClick={async () => {
                setSaving(true);
                try {
                  await onUpdateGroup(group, {
                    name,
                    description,
                    avatarFile,
                  });
                } finally {
                  setSaving(false);
                }
              }}
              className="min-h-[40px] px-4 rounded-xl text-xs font-semibold text-white cursor-pointer disabled:opacity-60"
              style={{ backgroundColor: theme.accentBg }}
            >
              {t.saveRoomTitle}
            </button>
          )}
        </div>

        {/* Members List */}
        <div
          className="pt-4 space-y-2.5"
          style={{ borderTop: `1px solid ${theme.borderColor}` }}
        >
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4" style={{ color: theme.accentText }} />
              <span>
                {t.groupMembersLabel} ({group.memberIds.length})
              </span>
            </span>
          </div>

          <ul className="space-y-1.5 max-h-44 overflow-y-auto chat-scroll">
            {group.memberIds.map((mid) => {
              const p = profilesById[mid];
              const mName = p?.displayName || mid;
              const isGrpAdmin = isGroupAdmin(group, mid);
              const isCreator = group.createdBy === mid;

              return (
                <li
                  key={mid}
                  className="px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <AvatarBadge
                      name={mName}
                      avatarColor={p?.avatarColor || '#7C3AED'}
                      avatarUrl={p?.avatarUrl}
                      online={p?.online}
                      size="xs"
                    />
                    <span className="truncate font-medium">
                      {mName}
                      {mid === currentClientId ? ` (${t.you})` : ''}
                    </span>
                    {isGrpAdmin && (
                      <span
                        className="text-[10px] font-semibold shrink-0"
                        style={{ color: theme.accentText }}
                      >
                        · {t.adminBadge}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {canMembers && !isCreator && (
                      <button
                        type="button"
                        onClick={() => void onToggleAdmin(group, mid)}
                        title={isGrpAdmin ? t.removeAdmin : t.makeAdmin}
                        aria-label={isGrpAdmin ? t.removeAdmin : t.makeAdmin}
                        className="px-2 py-1 rounded-lg text-[11px] font-medium cursor-pointer"
                        style={{
                          backgroundColor: theme.surfaceBg,
                          color: theme.accentText,
                        }}
                      >
                        <Shield className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {(mid === currentClientId || (canMembers && !isCreator)) && (
                      <button
                        type="button"
                        onClick={() => void onRemoveMember(group, mid)}
                        title={t.removeMember}
                        aria-label={`${t.removeMember} ${mName}`}
                        className="px-2 py-1 rounded-lg text-red-400 hover:bg-red-500/15 cursor-pointer"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>

          {canMembers && addableContacts.length > 0 && (
            <div className="pt-2 space-y-1.5">
              <span
                className="text-xs font-medium block"
                style={{ color: theme.textMuted }}
              >
                {t.addMember}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {addableContacts.slice(0, 8).map((c) => (
                  <button
                    key={c.clientId}
                    type="button"
                    onClick={() => void onAddMember(group, c.clientId)}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1 cursor-pointer"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{c.displayName}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {canEdit && (
          <div
            className="pt-3 flex justify-end"
            style={{ borderTop: `1px solid ${theme.borderColor}` }}
          >
            <button
              type="button"
              onClick={async () => {
                await onDeleteGroup(group);
                onClose();
              }}
              className="min-h-[40px] px-3.5 rounded-xl text-xs font-semibold text-red-400 bg-red-500/15 flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Group</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
