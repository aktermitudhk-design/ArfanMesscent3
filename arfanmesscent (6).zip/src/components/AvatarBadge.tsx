import React, { useState } from 'react';
import { getInitials } from '../shared/chatRules';

interface AvatarBadgeProps {
  name: string;
  avatarColor: string;
  avatarUrl?: string | null;
  canViewPhoto?: boolean;
  online?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  ringColor?: string;
  dotBorderColor?: string;
  storyRing?: 'unviewed' | 'viewed' | 'none';
}

const SIZE_MAP = {
  xs: { box: 'w-6 h-6 text-[9px]', dot: 'w-2 h-2' },
  sm: { box: 'w-8 h-8 text-[11px]', dot: 'w-2.5 h-2.5' },
  md: { box: 'w-10 h-10 text-xs', dot: 'w-2.5 h-2.5' },
  lg: { box: 'w-14 h-14 text-base', dot: 'w-3.5 h-3.5' },
  xl: { box: 'w-20 h-20 text-xl', dot: 'w-4 h-4' },
} as const;

export function AvatarBadge({
  name,
  avatarColor,
  avatarUrl,
  canViewPhoto = true,
  online = false,
  size = 'sm',
  dotBorderColor = '#110F1A',
  storyRing = 'none',
}: AvatarBadgeProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const dims = SIZE_MAP[size];
  const showImage = Boolean(canViewPhoto && avatarUrl && !imgFailed);

  const ringStyle: React.CSSProperties | undefined =
    storyRing === 'unviewed'
      ? { boxShadow: '0 0 0 2px #10B981' }
      : storyRing === 'viewed'
        ? { boxShadow: '0 0 0 2px rgba(148, 163, 184, 0.45)' }
        : undefined;

  return (
    <div className="relative shrink-0 inline-flex">
      <div
        className={`${dims.box} rounded-full overflow-hidden flex items-center justify-center font-bold text-white select-none`}
        style={{
          backgroundColor: avatarColor || '#7C3AED',
          ...ringStyle,
        }}
      >
        {showImage ? (
          <img
            src={avatarUrl!}
            alt={name}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="w-full h-full object-cover"
          />
        ) : (
          <span>{getInitials(name || '?')}</span>
        )}
      </div>

      {online && (
        <span
          className={`absolute -bottom-0.5 -right-0.5 ${dims.dot} rounded-full bg-emerald-500`}
          style={{ boxShadow: `0 0 0 2px ${dotBorderColor}` }}
          aria-label="Online"
        />
      )}
    </div>
  );
}
