import React, { useMemo, useState } from 'react';
import {
  Ban,
  Check,
  Copy,
  Edit3,
  Hash,
  MessageCircle,
  MessageSquare,
  Phone,
  Plus,
  Search,
  Settings,
  Share2,
  Shield,
  ShieldCheck,
  Sparkles,
  Trash2,
  Users,
  Video,
  VolumeX,
  X,
} from 'lucide-react';
import {
  canViewProfileField,
  formatLastSeen,
  isUserBlocked,
} from '../shared/chatRules';
import type {
  BlockedUser,
  ChatGroup,
  DirectPeer,
  OnlineUser,
  StoryStatus,
  ThemeSpec,
  UserProfile,
} from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { AvatarBadge } from './AvatarBadge';

interface StoryAuthorBucket {
  authorId: string;
  authorName: string;
  authorColor: string;
  authorAvatarUrl?: string | null;
  stories: StoryStatus[];
  hasUnviewed: boolean;
}

interface SidebarMembersProps {
  onlineUsers: OnlineUser[];
  allProfiles: UserProfile[];
  profilesById: Record<string, UserProfile>;
  ownProfile: UserProfile | null;
  myGroups: ChatGroup[];
  storiesByAuthor: StoryAuthorBucket[];
  currentClientId: string;
  currentNickname: string;
  currentAvatarColor: string;
  isAdmin: boolean;
  guestLinkMode: boolean;
  inviteUrl: string;
  copied: boolean;
  activeRoomId: string;
  activeDirectPeer: DirectPeer | null;
  unreadByPeerId: Record<string, number>;
  blockedPeerIds: string[];
  blockedUsers: BlockedUser[];
  mutedRoomIds: string[];
  allowGroupCreation?: boolean;
  theme: ThemeSpec;
  lang: Lang;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onToggleGuestLinkMode: (directGuest: boolean) => void;
  onCopyInvite: () => void;
  onShareInvite: () => void;
  onSelectGroupChat: () => void;
  onSelectCustomGroup: (group: ChatGroup) => void;
  onOpenCreateGroup: () => void;
  onSelectDirectPeer: (user: {
    clientId: string;
    nickname: string;
    avatarColor: string;
    avatarUrl?: string | null;
  }) => void;
  onCallDirectPeer: (
    user: {
      clientId: string;
      nickname: string;
      avatarColor: string;
      avatarUrl?: string | null;
    },
    callKind: 'audio' | 'video'
  ) => void;
  onViewProfile: (profile: UserProfile) => void;
  onOpenOwnProfile: () => void;
  onOpenSettings: () => void;
  onOpenCreateStory: () => void;
  onOpenStoryBucket: (bucket: StoryAuthorBucket) => void;
  onBlockUser: (user: OnlineUser) => void;
  onDeleteContact: (user: { clientId: string; nickname: string }) => void;
  onOpenAdmin: () => void;
  onChangeNickname: () => void;
}

export function SidebarMembers({
  onlineUsers,
  allProfiles,
  profilesById,
  ownProfile,
  myGroups,
  storiesByAuthor,
  currentClientId,
  currentNickname,
  currentAvatarColor,
  isAdmin,
  guestLinkMode,
  inviteUrl,
  copied,
  activeRoomId,
  activeDirectPeer,
  unreadByPeerId,
  blockedPeerIds,
  blockedUsers,
  mutedRoomIds,
  allowGroupCreation = true,
  theme,
  lang,
  mobileOpen,
  onCloseMobile,
  onToggleGuestLinkMode,
  onCopyInvite,
  onShareInvite,
  onSelectGroupChat,
  onSelectCustomGroup,
  onOpenCreateGroup,
  onSelectDirectPeer,
  onCallDirectPeer,
  onViewProfile,
  onOpenOwnProfile,
  onOpenSettings,
  onOpenCreateStory,
  onOpenStoryBucket,
  onBlockUser,
  onDeleteContact,
  onOpenAdmin,
  onChangeNickname,
}: SidebarMembersProps) {
  const t = COPY[lang];
  const [sidebarTab, setSidebarTab] = useState<
    'chats' | 'contacts' | 'groups' | 'stories'
  >('chats');
  const [filterText, setFilterText] = useState('');
  const [showInvitePanel, setShowInvitePanel] = useState(false);

  const onlineIdsSet = useMemo(
    () => new Set(onlineUsers.map((u) => u.clientId)),
    [onlineUsers]
  );

  // Merge onlineUsers + persisted UserProfiles into unified contact list
  const unifiedContacts = useMemo(() => {
    const map = new Map<
      string,
      {
        clientId: string;
        nickname: string;
        username: string;
        avatarColor: string;
        avatarUrl?: string | null;
        online: boolean;
        lastSeenAt: number;
        isAdmin: boolean;
        isGuest: boolean;
        profile: UserProfile | null;
      }
    >();

    for (const p of allProfiles) {
      map.set(p.clientId, {
        clientId: p.clientId,
        nickname: p.displayName,
        username: p.username || '',
        avatarColor: p.avatarColor,
        avatarUrl: p.avatarUrl,
        online: Boolean(p.online || onlineIdsSet.has(p.clientId)),
        lastSeenAt: p.lastSeenAt,
        isAdmin: Boolean(p.isAdmin),
        isGuest: Boolean(p.isGuest),
        profile: p,
      });
    }

    for (const u of onlineUsers) {
      const existing = map.get(u.clientId);
      const prof = profilesById[u.clientId] || existing?.profile || null;
      map.set(u.clientId, {
        clientId: u.clientId,
        nickname: prof?.displayName || u.nickname,
        username: prof?.username || '',
        avatarColor: prof?.avatarColor || u.avatarColor,
        avatarUrl: prof?.avatarUrl ?? u.avatarUrl,
        online: true,
        lastSeenAt: Date.now(),
        isAdmin: u.isAdmin,
        isGuest: u.isGuest,
        profile: prof,
      });
    }

    const q = filterText.trim().toLowerCase();
    return Array.from(map.values())
      .filter((c) => !blockedPeerIds.includes(c.clientId))
      .filter(
        (c) =>
          c.clientId === currentClientId ||
          !isUserBlocked(blockedUsers, c.clientId, c.nickname)
      )
      .filter((c) => {
        if (!q) return true;
        return (
          c.nickname.toLowerCase().includes(q) ||
          c.username.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (a.clientId === currentClientId) return -1;
        if (b.clientId === currentClientId) return 1;
        if (a.online !== b.online) return a.online ? -1 : 1;
        return b.lastSeenAt - a.lastSeenAt;
      });
  }, [
    allProfiles,
    blockedPeerIds,
    blockedUsers,
    currentClientId,
    filterText,
    onlineIdsSet,
    onlineUsers,
    profilesById,
  ]);

  const filteredGroups = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    if (!q) return myGroups;
    return myGroups.filter((g) => g.name.toLowerCase().includes(q));
  }, [filterText, myGroups]);

  const ownBucket = storiesByAuthor.find((b) => b.authorId === currentClientId);

  const content = (
    <div
      className="h-full flex flex-col w-80 shrink-0"
      style={{
        backgroundColor: theme.sidebarBg,
        borderRight: `1px solid ${theme.borderColor}`,
      }}
    >
      {/* Brand header + Quick Settings / Invite toggle */}
      <div
        className="h-14 px-4 flex items-center justify-between gap-2 shrink-0"
        style={{ borderBottom: `1px solid ${theme.borderColor}` }}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0"
            style={{ backgroundColor: theme.accentBg }}
          >
            <MessageSquare className="w-4 h-4" />
          </div>
          <span
            className="font-display text-base font-bold tracking-tight truncate"
            style={{ color: theme.textPrimary }}
          >
            {t.appName}
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setShowInvitePanel((s) => !s)}
            aria-label={t.inviteTitle}
            title={t.inviteTitle}
            className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer"
            style={{
              backgroundColor: showInvitePanel ? theme.accentSoftBg : 'transparent',
              color: showInvitePanel ? theme.accentText : theme.textMuted,
            }}
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              onOpenSettings();
              onCloseMobile();
            }}
            aria-label={t.settingsTitle}
            title={t.settingsTitle}
            className="w-9 h-9 rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onCloseMobile}
            aria-label={t.close}
            className="lg:hidden min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Collapsible Invite Friends Drawer */}
      {showInvitePanel && (
        <div
          className="p-3.5 shrink-0 space-y-2.5"
          style={{
            backgroundColor: theme.surfaceBg,
            borderBottom: `1px solid ${theme.borderColor}`,
          }}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold">{t.inviteTitle}</span>
            <button
              type="button"
              onClick={() => setShowInvitePanel(false)}
              className="text-xs cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              {t.close}
            </button>
          </div>
          <div
            className="grid grid-cols-2 gap-1 p-1 rounded-xl"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
            }}
          >
            <button
              type="button"
              onClick={() => onToggleGuestLinkMode(true)}
              className="py-1 px-2 rounded-lg text-[11px] font-medium whitespace-nowrap truncate cursor-pointer"
              style={{
                backgroundColor: guestLinkMode ? theme.accentBg : 'transparent',
                color: guestLinkMode ? '#FFFFFF' : theme.textMuted,
              }}
            >
              {t.directGuestMode}
            </button>
            <button
              type="button"
              onClick={() => onToggleGuestLinkMode(false)}
              className="py-1 px-2 rounded-lg text-[11px] font-medium whitespace-nowrap truncate cursor-pointer"
              style={{
                backgroundColor: !guestLinkMode ? theme.accentBg : 'transparent',
                color: !guestLinkMode ? '#FFFFFF' : theme.textMuted,
              }}
            >
              {t.namePromptMode}
            </button>
          </div>
          <div
            className="px-2.5 py-1.5 rounded-lg text-[11px] font-mono truncate select-all"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            {inviteUrl}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onCopyInvite}
              className="flex-1 min-h-[38px] px-3 rounded-xl text-xs font-medium text-white flex items-center justify-center gap-1.5 cursor-pointer"
              style={{ backgroundColor: copied ? '#059669' : theme.accentBg }}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? t.copied : t.copyLink}</span>
            </button>
            {typeof navigator !== 'undefined' &&
              typeof navigator.share === 'function' && (
                <button
                  type="button"
                  onClick={onShareInvite}
                  aria-label={t.shareLink}
                  className="min-h-[38px] min-w-[38px] rounded-xl flex items-center justify-center cursor-pointer"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <Share2 className="w-3.5 h-3.5" />
                </button>
              )}
          </div>
        </div>
      )}

      {/* Horizontal Stories Ring Strip */}
      <div
        className="px-3 py-2.5 flex items-center gap-2.5 overflow-x-auto shrink-0"
        style={{ borderBottom: `1px solid ${theme.borderColor}` }}
      >
        <button
          type="button"
          onClick={() => {
            onOpenCreateStory();
            onCloseMobile();
          }}
          className="flex flex-col items-center gap-1 shrink-0 w-13 cursor-pointer"
        >
          <div className="relative">
            <AvatarBadge
              name={ownProfile?.displayName || currentNickname}
              avatarColor={ownProfile?.avatarColor || currentAvatarColor}
              avatarUrl={ownProfile?.avatarUrl}
              size="md"
              storyRing={ownBucket ? 'unviewed' : 'none'}
            />
            <span
              className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center"
              style={{
                backgroundColor: theme.accentBg,
                boxShadow: `0 0 0 2px ${theme.sidebarBg}`,
              }}
            >
              <Plus className="w-2.5 h-2.5" />
            </span>
          </div>
          <span
            className="text-[10px] font-medium truncate w-full text-center"
            style={{ color: theme.textSecondary }}
          >
            {t.addStory}
          </span>
        </button>

        {storiesByAuthor.map((bucket) => (
          <button
            key={bucket.authorId}
            type="button"
            onClick={() => {
              onOpenStoryBucket(bucket);
              onCloseMobile();
            }}
            className="flex flex-col items-center gap-1 shrink-0 w-13 cursor-pointer"
          >
            <AvatarBadge
              name={bucket.authorName}
              avatarColor={bucket.authorColor}
              avatarUrl={bucket.authorAvatarUrl}
              size="md"
              storyRing={bucket.hasUnviewed ? 'unviewed' : 'viewed'}
            />
            <span
              className="text-[10px] font-medium truncate w-full text-center"
              style={{ color: theme.textPrimary }}
            >
              {bucket.authorId === currentClientId ? t.myStory : bucket.authorName}
            </span>
          </button>
        ))}
      </div>

      {/* Navigation Tabs + Search */}
      <div
        className="px-3 pt-2.5 pb-2 space-y-2 shrink-0"
        style={{ borderBottom: `1px solid ${theme.borderColor}` }}
      >
        <div
          className="grid grid-cols-4 gap-1 p-1 rounded-xl"
          style={{
            backgroundColor: theme.canvasBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          {(
            [
              { id: 'chats', label: t.tabChats },
              { id: 'contacts', label: t.tabContacts },
              { id: 'groups', label: t.tabGroups },
              { id: 'stories', label: t.tabStories },
            ] as const
          ).map((tab) => {
            const active = sidebarTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSidebarTab(tab.id)}
                className="py-1.5 px-1 rounded-lg text-[11px] font-semibold truncate whitespace-nowrap cursor-pointer transition-colors"
                style={{
                  backgroundColor: active ? theme.accentBg : 'transparent',
                  color: active ? '#FFFFFF' : theme.textMuted,
                }}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div
          className="flex items-center h-9 px-3 rounded-xl gap-2"
          style={{
            backgroundColor: theme.canvasBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          <Search className="w-3.5 h-3.5 shrink-0" style={{ color: theme.textMuted }} />
          <input
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            placeholder={t.searchPlaceholder}
            aria-label={t.searchPlaceholder}
            className="flex-1 bg-transparent text-xs outline-none"
            style={{ color: theme.textPrimary }}
          />
          {filterText && (
            <button
              type="button"
              onClick={() => setFilterText('')}
              aria-label="Clear filter"
              className="cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main List Body */}
      <div className="flex-1 overflow-y-auto chat-scroll p-3 space-y-2">
        {/* CHATS TAB */}
        {sidebarTab === 'chats' && (
          <>
            {/* Main Public Lounge */}
            <button
              type="button"
              onClick={() => {
                onSelectGroupChat();
                onCloseMobile();
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between gap-2 text-xs font-semibold transition-colors cursor-pointer"
              style={{
                backgroundColor:
                  activeRoomId === 'main' && !activeDirectPeer
                    ? theme.accentSoftBg
                    : theme.surfaceBg,
                border: `1px solid ${
                  activeRoomId === 'main' && !activeDirectPeer
                    ? theme.accentBorder
                    : theme.borderColor
                }`,
                color:
                  activeRoomId === 'main' && !activeDirectPeer
                    ? theme.accentText
                    : theme.textPrimary,
              }}
            >
              <span className="flex items-center gap-2 truncate">
                <Hash className="w-4 h-4 shrink-0" />
                <span className="truncate">{t.groupChatTitle}</span>
                {mutedRoomIds.includes('main') && (
                  <VolumeX className="w-3.5 h-3.5 opacity-60 shrink-0" />
                )}
              </span>
              <span className="font-mono-nums opacity-75">{onlineUsers.length}</span>
            </button>

            {/* Custom Groups preview */}
            {filteredGroups.map((grp) => {
              const selected = activeRoomId === grp.id;
              return (
                <button
                  key={grp.id}
                  type="button"
                  onClick={() => {
                    onSelectCustomGroup(grp);
                    onCloseMobile();
                  }}
                  className="w-full px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs font-medium cursor-pointer"
                  style={{
                    backgroundColor: selected ? theme.accentSoftBg : 'transparent',
                    border: `1px solid ${
                      selected ? theme.accentBorder : 'transparent'
                    }`,
                    color: selected ? theme.accentText : theme.textPrimary,
                  }}
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <AvatarBadge
                      name={grp.name}
                      avatarColor={grp.avatarColor}
                      avatarUrl={grp.avatarUrl}
                      size="sm"
                    />
                    <span className="truncate font-semibold">{grp.name}</span>
                  </span>
                  <span
                    className="text-[11px] font-mono-nums shrink-0"
                    style={{ color: theme.textMuted }}
                  >
                    {grp.memberIds.length}
                  </span>
                </button>
              );
            })}

            {/* Recent & Online Friends */}
            <div className="px-1 pt-2 flex items-center justify-between">
              <span
                className="text-xs font-semibold"
                style={{ color: theme.textSecondary }}
              >
                {t.friendsOnline}
              </span>
              <span
                className="text-xs font-mono-nums"
                style={{ color: theme.textMuted }}
              >
                {onlineUsers.length} {t.onlineNow}
              </span>
            </div>

            <ul className="space-y-1">
              {unifiedContacts
                .filter((c) => c.clientId !== currentClientId)
                .map((c) => {
                  const isSelectedDm = activeDirectPeer?.clientId === c.clientId;
                  const unreadCount = unreadByPeerId[c.clientId] || 0;
                  const canSeePhoto = c.profile
                    ? canViewProfileField(
                        c.profile.privacy?.profilePhoto,
                        c.clientId,
                        currentClientId,
                        false,
                        true
                      )
                    : true;
                  const canSeeLastSeen = c.profile
                    ? canViewProfileField(
                        c.profile.privacy?.lastSeen,
                        c.clientId,
                        currentClientId,
                        false,
                        true
                      )
                    : true;

                  return (
                    <li
                      key={c.clientId}
                      className="px-2 py-2 rounded-xl flex items-center justify-between gap-2"
                      style={{
                        backgroundColor: isSelectedDm
                          ? theme.accentSoftBg
                          : 'transparent',
                        border: isSelectedDm
                          ? `1px solid ${theme.accentBorder}`
                          : '1px solid transparent',
                      }}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectDirectPeer(c);
                          onCloseMobile();
                        }}
                        className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
                      >
                        <AvatarBadge
                          name={c.nickname}
                          avatarColor={c.avatarColor}
                          avatarUrl={c.avatarUrl}
                          canViewPhoto={canSeePhoto}
                          online={c.online && canSeeLastSeen}
                          size="sm"
                          dotBorderColor={theme.sidebarBg}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1">
                            <span
                              className="text-sm font-medium truncate"
                              style={{ color: theme.textPrimary }}
                            >
                              {c.nickname}
                            </span>
                            {c.isAdmin && (
                              <span
                                className="text-[10px] font-semibold shrink-0"
                                style={{ color: theme.accentText }}
                              >
                                · {t.adminBadge}
                              </span>
                            )}
                          </div>
                          <div
                            className="text-[11px] truncate"
                            style={{ color: theme.textMuted }}
                          >
                            {formatLastSeen(
                              c.lastSeenAt,
                              c.online,
                              canSeeLastSeen,
                              Date.now(),
                              lang
                            )}
                          </div>
                        </div>
                      </button>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            onSelectDirectPeer(c);
                            onCloseMobile();
                          }}
                          aria-label={`${t.messageFriend} ${c.nickname}`}
                          className="relative w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer"
                          style={{
                            backgroundColor: isSelectedDm
                              ? theme.accentBg
                              : theme.surfaceBg,
                            border: `1px solid ${
                              isSelectedDm ? theme.accentBg : theme.borderColor
                            }`,
                            color: isSelectedDm ? '#FFFFFF' : theme.textSecondary,
                          }}
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          {unreadCount > 0 && (
                            <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-emerald-500 text-[10px] font-bold text-white flex items-center justify-center">
                              {unreadCount}
                            </span>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onCallDirectPeer(c, 'video');
                            onCloseMobile();
                          }}
                          aria-label={`${t.callFriend} ${c.nickname}`}
                          className="w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer"
                          style={{
                            backgroundColor: 'rgba(16, 185, 129, 0.14)',
                            border: '1px solid rgba(52, 211, 153, 0.35)',
                            color: '#34D399',
                          }}
                        >
                          <Video className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </li>
                  );
                })}
            </ul>
          </>
        )}

        {/* CONTACTS TAB */}
        {sidebarTab === 'contacts' && (
          <ul className="space-y-1.5">
            {unifiedContacts
              .filter((c) => c.clientId !== currentClientId)
              .map((c) => {
                const canSeePhoto = c.profile
                  ? canViewProfileField(
                      c.profile.privacy?.profilePhoto,
                      c.clientId,
                      currentClientId,
                      false,
                      true
                    )
                  : true;
                const canSeeLastSeen = c.profile
                  ? canViewProfileField(
                      c.profile.privacy?.lastSeen,
                      c.clientId,
                      currentClientId,
                      false,
                      true
                    )
                  : true;
                return (
                  <li
                    key={c.clientId}
                    className="p-2.5 rounded-xl flex items-center justify-between gap-2"
                    style={{
                      backgroundColor: theme.surfaceBg,
                      border: `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        if (c.profile) onViewProfile(c.profile);
                        onCloseMobile();
                      }}
                      className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
                    >
                      <AvatarBadge
                        name={c.nickname}
                        avatarColor={c.avatarColor}
                        avatarUrl={c.avatarUrl}
                        canViewPhoto={canSeePhoto}
                        online={c.online && canSeeLastSeen}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{c.nickname}</p>
                        <p className="text-[11px] truncate" style={{ color: theme.textMuted }}>
                          {c.username ? `@${c.username} · ` : ''}
                          {formatLastSeen(
                            c.lastSeenAt,
                            c.online,
                            canSeeLastSeen,
                            Date.now(),
                            lang
                          )}
                        </p>
                      </div>
                    </button>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          onCallDirectPeer(c, 'audio');
                          onCloseMobile();
                        }}
                        aria-label={`${t.audioCallFriend} ${c.nickname}`}
                        className="w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer"
                        style={{
                          backgroundColor: theme.canvasBg,
                          color: theme.textSecondary,
                        }}
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onCallDirectPeer(c, 'video');
                          onCloseMobile();
                        }}
                        aria-label={`${t.callFriend} ${c.nickname}`}
                        className="w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer"
                        style={{
                          backgroundColor: 'rgba(16, 185, 129, 0.14)',
                          color: '#34D399',
                        }}
                      >
                        <Video className="w-3.5 h-3.5" />
                      </button>
                      {isAdmin && c.clientId !== currentClientId && (
                        <>
                          {!c.isAdmin && !c.profile?.isAdmin && (
                            <button
                              type="button"
                              onClick={() =>
                                onBlockUser({
                                  clientId: c.clientId,
                                  nickname: c.nickname,
                                  avatarColor: c.avatarColor,
                                  isAdmin: c.isAdmin,
                                  isGuest: c.isGuest,
                                  connectedAt: c.lastSeenAt,
                                })
                              }
                              aria-label={`${t.blockUser} ${c.nickname}`}
                              title={t.blockUser}
                              className="w-8 h-8 rounded-lg text-amber-400 hover:bg-amber-500/15 flex items-center justify-center cursor-pointer"
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            data-testid="delete-contact-btn"
                            onClick={() =>
                              onDeleteContact({
                                clientId: c.clientId,
                                nickname: c.nickname,
                              })
                            }
                            aria-label={`${t.deleteContact} ${c.nickname}`}
                            title={t.deleteContact}
                            className="w-8 h-8 rounded-lg text-red-400 hover:bg-red-500/15 flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </li>
                );
              })}
          </ul>
        )}

        {/* GROUPS TAB */}
        {sidebarTab === 'groups' && (
          <div className="space-y-2.5">
            {isAdmin || allowGroupCreation ? (
              <button
                type="button"
                onClick={() => {
                  onOpenCreateGroup();
                  onCloseMobile();
                }}
                data-testid="new-group-btn"
                className="w-full min-h-[42px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: theme.accentBg }}
              >
                <Plus className="w-4 h-4" />
                <span>{t.createGroup}</span>
              </button>
            ) : (
              <p
                className="text-xs px-3 py-2 rounded-xl text-center"
                style={{
                  backgroundColor: theme.surfaceBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textMuted,
                }}
              >
                {t.groupsDisabledNotice}
              </p>
            )}

            <button
              type="button"
              onClick={() => {
                onSelectGroupChat();
                onCloseMobile();
              }}
              className="w-full p-3 rounded-xl flex items-center justify-between gap-2 text-left cursor-pointer"
              style={{
                backgroundColor:
                  activeRoomId === 'main' ? theme.accentSoftBg : theme.surfaceBg,
                border: `1px solid ${
                  activeRoomId === 'main' ? theme.accentBorder : theme.borderColor
                }`,
              }}
            >
              <span className="flex items-center gap-2.5">
                <Hash className="w-4 h-4" style={{ color: theme.accentText }} />
                <span className="text-sm font-semibold">{t.groupChatTitle}</span>
              </span>
              <span className="text-xs font-mono-nums" style={{ color: theme.textMuted }}>
                {onlineUsers.length}
              </span>
            </button>

            {filteredGroups.length === 0 ? (
              <p className="text-xs text-center py-4" style={{ color: theme.textMuted }}>
                {t.noGroupsYet}
              </p>
            ) : (
              filteredGroups.map((grp) => (
                <button
                  key={grp.id}
                  type="button"
                  onClick={() => {
                    onSelectCustomGroup(grp);
                    onCloseMobile();
                  }}
                  className="w-full p-3 rounded-xl flex items-center justify-between gap-2 text-left cursor-pointer"
                  style={{
                    backgroundColor:
                      activeRoomId === grp.id ? theme.accentSoftBg : theme.surfaceBg,
                    border: `1px solid ${
                      activeRoomId === grp.id ? theme.accentBorder : theme.borderColor
                    }`,
                  }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <AvatarBadge
                      name={grp.name}
                      avatarColor={grp.avatarColor}
                      avatarUrl={grp.avatarUrl}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{grp.name}</p>
                      <p className="text-[11px] truncate" style={{ color: theme.textMuted }}>
                        {grp.memberIds.length} {t.groupMembersLabel}
                      </p>
                    </div>
                  </div>
                  <Users className="w-4 h-4 shrink-0" style={{ color: theme.textMuted }} />
                </button>
              ))
            )}
          </div>
        )}

        {/* STORIES TAB */}
        {sidebarTab === 'stories' && (
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={() => {
                onOpenCreateStory();
                onCloseMobile();
              }}
              className="w-full min-h-[42px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer"
              style={{ backgroundColor: theme.accentBg }}
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.addStory}</span>
            </button>

            {storiesByAuthor.length === 0 ? (
              <p className="text-xs text-center py-6" style={{ color: theme.textMuted }}>
                No active stories in the last 24 hours.
              </p>
            ) : (
              storiesByAuthor.map((bucket) => (
                <button
                  key={bucket.authorId}
                  type="button"
                  onClick={() => {
                    onOpenStoryBucket(bucket);
                    onCloseMobile();
                  }}
                  className="w-full p-2.5 rounded-xl flex items-center justify-between gap-2.5 text-left cursor-pointer"
                  style={{
                    backgroundColor: theme.surfaceBg,
                    border: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <AvatarBadge
                      name={bucket.authorName}
                      avatarColor={bucket.authorColor}
                      avatarUrl={bucket.authorAvatarUrl}
                      size="sm"
                      storyRing={bucket.hasUnviewed ? 'unviewed' : 'viewed'}
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">
                        {bucket.authorId === currentClientId
                          ? t.myStory
                          : bucket.authorName}
                      </p>
                      <p className="text-[11px]" style={{ color: theme.textMuted }}>
                        {bucket.stories.length} updates
                      </p>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        )}
      </div>

      {/* Bottom Profile Card + Host + Switch User */}
      <div
        className="p-3 space-y-2 shrink-0"
        style={{ borderTop: `1px solid ${theme.borderColor}` }}
      >
        <button
          type="button"
          onClick={() => {
            onOpenOwnProfile();
            onCloseMobile();
          }}
          data-testid="edit-own-profile-btn"
          className="w-full px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-left cursor-pointer"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <AvatarBadge
              name={ownProfile?.displayName || currentNickname}
              avatarColor={ownProfile?.avatarColor || currentAvatarColor}
              avatarUrl={ownProfile?.avatarUrl}
              online={true}
              size="sm"
              dotBorderColor={theme.surfaceBg}
            />
            <div className="min-w-0">
              <p className="text-xs font-bold truncate" style={{ color: theme.textPrimary }}>
                {ownProfile?.displayName || currentNickname}
              </p>
              <p className="text-[11px] truncate" style={{ color: theme.textMuted }}>
                {ownProfile?.username
                  ? `@${ownProfile.username}`
                  : t.editProfile}
              </p>
            </div>
          </div>
          <Edit3 className="w-3.5 h-3.5 shrink-0" style={{ color: theme.accentText }} />
        </button>

        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => {
              onOpenAdmin();
              onCloseMobile();
            }}
            className="min-h-[40px] px-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              backgroundColor: isAdmin ? theme.accentSoftBg : theme.surfaceBg,
              border: `1px solid ${
                isAdmin ? theme.accentBorder : theme.borderColor
              }`,
              color: isAdmin ? theme.accentText : theme.textPrimary,
            }}
          >
            {isAdmin ? (
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            ) : (
              <Shield className="w-3.5 h-3.5 shrink-0" />
            )}
            <span className="truncate">
              {isAdmin ? t.adminBadge : t.adminControls}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              onChangeNickname();
              onCloseMobile();
            }}
            className="min-h-[40px] px-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textMuted,
            }}
          >
            <span>{t.leaveRoom}</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block h-full shrink-0">{content}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 h-full max-w-[85vw]">{content}</div>
        </div>
      )}
    </>
  );
}
