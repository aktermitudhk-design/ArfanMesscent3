import React, { useEffect, useRef, useState } from 'react';
import {
  Ban,
  BarChart2,
  Check,
  Clock,
  Copy,
  Download,
  ExternalLink,
  Eye,
  FileDown,
  Flag,
  Globe,
  Hash,
  ImagePlus,
  KeyRound,
  Lock,
  LogOut,
  Megaphone,
  MessageSquare,
  Palette,
  Phone,
  PhoneOff,
  RefreshCw,
  RotateCcw,
  Search,
  Shield,
  ShieldCheck,
  Trash2,
  Unlock,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  THEME_SPECS,
  WALLPAPER_PRESETS,
  formatBdPhoneDisplay,
  formatTime,
  getInitials,
  isSelfOrHostTarget,
  isUserBlocked,
  normalizeNicknameKey,
} from '../shared/chatRules';
import type {
  BlockedUser,
  ChatGroup,
  DeletedContact,
  DmThreadSummary,
  OnlineUser,
  RegisteredUser,
  ThemeId,
  ThemeSpec,
  UserProfile,
  UserReport,
} from '../shared/types';
import { downloadVerifiedFile } from '../utils/downloadHelper';
import { COPY, type Lang } from '../utils/i18n';

const SLOW_MODE_OPTIONS = [0, 3, 10, 30] as const;

export interface HostInspectTarget {
  roomId: string;
  title: string;
  kind: 'main' | 'group' | 'dm';
}

interface AdminPanelModalProps {
  open: boolean;
  isAdmin: boolean;
  currentClientId: string;
  selfNickname: string | null;
  selfPhoneNumber: string | null;
  profilesById: Record<string, UserProfile>;
  authError: string | null;
  currentThemeId: ThemeId;
  backgroundImageUrl: string | null;
  roomLocked: boolean;
  roomTitle: string;
  slowModeSec: number;
  guestAllowed: boolean;
  announcement: string;
  allowMedia: boolean;
  allowVoice: boolean;
  allowPolls: boolean;
  allowGroupCreation: boolean;
  disappearingHours: 0 | 24 | 168;
  messageCount: number;
  onlineCount: number;
  guestCount: number;
  storyCount: number;
  onlineUsers: OnlineUser[];
  registeredUsers: RegisteredUser[];
  deletedContacts: DeletedContact[];
  allProfiles: UserProfile[];
  blockedUsers: BlockedUser[];
  reports: UserReport[];
  allGroups: ChatGroup[];
  allDmThreads: DmThreadSummary[];
  scanningDmThreads?: boolean;
  theme: ThemeSpec;
  lang: Lang;
  onClose: () => void;
  onLogin: (password: string) => Promise<boolean>;
  onLogout: () => void;
  onSelectTheme: (themeId: ThemeId) => void;
  onSelectBackgroundPreset: (presetUrl: string | null) => Promise<void>;
  onUploadBackground: (
    file: File,
    onProgress?: (percent: number) => void
  ) => Promise<{ usedFallback: boolean }>;
  onClearBackground: () => Promise<void>;
  onToggleLock: (locked: boolean) => void;
  onUpdateRoomSettings: (settings: {
    roomTitle?: string;
    slowModeSec?: number;
    guestAllowed?: boolean;
    announcement?: string;
    allowMedia?: boolean;
    allowVoice?: boolean;
    allowPolls?: boolean;
    allowGroupCreation?: boolean;
    disappearingHours?: 0 | 24 | 168;
  }) => void;
  onClearChat: () => void;
  onClearRoomCalls?: () => Promise<void>;
  onExportChat?: () => void;
  onScanAllDmThreads?: () => Promise<void>;
  onBlockUser: (target: {
    nickname: string;
    clientId?: string;
    phoneNumber?: string;
  }) => void;
  onUnblock: (
    target:
      | string
      | { nickname?: string; clientId?: string; phoneNumber?: string }
  ) => void;
  onDeleteContact: (target: {
    clientId: string;
    nickname?: string;
    phoneNumber?: string;
  }) => void;
  onRestoreDeletedContact: (entry: DeletedContact) => Promise<boolean>;
  onResolveReport: (reportId: string) => Promise<void>;
  onDeleteReportedMessage: (messageId: string, roomId?: string) => Promise<void>;
  onDeleteGroup: (group: ChatGroup) => Promise<void>;
  onInspectRoom: (target: HostInspectTarget) => void;
}

export function AdminPanelModal({
  open,
  isAdmin,
  currentClientId,
  selfNickname,
  selfPhoneNumber,
  profilesById,
  authError,
  currentThemeId,
  backgroundImageUrl,
  roomLocked,
  roomTitle,
  slowModeSec,
  guestAllowed,
  announcement,
  allowMedia,
  allowVoice,
  allowPolls,
  allowGroupCreation,
  disappearingHours,
  messageCount,
  onlineCount,
  guestCount,
  storyCount,
  onlineUsers,
  registeredUsers,
  deletedContacts,
  allProfiles,
  blockedUsers,
  reports,
  allGroups,
  allDmThreads,
  scanningDmThreads = false,
  theme,
  lang,
  onClose,
  onLogin,
  onLogout,
  onSelectTheme,
  onSelectBackgroundPreset,
  onUploadBackground,
  onClearBackground,
  onToggleLock,
  onUpdateRoomSettings,
  onClearChat,
  onClearRoomCalls,
  onExportChat,
  onScanAllDmThreads,
  onBlockUser,
  onUnblock,
  onDeleteContact,
  onRestoreDeletedContact,
  onResolveReport,
  onDeleteReportedMessage,
  onDeleteGroup,
  onInspectRoom,
}: AdminPanelModalProps) {
  const [adminTab, setAdminTab] = useState<
    'controls' | 'chats' | 'reports' | 'groups' | 'phones'
  >('controls');
  const [passwordDraft, setPasswordDraft] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);
  const [titleDraft, setTitleDraft] = useState(roomTitle);
  const [announcementDraft, setAnnouncementDraft] = useState(announcement);
  const [blockNickDraft, setBlockNickDraft] = useState('');
  const [quickBlockError, setQuickBlockError] = useState<string | null>(null);
  const [phoneSearch, setPhoneSearch] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [bgUploading, setBgUploading] = useState(false);
  const [bgProgress, setBgProgress] = useState(0);
  const [bgError, setBgError] = useState<string | null>(null);
  const [copiedPublicUrl, setCopiedPublicUrl] = useState(false);
  const [downloadingKey, setDownloadingKey] = useState<'zip' | 'html' | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const bgFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTitleDraft(roomTitle);
  }, [roomTitle]);

  useEffect(() => {
    setAnnouncementDraft(announcement);
  }, [announcement]);

  useEffect(() => {
    if (open && isAdmin && adminTab === 'chats') {
      void onScanAllDmThreads?.();
    }
  }, [adminTab, isAdmin, onScanAllDmThreads, open]);

  if (!open) return null;

  const hostUsersForCheck = [
    ...onlineUsers,
    ...Object.values(profilesById).map((p) => ({
      clientId: p.clientId,
      displayName: p.displayName,
      isAdmin: Boolean(p.isAdmin),
    })),
  ];

  const isProtectedHost = (target: {
    clientId?: string;
    nickname?: string;
    phoneNumber?: string;
  }) =>
    isSelfOrHostTarget({
      targetClientId: target.clientId,
      targetNickname: target.nickname,
      targetPhoneNumber: target.phoneNumber,
      selfClientId: currentClientId,
      selfNickname,
      selfPhoneNumber,
      hostUsers: hostUsersForCheck,
    });

  const publicLiveUrl =
    'https://ais-pre-ninkkcapv3lnbh7ktm5ame-417594258398.asia-southeast1.run.app';

  const handleCopyPublicUrl = async () => {
    try {
      await navigator.clipboard.writeText(publicLiveUrl);
      setCopiedPublicUrl(true);
      window.setTimeout(() => setCopiedPublicUrl(false), 2000);
    } catch {
      // Fallback ignored
    }
  };

  const handleBackgroundFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setBgError(null);
    setBgUploading(true);
    setBgProgress(10);
    try {
      await onUploadBackground(file, setBgProgress);
    } catch (err) {
      setBgError(
        err instanceof Error
          ? err.message
          : 'Could not upload background image.'
      );
    } finally {
      setBgUploading(false);
      setBgProgress(0);
    }
  };

  const onlineIds = new Set(onlineUsers.map((u) => u.clientId));
  const filteredRegistered = registeredUsers.filter((reg) => {
    const q = phoneSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      reg.nickname.toLowerCase().includes(q) ||
      reg.phoneNumber.includes(q.replace(/[\s\-+]/g, ''))
    );
  });

  const openReportCount = reports.filter((r) => r.status === 'open').length;
  const t = COPY[lang];

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loggingIn) return;
    setLoggingIn(true);
    try {
      const ok = await onLogin(passwordDraft);
      if (ok) {
        setPasswordDraft('');
      }
    } finally {
      setLoggingIn(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t.adminControls}
    >
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full sm:max-w-xl max-h-[90dvh] overflow-y-auto chat-scroll rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl"
        style={{
          backgroundColor: theme.surfaceBg,
          border: `1px solid ${theme.borderColor}`,
          color: theme.textPrimary,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{
                backgroundColor: theme.accentSoftBg,
                color: theme.accentText,
              }}
            >
              {isAdmin ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <Shield className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="font-display text-base font-bold">
                {isAdmin ? t.adminActive : t.adminUnlock}
              </h2>
              {isAdmin && (
                <p
                  className="text-xs font-mono-nums"
                  style={{ color: theme.textMuted }}
                >
                  {onlineCount} online · {guestCount} guests · {messageCount} msgs
                </p>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isAdmin ? (
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <p className="text-sm leading-relaxed" style={{ color: theme.textSecondary }}>
              {t.adminOwnerNote}
            </p>

            <div>
              <label
                htmlFor="host-password-input"
                className="block text-xs font-semibold mb-1.5"
                style={{ color: theme.textSecondary }}
              >
                {t.adminPasswordLabel}
              </label>
              <input
                id="host-password-input"
                type="password"
                autoFocus
                value={passwordDraft}
                onChange={(e) => setPasswordDraft(e.target.value)}
                placeholder={t.adminPasswordPlaceholder}
                className="w-full h-12 px-3.5 rounded-xl text-sm outline-none"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${authError ? '#EF4444' : theme.borderColor}`,
                  color: theme.textPrimary,
                }}
              />
            </div>

            {authError && (
              <p className="text-xs text-red-400" role="alert">
                {authError === 'wrongPassword' ? t.wrongPassword : authError}
              </p>
            )}

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full h-12 rounded-xl text-sm font-semibold text-white flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              style={{ backgroundColor: theme.accentBg }}
            >
              <KeyRound className="w-4 h-4" />
              <span>{loggingIn ? t.loadingOlder : t.unlockButton}</span>
            </button>
          </form>
        ) : (
          <div className="space-y-5">
            {/* Admin Tab Bar */}
            <div
              className="grid grid-cols-5 gap-1 p-1 rounded-xl"
              style={{
                backgroundColor: theme.canvasBg,
                border: `1px solid ${theme.borderColor}`,
              }}
            >
              {(
                [
                  { id: 'controls', label: 'Controls' },
                  {
                    id: 'chats',
                    label: `${t.hostOversightTab} (${allDmThreads.length})`,
                  },
                  {
                    id: 'reports',
                    label:
                      openReportCount > 0
                        ? `Reports (${openReportCount})`
                        : 'Reports',
                  },
                  { id: 'groups', label: `Groups (${allGroups.length})` },
                  { id: 'phones', label: `Phones (${registeredUsers.length})` },
                ] as const
              ).map((tab) => {
                const active = adminTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    data-testid={`admin-tab-${tab.id}`}
                    onClick={() => setAdminTab(tab.id)}
                    className="py-2 px-1 rounded-lg text-[11px] font-semibold truncate whitespace-nowrap cursor-pointer"
                    style={{
                      backgroundColor: active ? theme.accentBg : 'transparent',
                      color: active ? '#FFFFFF' : theme.textMuted,
                    }}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* TAB 1: Controls */}
            {adminTab === 'controls' && (
              <div className="space-y-6">
                <section>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <Palette
                        className="w-4 h-4"
                        style={{ color: theme.accentText }}
                      />
                      <h3 className="text-sm font-semibold">{t.themesTitle}</h3>
                    </div>
                    <span
                      className="text-[11px] font-mono-nums"
                      style={{ color: theme.textMuted }}
                    >
                      {Object.keys(THEME_SPECS).length}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto chat-scroll pr-1">
                    {Object.values(THEME_SPECS).map((spec) => {
                      const selected = spec.id === currentThemeId;
                      return (
                        <button
                          key={spec.id}
                          type="button"
                          data-testid={`admin-theme-${spec.id}`}
                          onClick={() => onSelectTheme(spec.id)}
                          className="min-h-[46px] px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-left transition-colors cursor-pointer"
                          style={{
                            backgroundColor: selected
                              ? theme.accentSoftBg
                              : theme.canvasBg,
                            border: `1px solid ${
                              selected ? theme.accentBorder : theme.borderColor
                            }`,
                          }}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span
                              className="w-6 h-6 rounded-lg shrink-0 flex items-center justify-center"
                              style={{
                                backgroundColor: spec.swatchPrimary,
                                border: `2px solid ${spec.swatchSecondary}`,
                              }}
                            >
                              <span
                                className="w-2.5 h-2.5 rounded-full"
                                style={{ backgroundColor: spec.swatchSecondary }}
                              />
                            </span>
                            <span className="text-xs font-medium truncate">
                              {lang === 'bn' ? spec.nameBn : spec.name}
                            </span>
                          </div>
                          {selected && (
                            <Check
                              className="w-4 h-4 shrink-0"
                              style={{ color: theme.accentText }}
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Custom Chat Background + 20 Background Designs */}
                  <div
                    className="mt-4 pt-4 space-y-2.5"
                    style={{ borderTop: `1px solid ${theme.borderColor}` }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <ImagePlus
                          className="w-4 h-4"
                          style={{ color: theme.accentText }}
                        />
                        <span className="text-xs font-semibold">
                          {t.roomBackgroundTitle} · {t.wallpapersGalleryTitle}
                        </span>
                      </div>
                      {backgroundImageUrl && (
                        <span
                          className="text-[11px]"
                          style={{ color: theme.accentText }}
                        >
                          {t.backgroundActiveHint}
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-48 overflow-y-auto chat-scroll pr-1">
                      {WALLPAPER_PRESETS.map((wp) => {
                        const active = backgroundImageUrl === wp.url;
                        return (
                          <button
                            key={wp.id}
                            type="button"
                            data-testid={`admin-wallpaper-${wp.id}`}
                            onClick={() =>
                              void onSelectBackgroundPreset(
                                active ? null : wp.url
                              )
                            }
                            title={lang === 'bn' ? wp.nameBn : wp.name}
                            className="h-12 rounded-xl overflow-hidden relative flex items-end p-1 cursor-pointer"
                            style={{
                              backgroundImage: `url("${wp.url}")`,
                              backgroundSize: 'cover',
                              backgroundPosition: 'center',
                              border: active
                                ? `2px solid ${theme.accentText}`
                                : `1px solid ${theme.borderColor}`,
                            }}
                          >
                            <span className="text-[9px] font-semibold px-1 py-0.5 rounded bg-black/60 text-white truncate w-full text-center">
                              {lang === 'bn' ? wp.nameBn : wp.name}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    {backgroundImageUrl && (
                      <div
                        className="relative rounded-xl overflow-hidden h-20 w-full"
                        style={{ border: `1px solid ${theme.borderColor}` }}
                      >
                        <img
                          src={backgroundImageUrl}
                          alt={t.roomBackgroundTitle}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    <input
                      ref={bgFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleBackgroundFileChange}
                      aria-label={t.uploadBackground}
                      data-testid="bg-upload-input"
                      className="hidden"
                    />

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={bgUploading}
                        onClick={() => bgFileInputRef.current?.click()}
                        className="flex-1 min-h-[40px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                        style={{ backgroundColor: theme.accentBg }}
                      >
                        <ImagePlus className="w-4 h-4" />
                        <span>
                          {bgUploading
                            ? `${t.uploadingBackground} ${bgProgress}%`
                            : backgroundImageUrl
                              ? t.changeBackground
                              : t.uploadBackground}
                        </span>
                      </button>

                      {backgroundImageUrl && (
                        <button
                          type="button"
                          disabled={bgUploading}
                          onClick={() => void onClearBackground()}
                          className="min-h-[40px] px-3 rounded-xl text-xs font-semibold text-red-400 bg-red-500/15 hover:bg-red-500/25 flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t.removeBackground}</span>
                        </button>
                      )}
                    </div>

                    {bgError && (
                      <p className="text-xs text-red-400" role="alert">
                        {bgError}
                      </p>
                    )}
                  </div>
                </section>

                {/* Moderation & Broadcast */}
                <section
                  className="pt-5 space-y-3"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <h3 className="text-sm font-semibold">{t.moderationTitle}</h3>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={titleDraft}
                      onChange={(e) => setTitleDraft(e.target.value)}
                      maxLength={40}
                      aria-label={t.roomTitleLabel}
                      className="flex-1 h-10 px-3 rounded-xl text-sm outline-none"
                      style={{
                        backgroundColor: theme.canvasBg,
                        border: `1px solid ${theme.borderColor}`,
                        color: theme.textPrimary,
                      }}
                    />
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateRoomSettings({ roomTitle: titleDraft })
                      }
                      className="h-10 px-3.5 rounded-xl text-xs font-medium text-white whitespace-nowrap cursor-pointer"
                      style={{ backgroundColor: theme.accentBg }}
                    >
                      {t.saveRoomTitle}
                    </button>
                  </div>

                  {/* Live Broadcast Announcement */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="host-broadcast-input"
                      className="text-xs font-medium flex items-center gap-1.5"
                      style={{ color: theme.textSecondary }}
                    >
                      <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t.hostBroadcastTitle}</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        id="host-broadcast-input"
                        data-testid="host-broadcast-input"
                        type="text"
                        value={announcementDraft}
                        onChange={(e) => setAnnouncementDraft(e.target.value)}
                        maxLength={280}
                        placeholder={t.hostBroadcastPlaceholder}
                        className="flex-1 h-10 px-3 rounded-xl text-xs outline-none"
                        style={{
                          backgroundColor: theme.canvasBg,
                          border: `1px solid ${theme.borderColor}`,
                          color: theme.textPrimary,
                        }}
                      />
                      <button
                        type="button"
                        data-testid="host-broadcast-submit"
                        onClick={() =>
                          onUpdateRoomSettings({
                            announcement: announcementDraft,
                          })
                        }
                        className="h-10 px-3 rounded-xl text-xs font-medium text-white cursor-pointer"
                        style={{ backgroundColor: theme.accentBg }}
                      >
                        {t.updateBroadcastBtn}
                      </button>
                      {announcement && (
                        <button
                          type="button"
                          onClick={() => {
                            setAnnouncementDraft('');
                            onUpdateRoomSettings({ announcement: '' });
                          }}
                          className="h-10 px-2.5 rounded-xl text-xs font-medium text-red-400 bg-red-500/15 cursor-pointer"
                        >
                          {t.clearBroadcastBtn}
                        </button>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateRoomSettings({ guestAllowed: !guestAllowed })
                    }
                    className="w-full min-h-[42px] px-3.5 rounded-xl text-xs font-medium flex items-center justify-between cursor-pointer"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                      color: theme.textPrimary,
                    }}
                  >
                    <span className="flex items-center gap-2">
                      <UserPlus
                        className="w-4 h-4"
                        style={{ color: theme.accentText }}
                      />
                      <span>{t.guestAccessLabel}</span>
                    </span>
                    <span
                      className="font-mono-nums font-semibold"
                      style={{ color: guestAllowed ? '#34D399' : '#FBBF24' }}
                    >
                      {guestAllowed ? 'ON' : 'OFF'}
                    </span>
                  </button>

                  <div>
                    <div
                      className="text-xs font-medium mb-1.5 flex items-center gap-1.5"
                      style={{ color: theme.textSecondary }}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>{t.slowModeLabel}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {SLOW_MODE_OPTIONS.map((sec) => {
                        const active = slowModeSec === sec;
                        return (
                          <button
                            key={sec}
                            type="button"
                            onClick={() =>
                              onUpdateRoomSettings({ slowModeSec: sec })
                            }
                            className="h-9 rounded-xl text-xs font-mono-nums font-medium cursor-pointer"
                            style={{
                              backgroundColor: active
                                ? theme.accentBg
                                : theme.canvasBg,
                              border: `1px solid ${
                                active ? theme.accentBg : theme.borderColor
                              }`,
                              color: active ? '#FFFFFF' : theme.textSecondary,
                            }}
                          >
                            {sec === 0 ? 'Off' : `${sec}s`}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* WhatsApp & Messenger Host Controls */}
                  <div
                    className="pt-3 space-y-2"
                    style={{ borderTop: `1px solid ${theme.borderColor}` }}
                  >
                    <h4
                      className="text-xs font-semibold"
                      style={{ color: theme.textSecondary }}
                    >
                      {t.hostPermissionsTitle}
                    </h4>

                    {(
                      [
                        {
                          key: 'allowMedia',
                          label: t.allowMediaLabel,
                          val: allowMedia,
                        },
                        {
                          key: 'allowVoice',
                          label: t.allowVoiceLabel,
                          val: allowVoice,
                        },
                        {
                          key: 'allowPolls',
                          label: t.allowPollsLabel,
                          val: allowPolls,
                        },
                        {
                          key: 'allowGroupCreation',
                          label: t.allowGroupsLabel,
                          val: allowGroupCreation,
                        },
                      ] as const
                    ).map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() =>
                          onUpdateRoomSettings({ [item.key]: !item.val })
                        }
                        className="w-full min-h-[38px] px-3 rounded-xl text-xs font-medium flex items-center justify-between cursor-pointer"
                        style={{
                          backgroundColor: theme.canvasBg,
                          border: `1px solid ${theme.borderColor}`,
                        }}
                      >
                        <span>{item.label}</span>
                        <span
                          className="font-mono-nums font-semibold"
                          style={{ color: item.val ? '#34D399' : '#F87171' }}
                        >
                          {item.val ? 'ON' : 'OFF'}
                        </span>
                      </button>
                    ))}

                    <div className="pt-1">
                      <span
                        className="text-xs font-medium block mb-1.5"
                        style={{ color: theme.textSecondary }}
                      >
                        {t.disappearingLabel}
                      </span>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(
                          [
                            { hours: 0, label: t.disappearingOff },
                            { hours: 24, label: t.disappearing24h },
                            { hours: 168, label: t.disappearing7d },
                          ] as const
                        ).map((opt) => {
                          const active = disappearingHours === opt.hours;
                          return (
                            <button
                              key={opt.hours}
                              type="button"
                              data-testid={`disappearing-${opt.hours}`}
                              onClick={() =>
                                onUpdateRoomSettings({
                                  disappearingHours: opt.hours,
                                })
                              }
                              className="h-9 rounded-xl text-xs font-medium cursor-pointer"
                              style={{
                                backgroundColor: active
                                  ? theme.accentBg
                                  : theme.canvasBg,
                                border: `1px solid ${
                                  active ? theme.accentBg : theme.borderColor
                                }`,
                                color: active ? '#FFFFFF' : theme.textSecondary,
                              }}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      {onClearRoomCalls && (
                        <button
                          type="button"
                          onClick={() => void onClearRoomCalls()}
                          className="min-h-[40px] px-3 rounded-xl text-xs font-medium text-amber-400 flex items-center justify-center gap-1.5 cursor-pointer"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: '1px solid rgba(251, 191, 36, 0.3)',
                          }}
                        >
                          <PhoneOff className="w-3.5 h-3.5" />
                          <span>{t.endAllCallsBtn}</span>
                        </button>
                      )}
                      {onExportChat && (
                        <button
                          type="button"
                          data-testid="export-chat-btn"
                          onClick={onExportChat}
                          className="min-h-[40px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: `1px solid ${theme.borderColor}`,
                            color: theme.accentText,
                          }}
                        >
                          <FileDown className="w-3.5 h-3.5" />
                          <span>{t.exportChatBtn}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onToggleLock(!roomLocked)}
                      className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-2 cursor-pointer"
                      style={{
                        backgroundColor: roomLocked
                          ? 'rgba(245, 158, 11, 0.16)'
                          : theme.canvasBg,
                        border: `1px solid ${
                          roomLocked
                            ? 'rgba(251, 191, 36, 0.35)'
                            : theme.borderColor
                        }`,
                        color: roomLocked ? '#FBBF24' : theme.textPrimary,
                      }}
                    >
                      {roomLocked ? (
                        <Unlock className="w-4 h-4" />
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                      <span>{roomLocked ? t.unlockRoom : t.lockRoom}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (!confirmClear) {
                          setConfirmClear(true);
                          return;
                        }
                        onClearChat();
                        setConfirmClear(false);
                      }}
                      className="min-h-[42px] px-3 rounded-xl text-xs font-medium text-red-400 flex items-center justify-center gap-2 cursor-pointer"
                      style={{
                        backgroundColor: confirmClear
                          ? 'rgba(239, 68, 68, 0.2)'
                          : theme.canvasBg,
                        border: `1px solid rgba(239, 68, 68, 0.3)`,
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>
                        {confirmClear ? t.confirmClearChat : t.clearChat}
                      </span>
                    </button>
                  </div>
                </section>

                {/* Publish Free & Download HTML / ZIP */}
                <section
                  className="pt-5 space-y-3"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" style={{ color: theme.accentText }} />
                    <h3 className="text-sm font-semibold">{t.publishFreeTitle}</h3>
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color: theme.textSecondary }}>
                    {t.publishFreeDesc}
                  </p>

                  <div
                    className="p-2.5 rounded-xl flex items-center justify-between gap-2"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <span
                      className="text-[11px] font-mono-nums truncate select-all"
                      style={{ color: theme.textSecondary }}
                    >
                      {publicLiveUrl}
                    </span>
                    <button
                      type="button"
                      onClick={() => void handleCopyPublicUrl()}
                      className="h-8 px-2.5 rounded-lg text-xs font-medium text-white flex items-center gap-1.5 shrink-0 cursor-pointer"
                      style={{ backgroundColor: theme.accentBg }}
                    >
                      {copiedPublicUrl ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedPublicUrl ? t.copied : t.copyPublicUrl}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      disabled={downloadingKey !== null}
                      onClick={async () => {
                        setDownloadingKey('zip');
                        setDownloadError(null);
                        try {
                          await downloadVerifiedFile(
                            '/api/download/netlify-pack',
                            'arfanmesscent-free-site.zip',
                            'zip'
                          );
                        } catch (err) {
                          setDownloadError(
                            err instanceof Error ? err.message : 'ZIP download failed.'
                          );
                        } finally {
                          setDownloadingKey(null);
                        }
                      }}
                      className="min-h-[42px] px-3 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 text-center cursor-pointer disabled:opacity-60"
                      style={{ backgroundColor: theme.accentBg }}
                    >
                      <Download className="w-4 h-4 shrink-0" />
                      <span>
                        {downloadingKey === 'zip'
                          ? t.downloadingFile
                          : t.downloadZipPack}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={downloadingKey !== null}
                      onClick={async () => {
                        setDownloadingKey('html');
                        setDownloadError(null);
                        try {
                          await downloadVerifiedFile(
                            '/api/download/single-html',
                            'index.html',
                            'html'
                          );
                        } catch (err) {
                          setDownloadError(
                            err instanceof Error ? err.message : 'HTML download failed.'
                          );
                        } finally {
                          setDownloadingKey(null);
                        }
                      }}
                      className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 text-center cursor-pointer disabled:opacity-60"
                      style={{
                        backgroundColor: theme.canvasBg,
                        border: `1px solid ${theme.borderColor}`,
                        color: theme.textPrimary,
                      }}
                    >
                      <Download className="w-4 h-4 shrink-0" />
                      <span>
                        {downloadingKey === 'html'
                          ? t.downloadingFile
                          : t.downloadSingleHtml}
                      </span>
                    </button>

                    <a
                      href="https://app.netlify.com/drop"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="min-h-[42px] px-3 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 text-center"
                      style={{
                        backgroundColor: theme.canvasBg,
                        border: `1px solid ${theme.borderColor}`,
                        color: theme.accentText,
                      }}
                    >
                      <ExternalLink className="w-4 h-4 shrink-0" />
                      <span>{t.openNetlifyDrop}</span>
                    </a>
                  </div>
                  {downloadError && (
                    <p className="text-xs text-red-400" role="alert">
                      {downloadError}
                    </p>
                  )}
                </section>
              </div>
            )}

            {/* TAB 2: Host Oversight — All Private DMs & Groups */}
            {adminTab === 'chats' && (
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Eye className="w-4 h-4" style={{ color: theme.accentText }} />
                    <h3 className="text-sm font-semibold">{t.hostOversightTitle}</h3>
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color: theme.textMuted }}>
                    {t.hostOversightDesc}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onInspectRoom({ roomId: 'main', title: roomTitle, kind: 'main' });
                    onClose();
                  }}
                  className="w-full p-3 rounded-xl flex items-center justify-between gap-2 text-xs cursor-pointer"
                  style={{
                    backgroundColor: theme.canvasBg,
                    border: `1px solid ${theme.borderColor}`,
                  }}
                >
                  <span className="flex items-center gap-2 font-semibold">
                    <Hash className="w-4 h-4" style={{ color: theme.accentText }} />
                    <span>{roomTitle}</span>
                  </span>
                  <span
                    className="px-2.5 py-1 rounded-lg font-medium"
                    style={{
                      backgroundColor: theme.accentSoftBg,
                      color: theme.accentText,
                    }}
                  >
                    {t.viewChatBtn}
                  </span>
                </button>

                <section className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold flex items-center gap-1.5">
                      <MessageSquare
                        className="w-3.5 h-3.5"
                        style={{ color: theme.accentText }}
                      />
                      <span>
                        {t.privateDmChatsLabel} ({allDmThreads.length})
                      </span>
                    </span>
                    {onScanAllDmThreads && (
                      <button
                        type="button"
                        disabled={scanningDmThreads}
                        data-testid="scan-all-dms-btn"
                        onClick={() => void onScanAllDmThreads()}
                        className="h-8 px-2.5 rounded-lg text-[11px] font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
                        style={{
                          backgroundColor: theme.accentSoftBg,
                          color: theme.accentText,
                        }}
                      >
                        <RefreshCw
                          className={`w-3 h-3 ${scanningDmThreads ? 'animate-spin' : ''}`}
                        />
                        <span>
                          {scanningDmThreads ? t.scanningDms : t.refreshDmsBtn}
                        </span>
                      </button>
                    )}
                  </div>

                  {allDmThreads.length === 0 ? (
                    <p className="text-xs" style={{ color: theme.textMuted }}>
                      {t.noPrivateDmsYet}
                    </p>
                  ) : (
                    <ul className="space-y-2 max-h-56 overflow-y-auto chat-scroll">
                      {allDmThreads.map((thread) => {
                        const names = thread.participantIds.map(
                          (pid) =>
                            profilesById[pid]?.displayName ||
                            thread.participantNames?.[pid] ||
                            pid
                        );
                        const pairTitle = names.join(' ↔ ');
                        return (
                          <li
                            key={thread.dmRoomId}
                            className="p-3 rounded-xl flex items-center justify-between gap-2 text-xs"
                            style={{
                              backgroundColor: theme.canvasBg,
                              border: `1px solid ${theme.borderColor}`,
                            }}
                          >
                            <div className="min-w-0 flex-1">
                              <p className="font-semibold truncate">{pairTitle}</p>
                              <p
                                className="truncate text-[11px] mt-0.5"
                                style={{ color: theme.textMuted }}
                              >
                                {thread.lastSenderName}: {thread.lastMessagePreview || '[Media]'} ·{' '}
                                {formatTime(thread.lastMessageAt)}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                onInspectRoom({
                                  roomId: thread.dmRoomId,
                                  title: pairTitle,
                                  kind: 'dm',
                                });
                                onClose();
                              }}
                              className="px-2.5 py-1.5 rounded-lg font-medium flex items-center gap-1 shrink-0 cursor-pointer"
                              style={{
                                backgroundColor: theme.accentBg,
                                color: '#FFFFFF',
                              }}
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>{t.viewChatBtn}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </section>

                {allGroups.length > 0 && (
                  <section className="space-y-2">
                    <span className="text-xs font-semibold block">
                      {t.adminGroupsTitle} ({allGroups.length})
                    </span>
                    <ul className="space-y-2 max-h-44 overflow-y-auto chat-scroll">
                      {allGroups.map((grp) => (
                        <li
                          key={grp.id}
                          className="p-3 rounded-xl flex items-center justify-between gap-2 text-xs"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: `1px solid ${theme.borderColor}`,
                          }}
                        >
                          <div className="min-w-0">
                            <p className="font-semibold truncate">{grp.name}</p>
                            <p style={{ color: theme.textMuted }}>
                              {grp.memberIds.length} {t.groupMembersLabel}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              onInspectRoom({
                                roomId: grp.id,
                                title: grp.name,
                                kind: 'group',
                              });
                              onClose();
                            }}
                            className="px-2.5 py-1.5 rounded-lg font-medium flex items-center gap-1 shrink-0 cursor-pointer"
                            style={{
                              backgroundColor: theme.accentSoftBg,
                              color: theme.accentText,
                            }}
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{t.viewChatBtn}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </section>
                )}
              </div>
            )}

            {/* TAB 3: App Stats + User/Message Reports */}
            {adminTab === 'reports' && (
              <div className="space-y-5">
                <section className="space-y-3">
                  <div className="flex items-center gap-2">
                    <BarChart2
                      className="w-4 h-4"
                      style={{ color: theme.accentText }}
                    />
                    <h3 className="text-sm font-semibold">{t.adminStatsTitle}</h3>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { label: t.onlineNow, val: onlineCount },
                      { label: 'BD Phones', val: registeredUsers.length },
                      { label: t.tabGroups, val: allGroups.length },
                      { label: t.tabStories, val: storyCount },
                    ].map((stat) => (
                      <div
                        key={stat.label}
                        className="p-3 rounded-xl"
                        style={{
                          backgroundColor: theme.canvasBg,
                          border: `1px solid ${theme.borderColor}`,
                        }}
                      >
                        <div className="font-mono-nums text-lg font-bold">
                          {stat.val}
                        </div>
                        <div
                          className="text-[11px]"
                          style={{ color: theme.textMuted }}
                        >
                          {stat.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                <section
                  className="pt-4 space-y-3"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <div className="flex items-center gap-2">
                    <Flag className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-semibold">
                      {t.adminReportsTitle}
                    </h3>
                  </div>

                  {reports.length === 0 ? (
                    <p className="text-xs" style={{ color: theme.textMuted }}>
                      {t.noReports}
                    </p>
                  ) : (
                    <ul className="space-y-2 max-h-64 overflow-y-auto chat-scroll">
                      {reports.map((rep) => (
                        <li
                          key={rep.id}
                          className="p-3 rounded-xl space-y-2 text-xs"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: `1px solid ${theme.borderColor}`,
                          }}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold">
                              {rep.targetName}{' '}
                              <span style={{ color: theme.textMuted }}>
                                ({rep.targetType}) · {formatTime(rep.createdAt)}
                              </span>
                            </span>
                            <span
                              className="text-[11px] font-semibold"
                              style={{
                                color:
                                  rep.status === 'resolved'
                                    ? '#34D399'
                                    : '#FBBF24',
                              }}
                            >
                              {rep.status === 'resolved'
                                ? t.resolvedBadge
                                : t.openBadge}
                            </span>
                          </div>
                          <p style={{ color: theme.textSecondary }}>
                            {rep.reason}
                          </p>
                          {rep.messagePreview && (
                            <p
                              className="italic truncate"
                              style={{ color: theme.textMuted }}
                            >
                              &ldquo;{rep.messagePreview}&rdquo;
                            </p>
                          )}
                          <div className="flex flex-wrap items-center gap-1.5 pt-1">
                            {rep.status !== 'resolved' && (
                              <button
                                type="button"
                                onClick={() => void onResolveReport(rep.id)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-400 font-medium cursor-pointer"
                              >
                                {t.resolveReport}
                              </button>
                            )}
                            {rep.messageId && (
                              <button
                                type="button"
                                onClick={() =>
                                  void onDeleteReportedMessage(
                                    rep.messageId!,
                                    rep.roomId
                                  )
                                }
                                className="px-2.5 py-1 rounded-lg bg-red-500/15 text-red-400 font-medium cursor-pointer"
                              >
                                {t.deleteMessage}
                              </button>
                            )}
                            {isProtectedHost({
                              clientId: rep.targetId,
                              nickname: rep.targetName,
                            }) ? (
                              <span
                                className="px-2 py-1 rounded-lg text-[11px] font-medium"
                                style={{
                                  backgroundColor: theme.accentSoftBg,
                                  color: theme.accentText,
                                }}
                              >
                                {t.hostProtectedBadge}
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() =>
                                  onBlockUser({
                                    nickname: rep.targetName,
                                    clientId: rep.targetId,
                                  })
                                }
                                className="px-2.5 py-1 rounded-lg bg-red-600/20 text-red-300 font-medium cursor-pointer"
                              >
                                {t.blockUser}
                              </button>
                            )}
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              </div>
            )}

            {/* TAB 3: Manage Custom Groups */}
            {adminTab === 'groups' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Users
                    className="w-4 h-4"
                    style={{ color: theme.accentText }}
                  />
                  <h3 className="text-sm font-semibold">
                    {t.adminGroupsTitle}
                  </h3>
                </div>
                {allGroups.length === 0 ? (
                  <p className="text-xs" style={{ color: theme.textMuted }}>
                    {t.noGroupsYet}
                  </p>
                ) : (
                  <ul className="space-y-2 max-h-72 overflow-y-auto chat-scroll">
                    {allGroups.map((grp) => (
                      <li
                        key={grp.id}
                        className="p-3 rounded-xl flex items-center justify-between gap-2 text-xs"
                        style={{
                          backgroundColor: theme.canvasBg,
                          border: `1px solid ${theme.borderColor}`,
                        }}
                      >
                        <div className="min-w-0">
                          <p className="font-semibold truncate">{grp.name}</p>
                          <p style={{ color: theme.textMuted }}>
                            {grp.memberIds.length} {t.groupMembersLabel} ·{' '}
                            {grp.adminIds.length} admins
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => void onDeleteGroup(grp)}
                          className="px-2.5 py-1.5 rounded-lg bg-red-500/15 text-red-400 flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t.deleteMessage}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {/* TAB 4: BD Phone Registry + Blocked Users */}
            {adminTab === 'phones' && (
              <div className="space-y-5">
                <section className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Phone
                        className="w-4 h-4"
                        style={{ color: theme.accentText }}
                      />
                      <h3 className="text-sm font-semibold">
                        {t.registeredPhonesTitle}
                      </h3>
                    </div>
                    <span
                      className="text-xs font-mono-nums px-2 py-0.5 rounded-lg"
                      style={{
                        backgroundColor: theme.accentSoftBg,
                        color: theme.accentText,
                      }}
                    >
                      {registeredUsers.length}
                    </span>
                  </div>

                  <div
                    className="flex items-center h-9 px-3 rounded-xl gap-2"
                    style={{
                      backgroundColor: theme.canvasBg,
                      border: `1px solid ${theme.borderColor}`,
                    }}
                  >
                    <Search
                      className="w-3.5 h-3.5 shrink-0"
                      style={{ color: theme.textMuted }}
                    />
                    <input
                      type="text"
                      value={phoneSearch}
                      onChange={(e) => setPhoneSearch(e.target.value)}
                      placeholder={t.registeredPhonesSearch}
                      aria-label={t.registeredPhonesSearch}
                      className="flex-1 bg-transparent text-xs outline-none"
                      style={{ color: theme.textPrimary }}
                    />
                  </div>

                  {filteredRegistered.length === 0 ? (
                    <p className="text-xs" style={{ color: theme.textMuted }}>
                      {t.noRegisteredPhones}
                    </p>
                  ) : (
                    <ul className="space-y-2 max-h-52 overflow-y-auto chat-scroll">
                      {filteredRegistered.map((reg) => {
                        const isOnline = onlineIds.has(reg.clientId);
                        const isSelf = reg.clientId === currentClientId;
                        const alreadyBlocked = isUserBlocked(
                          blockedUsers,
                          reg.clientId,
                          reg.nickname,
                          reg.phoneNumber
                        );
                        return (
                          <li
                            key={reg.clientId}
                            className="px-3 py-2.5 rounded-xl flex items-center justify-between gap-2.5"
                            style={{
                              backgroundColor: theme.canvasBg,
                              border: `1px solid ${
                                alreadyBlocked
                                  ? 'rgba(239, 68, 68, 0.35)'
                                  : theme.borderColor
                              }`,
                            }}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-bold text-white shrink-0 relative"
                                style={{ backgroundColor: reg.avatarColor }}
                              >
                                {getInitials(reg.nickname)}
                                <span
                                  className="w-2.5 h-2.5 rounded-full absolute -bottom-0.5 -right-0.5 border-2"
                                  style={{
                                    borderColor: theme.canvasBg,
                                    backgroundColor: isOnline
                                      ? '#34D399'
                                      : '#6B7280',
                                  }}
                                  title={
                                    isOnline ? t.onlineStatus : t.offlineStatus
                                  }
                                />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-xs font-semibold truncate">
                                    {reg.nickname}
                                  </span>
                                  {isSelf && (
                                    <span
                                      className="text-[10px] font-medium"
                                      style={{ color: theme.accentText }}
                                    >
                                      ({t.you})
                                    </span>
                                  )}
                                  {alreadyBlocked && (
                                    <span className="text-[10px] text-red-400 font-medium">
                                      · {t.blockedBadge}
                                    </span>
                                  )}
                                </div>
                                <p
                                  className="text-xs font-mono-nums select-all"
                                  style={{ color: theme.accentText }}
                                >
                                  {formatBdPhoneDisplay(reg.phoneNumber)}
                                </p>
                              </div>
                            </div>

                            {(() => {
                              const protectedHost = isProtectedHost({
                                clientId: reg.clientId,
                                nickname: reg.nickname,
                                phoneNumber: reg.phoneNumber,
                              });
                              return (
                                <div className="flex items-center gap-1.5 shrink-0 flex-wrap justify-end">
                                  {protectedHost ? (
                                    <span
                                      className="px-2 py-1 rounded-lg text-[11px] font-semibold"
                                      style={{
                                        backgroundColor: theme.accentSoftBg,
                                        color: theme.accentText,
                                      }}
                                    >
                                      {t.hostProtectedBadge}
                                    </span>
                                  ) : alreadyBlocked ? (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onUnblock({
                                          clientId: reg.clientId,
                                          nickname: reg.nickname,
                                          phoneNumber: reg.phoneNumber,
                                        })
                                      }
                                      className="h-8 px-2.5 rounded-lg text-xs font-medium text-emerald-400 bg-emerald-500/15 hover:bg-emerald-500/25 flex items-center gap-1 cursor-pointer"
                                    >
                                      <UserCheck className="w-3.5 h-3.5" />
                                      <span>{t.unblockUser}</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onBlockUser({
                                          nickname: reg.nickname,
                                          clientId: reg.clientId,
                                          phoneNumber: reg.phoneNumber,
                                        })
                                      }
                                      className="h-8 px-2.5 rounded-lg text-xs font-medium text-amber-400 bg-amber-500/15 hover:bg-amber-500/25 flex items-center gap-1 cursor-pointer"
                                    >
                                      <Ban className="w-3.5 h-3.5" />
                                      <span>{t.blockUser}</span>
                                    </button>
                                  )}
                                  {!isSelf && (
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onDeleteContact({
                                          clientId: reg.clientId,
                                          nickname: reg.nickname,
                                          phoneNumber: reg.phoneNumber,
                                        })
                                      }
                                      aria-label={`${t.deleteContact} ${reg.nickname}`}
                                      title={t.deleteContact}
                                      className="h-8 px-2.5 rounded-lg text-xs font-medium text-red-400 bg-red-500/15 hover:bg-red-500/25 flex items-center gap-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      <span>{t.deleteContactBtn}</span>
                                    </button>
                                  )}
                                </div>
                              );
                            })()}
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </section>

                {/* All Contacts (Profiles) Management */}
                <section
                  className="pt-4 space-y-2.5"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold">{t.allContactsTitle}</h3>
                    <span
                      className="text-xs font-mono-nums"
                      style={{ color: theme.textMuted }}
                    >
                      {allProfiles.length}
                    </span>
                  </div>
                  {allProfiles.length > 0 && (
                    <ul className="space-y-1.5 max-h-48 overflow-y-auto chat-scroll">
                      {allProfiles
                        .filter((prof) => {
                          if (!phoneSearch.trim()) return true;
                          const q = phoneSearch.trim().toLowerCase();
                          return (
                            prof.displayName.toLowerCase().includes(q) ||
                            (prof.username || '').toLowerCase().includes(q)
                          );
                        })
                        .map((prof) => {
                          const isSelf = prof.clientId === currentClientId;
                          const protectedHost = isProtectedHost({
                            clientId: prof.clientId,
                            nickname: prof.displayName,
                          });
                          const alreadyBlocked = blockedUsers.some(
                            (bu) =>
                              bu.clientId === prof.clientId ||
                              normalizeNicknameKey(bu.nickname) ===
                                normalizeNicknameKey(prof.displayName)
                          );
                          return (
                            <li
                              key={prof.clientId}
                              className="px-3 py-2 rounded-xl flex items-center justify-between gap-2"
                              style={{
                                backgroundColor: theme.canvasBg,
                                border: `1px solid ${theme.borderColor}`,
                              }}
                            >
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-xs font-semibold truncate">
                                    {prof.displayName}
                                  </span>
                                  {prof.isAdmin && (
                                    <span
                                      className="text-[10px] font-semibold"
                                      style={{ color: theme.accentText }}
                                    >
                                      · {t.adminBadge}
                                    </span>
                                  )}
                                  {alreadyBlocked && (
                                    <span className="text-[10px] text-red-400 font-medium">
                                      · {t.blockedBadge}
                                    </span>
                                  )}
                                </div>
                                <p
                                  className="text-[11px] truncate"
                                  style={{ color: theme.textMuted }}
                                >
                                  {prof.username ? `@${prof.username}` : prof.clientId}
                                </p>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                {protectedHost ? (
                                  <span
                                    className="px-2 py-1 rounded-lg text-[11px] font-semibold"
                                    style={{
                                      backgroundColor: theme.accentSoftBg,
                                      color: theme.accentText,
                                    }}
                                  >
                                    {t.hostProtectedBadge}
                                  </span>
                                ) : !alreadyBlocked ? (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onBlockUser({
                                        clientId: prof.clientId,
                                        nickname: prof.displayName,
                                      })
                                    }
                                    className="h-8 px-2 rounded-lg text-xs font-medium text-amber-400 bg-amber-500/15 hover:bg-amber-500/25 flex items-center gap-1 cursor-pointer"
                                  >
                                    <Ban className="w-3.5 h-3.5" />
                                  </button>
                                ) : null}
                                {!isSelf && (
                                  <button
                                    type="button"
                                    data-testid={`admin-delete-contact-${prof.clientId}`}
                                    onClick={() =>
                                      onDeleteContact({
                                        clientId: prof.clientId,
                                        nickname: prof.displayName,
                                      })
                                    }
                                    aria-label={`${t.deleteContact} ${prof.displayName}`}
                                    className="h-8 px-2.5 rounded-lg text-xs font-medium text-red-400 bg-red-500/15 hover:bg-red-500/25 flex items-center gap-1 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>{t.deleteContactBtn}</span>
                                  </button>
                                )}
                              </div>
                            </li>
                          );
                        })}
                    </ul>
                  )}
                </section>

                {/* Deleted Contacts Archive + 1-Click Restore */}
                <section
                  className="pt-4 space-y-2.5"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold">
                      {t.deletedContactsTitle}
                    </h3>
                    <span
                      className="text-xs font-mono-nums"
                      style={{ color: theme.textMuted }}
                    >
                      {deletedContacts.length}
                    </span>
                  </div>
                  {deletedContacts.length === 0 ? (
                    <p className="text-xs" style={{ color: theme.textMuted }}>
                      {t.noDeletedContacts}
                    </p>
                  ) : (
                    <ul className="space-y-1.5 max-h-40 overflow-y-auto chat-scroll">
                      {deletedContacts.map((dc) => (
                        <li
                          key={dc.clientId}
                          className="px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: `1px solid ${theme.borderColor}`,
                          }}
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-semibold truncate">
                                {dc.nickname}
                              </span>
                              {dc.isAdmin && (
                                <span
                                  className="text-[10px] font-semibold"
                                  style={{ color: theme.accentText }}
                                >
                                  · {t.adminBadge}
                                </span>
                              )}
                            </div>
                            <p
                              className="text-[11px] truncate"
                              style={{ color: theme.textMuted }}
                            >
                              {dc.phoneNumber
                                ? `${formatBdPhoneDisplay(dc.phoneNumber)} · `
                                : dc.username
                                  ? `@${dc.username} · `
                                  : ''}
                              {formatTime(dc.deletedAt)}
                            </p>
                          </div>
                          <button
                            type="button"
                            data-testid="restore-contact-btn"
                            onClick={() => void onRestoreDeletedContact(dc)}
                            className="h-8 px-2.5 rounded-lg text-emerald-400 bg-emerald-500/15 hover:bg-emerald-500/25 flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>{t.restoreContactBtn}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>

                <section
                  className="pt-4 space-y-3"
                  style={{ borderTop: `1px solid ${theme.borderColor}` }}
                >
                  <h3 className="text-sm font-semibold">{t.blockedUsersTitle}</h3>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={blockNickDraft}
                      onChange={(e) => {
                        setBlockNickDraft(e.target.value);
                        if (quickBlockError) setQuickBlockError(null);
                      }}
                      placeholder={t.quickBlockPlaceholder}
                      className="flex-1 h-10 px-3 rounded-xl text-sm outline-none"
                      style={{
                        backgroundColor: theme.canvasBg,
                        border: `1px solid ${theme.borderColor}`,
                        color: theme.textPrimary,
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const draft = blockNickDraft.trim();
                        if (!draft) return;
                        if (isProtectedHost({ nickname: draft })) {
                          setQuickBlockError(t.cannotBlockSelfOrHost);
                          return;
                        }
                        setQuickBlockError(null);
                        onBlockUser({ nickname: draft });
                        setBlockNickDraft('');
                      }}
                      className="h-10 px-3.5 rounded-xl text-xs font-medium text-white bg-red-600 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>{t.blockUser}</span>
                    </button>
                  </div>
                  {quickBlockError && (
                    <p className="text-xs text-red-400" role="alert">
                      {quickBlockError}
                    </p>
                  )}

                  {blockedUsers.length === 0 ? (
                    <p className="text-xs" style={{ color: theme.textMuted }}>
                      {t.noBlockedUsers}
                    </p>
                  ) : (
                    <ul className="space-y-1.5 max-h-36 overflow-y-auto chat-scroll">
                      {blockedUsers.map((bu) => (
                        <li
                          key={`${bu.clientId}-${bu.nickname}-${bu.phoneNumber || ''}`}
                          className="px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
                          style={{
                            backgroundColor: theme.canvasBg,
                            border: `1px solid ${theme.borderColor}`,
                          }}
                        >
                          <div className="min-w-0">
                            <span className="font-medium block truncate">
                              {bu.nickname}
                            </span>
                            {bu.phoneNumber && (
                              <span
                                className="text-[11px] font-mono-nums block"
                                style={{ color: theme.textMuted }}
                              >
                                {formatBdPhoneDisplay(bu.phoneNumber)}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              onUnblock({
                                clientId: bu.clientId,
                                nickname: bu.nickname,
                                phoneNumber: bu.phoneNumber,
                              })
                            }
                            className="px-2.5 py-1 rounded-lg text-emerald-400 hover:bg-emerald-500/15 flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{t.unblockUser}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              </div>
            )}

            {/* Logout Admin Mode */}
            <div
              className="pt-4 flex justify-end"
              style={{ borderTop: `1px solid ${theme.borderColor}` }}
            >
              <button
                type="button"
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="min-h-[40px] px-4 rounded-xl text-xs font-medium flex items-center gap-2 cursor-pointer"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textMuted,
                }}
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.lockOutAdmin}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
