import React, { useEffect, useRef, useState } from 'react';
import {
  BarChart2,
  FileText,
  ImagePlus,
  Lock,
  Mic,
  Paperclip,
  Plus,
  Send,
  Smile,
  Square,
  X,
} from 'lucide-react';
import { formatDuration, formatFileSize } from '../shared/chatRules';
import type { ChatMessage, CustomSticker, ThemeSpec } from '../shared/types';
import { COPY, type Lang } from '../utils/i18n';
import { uploadMediaFile } from '../utils/storageHelper';
import { EmojiPickerPopover } from './EmojiPickerPopover';

interface PendingAttachment {
  kind: 'image' | 'video' | 'file';
  url: string;
  fileName?: string;
  fileSize?: number;
  fileMime?: string;
}

interface MessageComposerProps {
  clientId: string;
  roomLocked: boolean;
  isAdmin: boolean;
  allowMedia?: boolean;
  allowVoice?: boolean;
  allowPolls?: boolean;
  roomError: string | null;
  droppedFile: File | null;
  replyTo: ChatMessage | null;
  customStickers: CustomSticker[];
  theme: ThemeSpec;
  lang: Lang;
  onClearDroppedFile: () => void;
  onCancelReply: () => void;
  onUploadSticker: (file: File) => Promise<CustomSticker | null>;
  onSendMessage: (payload: {
    text: string;
    imageUrl?: string;
    videoUrl?: string;
    audioUrl?: string;
    audioDataUrl?: string;
    audioDurationSec?: number;
    fileUrl?: string;
    fileName?: string;
    fileSize?: number;
    fileMime?: string;
    gifUrl?: string;
    stickerUrl?: string;
    poll?: { question: string; options: string[] };
  }) => void;
  onTypingChange: (isTyping: boolean) => void;
}

export function MessageComposer({
  clientId,
  roomLocked,
  isAdmin,
  allowMedia = true,
  allowVoice = true,
  allowPolls = true,
  roomError,
  droppedFile,
  replyTo,
  customStickers,
  theme,
  lang,
  onClearDroppedFile,
  onCancelReply,
  onUploadSticker,
  onSendMessage,
  onTypingChange,
}: MessageComposerProps) {
  const [text, setText] = useState('');
  const [attachment, setAttachment] = useState<PendingAttachment | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cancelRecordingRef = useRef(false);
  const recordSecondsRef = useRef(0);

  const mediaInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const t = COPY[lang];

  const disabled = roomLocked && !isAdmin;
  const mediaAllowed = isAdmin || allowMedia;
  const voiceAllowed = isAdmin || allowVoice;
  const pollsAllowed = isAdmin || allowPolls;

  const uploadAndStageFile = async (file: File) => {
    if (!mediaAllowed) {
      setMediaError(t.mediaDisabledNotice);
      return;
    }
    setMediaError(null);
    setUploading(true);
    try {
      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');
      const folder = isImage
        ? 'chat-images'
        : isVideo
          ? 'chat-videos'
          : 'chat-files';
      const res = await uploadMediaFile(file, folder, clientId, file.name);
      setAttachment({
        kind: isImage ? 'image' : isVideo ? 'video' : 'file',
        url: res.url,
        fileName: file.name,
        fileSize: file.size,
        fileMime: res.mime,
      });
    } catch (err) {
      setMediaError(
        err instanceof Error ? err.message : 'Failed to upload media.'
      );
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => {
    if (droppedFile) {
      void uploadAndStageFile(droppedFile);
      onClearDroppedFile();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [droppedFile]);

  useEffect(() => {
    return () => {
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
      if (mediaRecorderRef.current?.state === 'recording') {
        cancelRecordingRef.current = true;
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const triggerTyping = (active: boolean) => {
    onTypingChange(active);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    if (active) {
      typingTimeoutRef.current = setTimeout(() => {
        onTypingChange(false);
      }, 2200);
    }
  };

  const handleSend = () => {
    if (disabled || uploading) return;
    const trimmed = text.trim();
    if (!trimmed && !attachment) return;

    onSendMessage({
      text: trimmed,
      ...(attachment?.kind === 'image' ? { imageUrl: attachment.url } : {}),
      ...(attachment?.kind === 'video' ? { videoUrl: attachment.url } : {}),
      ...(attachment?.kind === 'file'
        ? {
            fileUrl: attachment.url,
            fileName: attachment.fileName,
            fileSize: attachment.fileSize,
            fileMime: attachment.fileMime,
          }
        : {}),
    });
    setText('');
    setAttachment(null);
    setShowEmojiPicker(false);
    setMediaError(null);
    triggerTyping(false);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    await uploadAndStageFile(file);
  };

  const handlePaste = async (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of Array.from(items)) {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          await uploadAndStageFile(file);
          return;
        }
      }
    }
  };

  const startRecording = async () => {
    if (disabled || isRecording) return;
    if (!voiceAllowed) {
      setMediaError(t.voiceDisabledNotice);
      return;
    }
    setMediaError(null);
    if (
      !navigator.mediaDevices?.getUserMedia ||
      typeof MediaRecorder === 'undefined'
    ) {
      setMediaError('Voice recording is not supported in this browser.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      cancelRecordingRef.current = false;
      recordSecondsRef.current = 0;
      setRecordSeconds(0);

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) {
          audioChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        if (recordTimerRef.current) clearInterval(recordTimerRef.current);
        setIsRecording(false);

        if (cancelRecordingRef.current || audioChunksRef.current.length === 0) {
          return;
        }

        const blob = new Blob(audioChunksRef.current, {
          type: recorder.mimeType || 'audio/webm',
        });
        const dur = Math.max(1, recordSecondsRef.current);

        try {
          setUploading(true);
          const uploaded = await uploadMediaFile(
            blob,
            'chat-audio',
            clientId,
            `voice-${Date.now()}.webm`
          );
          onSendMessage({
            text: '',
            audioUrl: uploaded.url,
            audioDurationSec: dur,
          });
        } catch {
          // Small fallback for static offline mode
          if (blob.size < 450_000) {
            const reader = new FileReader();
            reader.onload = () => {
              if (typeof reader.result === 'string') {
                onSendMessage({
                  text: '',
                  audioDataUrl: reader.result,
                  audioDurationSec: dur,
                });
              }
            };
            reader.readAsDataURL(blob);
          } else {
            setMediaError('Voice upload failed. Enable Firebase Storage.');
          }
        } finally {
          setUploading(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setShowEmojiPicker(false);
      setShowPollCreator(false);

      recordTimerRef.current = setInterval(() => {
        recordSecondsRef.current += 1;
        setRecordSeconds(recordSecondsRef.current);
        if (
          recordSecondsRef.current >= 90 &&
          mediaRecorderRef.current?.state === 'recording'
        ) {
          mediaRecorderRef.current.stop();
        }
      }, 1000);
    } catch {
      setMediaError('Microphone permission denied or unavailable.');
    }
  };

  const stopRecording = (cancel = false) => {
    cancelRecordingRef.current = cancel;
    if (mediaRecorderRef.current?.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const handleSubmitPoll = (e: React.FormEvent) => {
    e.preventDefault();
    const q = pollQuestion.trim();
    const opts = pollOptions.map((o) => o.trim()).filter(Boolean);
    if (q.length < 2 || opts.length < 2) {
      setMediaError('Poll needs a question and at least 2 options.');
      return;
    }
    onSendMessage({
      text: '',
      poll: { question: q, options: opts },
    });
    setPollQuestion('');
    setPollOptions(['', '']);
    setShowPollCreator(false);
    setMediaError(null);
  };

  const insertEmoji = (emoji: string) => {
    setText((prev) => prev + emoji);
    inputRef.current?.focus();
  };

  return (
    <div
      data-testid="message-composer"
      className="shrink-0 px-3 sm:px-5 pt-2.5 sm:pt-3 pb-[calc(4.25rem+env(safe-area-inset-bottom))] sm:pb-14 relative"
      style={{
        backgroundColor: theme.sidebarBg,
        borderTop: `1px solid ${theme.borderColor}`,
      }}
    >
      {/* Emoji, GIFs & Stickers Popover */}
      <EmojiPickerPopover
        open={showEmojiPicker && !disabled}
        theme={theme}
        lang={lang}
        placement="top"
        align="left"
        ariaLabel={t.emojiPicker}
        customStickers={customStickers}
        onSelectEmoji={insertEmoji}
        onSelectGif={(gifUrl) => {
          if (!mediaAllowed) {
            setMediaError(t.mediaDisabledNotice);
            return;
          }
          onSendMessage({ text: '', gifUrl });
        }}
        onSelectSticker={(stickerUrl) => {
          if (!mediaAllowed) {
            setMediaError(t.mediaDisabledNotice);
            return;
          }
          onSendMessage({ text: '', stickerUrl });
        }}
        onUploadSticker={onUploadSticker}
        onClose={() => setShowEmojiPicker(false)}
      />

      {/* Live Poll Creator Popover */}
      {showPollCreator && !disabled && pollsAllowed && (
        <form
          onSubmit={handleSubmitPoll}
          className="absolute bottom-full left-3 right-3 sm:left-5 sm:right-auto sm:w-96 mb-2 rounded-2xl p-4 shadow-2xl z-30 space-y-3"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          <div className="flex items-center justify-between">
            <span
              className="text-xs font-semibold flex items-center gap-1.5"
              style={{ color: theme.textSecondary }}
            >
              <BarChart2 className="w-4 h-4" />
              {t.createPoll}
            </span>
            <button
              type="button"
              onClick={() => setShowPollCreator(false)}
              aria-label={t.close}
              className="w-7 h-7 rounded-lg flex items-center justify-center cursor-pointer"
              style={{ color: theme.textMuted }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <input
            type="text"
            autoFocus
            maxLength={160}
            value={pollQuestion}
            onChange={(e) => setPollQuestion(e.target.value)}
            placeholder={t.pollQuestionPlaceholder}
            aria-label={t.pollQuestionPlaceholder}
            className="w-full h-10 px-3 rounded-xl text-sm outline-none"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />

          <div className="space-y-2">
            {pollOptions.map((opt, idx) => (
              <input
                key={idx}
                type="text"
                maxLength={80}
                value={opt}
                onChange={(e) => {
                  const next = [...pollOptions];
                  next[idx] = e.target.value;
                  setPollOptions(next);
                }}
                placeholder={`${t.pollOptionPlaceholder} ${idx + 1}`}
                aria-label={`${t.pollOptionPlaceholder} ${idx + 1}`}
                className="w-full h-9 px-3 rounded-xl text-xs outline-none"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textPrimary,
                }}
              />
            ))}
          </div>

          <div className="flex items-center justify-between gap-2 pt-1">
            {pollOptions.length < 4 ? (
              <button
                type="button"
                onClick={() => setPollOptions((o) => [...o, ''])}
                className="h-9 px-3 rounded-xl text-xs font-medium flex items-center gap-1 cursor-pointer"
                style={{
                  backgroundColor: theme.canvasBg,
                  border: `1px solid ${theme.borderColor}`,
                  color: theme.textSecondary,
                }}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t.addPollOption}</span>
              </button>
            ) : (
              <span />
            )}

            <button
              type="submit"
              className="h-9 px-4 rounded-xl text-xs font-medium text-white cursor-pointer"
              style={{ backgroundColor: theme.accentBg }}
            >
              {t.postPoll}
            </button>
          </div>
        </form>
      )}

      {/* Locked Room Banner */}
      {disabled && (
        <div
          className="mb-2 px-3 py-2 rounded-xl text-xs flex items-center gap-2"
          style={{
            backgroundColor: 'rgba(245, 158, 11, 0.12)',
            color: '#FBBF24',
          }}
        >
          <Lock className="w-3.5 h-3.5 shrink-0" />
          <span>{t.roomLockedBanner}</span>
        </div>
      )}

      {/* Reply Banner */}
      {replyTo && (
        <div
          className="mb-2 px-3 py-2 rounded-xl flex items-center justify-between gap-2 text-xs"
          style={{
            backgroundColor: theme.surfaceBg,
            border: `1px solid ${theme.borderColor}`,
          }}
        >
          <div className="min-w-0">
            <span
              className="font-semibold"
              style={{ color: theme.accentText }}
            >
              {t.replyingTo} {replyTo.senderName}:{' '}
            </span>
            <span style={{ color: theme.textMuted }} className="truncate">
              {replyTo.text ||
                (replyTo.poll ? `📊 ${replyTo.poll.question}` : '') ||
                (replyTo.audioUrl || replyTo.audioDataUrl ? '🎙️ Voice Note' : '') ||
                (replyTo.videoUrl ? '🎬 Video' : '') ||
                (replyTo.imageUrl || replyTo.imageDataUrl ? '📷 Photo' : '')}
            </span>
          </div>
          <button
            type="button"
            onClick={onCancelReply}
            aria-label={t.cancelReply}
            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 cursor-pointer"
            style={{ color: theme.textMuted }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Staged Attachment Preview */}
      {attachment && (
        <div className="mb-2 relative inline-flex items-center">
          {attachment.kind === 'image' && (
            <img
              src={attachment.url}
              alt="Upload preview"
              className="h-24 w-auto rounded-xl object-cover"
              style={{ border: `1px solid ${theme.borderColor}` }}
            />
          )}
          {attachment.kind === 'video' && (
            <video
              src={attachment.url}
              controls
              className="h-24 w-auto rounded-xl bg-black"
              style={{ border: `1px solid ${theme.borderColor}` }}
            />
          )}
          {attachment.kind === 'file' && (
            <div
              className="px-3.5 py-2.5 rounded-xl flex items-center gap-2 text-xs"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
              }}
            >
              <FileText className="w-4 h-4" style={{ color: theme.accentText }} />
              <span className="font-medium truncate max-w-[200px]">
                {attachment.fileName}
              </span>
              <span className="opacity-70 font-mono-nums">
                {formatFileSize(attachment.fileSize)}
              </span>
            </div>
          )}
          <button
            type="button"
            onClick={() => setAttachment(null)}
            aria-label="Remove attachment"
            className="ml-2 w-7 h-7 rounded-full bg-red-600 text-white flex items-center justify-center shadow cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {(mediaError || roomError) && (
        <p className="mb-2 text-xs text-red-400" role="alert">
          {mediaError || roomError}
        </p>
      )}

      {/* Active Recording Row OR Standard Composer Row */}
      {isRecording ? (
        <div
          className="h-11 px-3 rounded-xl flex items-center justify-between gap-3"
          style={{
            backgroundColor: 'rgba(239, 68, 68, 0.14)',
            border: '1px solid rgba(239, 68, 68, 0.35)',
          }}
        >
          <div className="flex items-center gap-2.5 text-sm font-medium text-red-400">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            <span>{t.recordingLabel}</span>
            <span className="font-mono-nums">{formatDuration(recordSeconds)}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => stopRecording(true)}
              aria-label={t.cancelVoice}
              className="h-9 px-3 rounded-lg text-xs font-medium cursor-pointer"
              style={{
                backgroundColor: theme.surfaceBg,
                color: theme.textMuted,
              }}
            >
              {t.cancelReply}
            </button>
            <button
              type="button"
              onClick={() => stopRecording(false)}
              aria-label={t.stopVoice}
              className="h-9 px-3.5 rounded-lg text-xs font-medium text-white bg-red-600 flex items-center gap-1.5 cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>{t.send}</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-end gap-1.5 sm:gap-2">
          <input
            ref={mediaInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleFileChange}
            className="hidden"
            aria-label={t.attachImage}
          />
          <input
            ref={docInputRef}
            type="file"
            onChange={handleFileChange}
            className="hidden"
            aria-label={t.attachFile}
          />

          <button
            type="button"
            disabled={disabled || uploading || !mediaAllowed}
            onClick={() => mediaInputRef.current?.click()}
            aria-label={t.attachImage}
            title={mediaAllowed ? t.attachImage : t.mediaDisabledNotice}
            className="min-h-[40px] min-w-[36px] sm:min-h-[44px] sm:min-w-[42px] rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer disabled:opacity-40"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            <ImagePlus className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <button
            type="button"
            disabled={disabled || uploading || !mediaAllowed}
            onClick={() => docInputRef.current?.click()}
            aria-label={t.attachFile}
            title={mediaAllowed ? t.attachFile : t.mediaDisabledNotice}
            className="flex min-h-[40px] min-w-[36px] sm:min-h-[44px] sm:min-w-[42px] rounded-xl items-center justify-center transition-colors shrink-0 cursor-pointer disabled:opacity-40"
            style={{
              backgroundColor: theme.surfaceBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textSecondary,
            }}
          >
            <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <button
            type="button"
            disabled={disabled}
            onClick={() => {
              setShowPollCreator(false);
              setShowEmojiPicker((s) => !s);
            }}
            aria-label={t.emojiPicker}
            aria-expanded={showEmojiPicker}
            title={t.emojiPicker}
            className="min-h-[40px] min-w-[36px] sm:min-h-[44px] sm:min-w-[42px] rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer disabled:opacity-40"
            style={{
              backgroundColor: showEmojiPicker
                ? theme.accentSoftBg
                : theme.surfaceBg,
              border: `1px solid ${
                showEmojiPicker ? theme.accentBorder : theme.borderColor
              }`,
              color: showEmojiPicker ? theme.accentText : theme.textSecondary,
            }}
          >
            <Smile className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <button
            type="button"
            disabled={disabled || !pollsAllowed}
            onClick={() => {
              setShowEmojiPicker(false);
              setShowPollCreator((s) => !s);
            }}
            aria-label={t.createPoll}
            aria-expanded={showPollCreator}
            title={pollsAllowed ? t.createPoll : t.pollsDisabledNotice}
            className="flex min-h-[40px] min-w-[36px] sm:min-h-[44px] sm:min-w-[42px] rounded-xl items-center justify-center transition-colors shrink-0 cursor-pointer disabled:opacity-40"
            style={{
              backgroundColor: showPollCreator
                ? theme.accentSoftBg
                : theme.surfaceBg,
              border: `1px solid ${
                showPollCreator ? theme.accentBorder : theme.borderColor
              }`,
              color: showPollCreator ? theme.accentText : theme.textSecondary,
            }}
          >
            <BarChart2 className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <textarea
            ref={inputRef}
            rows={1}
            disabled={disabled}
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              triggerTyping(e.target.value.trim().length > 0);
            }}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder={
              uploading
                ? t.uploadingBackground
                : disabled
                  ? t.roomLockedBanner
                  : t.typeMessage
            }
            aria-label={t.typeMessage}
            className="flex-1 min-w-0 min-h-[40px] sm:min-h-[44px] max-h-32 py-2 sm:py-2.5 px-3 sm:px-3.5 rounded-xl text-sm sm:text-base resize-none outline-none"
            style={{
              backgroundColor: theme.canvasBg,
              border: `1px solid ${theme.borderColor}`,
              color: theme.textPrimary,
            }}
          />

          {!text.trim() && !attachment ? (
            <button
              type="button"
              disabled={disabled || uploading || !voiceAllowed}
              onClick={startRecording}
              aria-label={t.recordVoice}
              title={voiceAllowed ? t.recordVoice : t.voiceDisabledNotice}
              className="min-h-[40px] min-w-[40px] sm:min-h-[44px] sm:min-w-[44px] px-2.5 sm:px-3 rounded-xl flex items-center justify-center transition-colors shrink-0 cursor-pointer disabled:opacity-40"
              style={{
                backgroundColor: theme.surfaceBg,
                border: `1px solid ${theme.borderColor}`,
                color: theme.accentText,
              }}
            >
              <Mic className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          ) : (
            <button
              type="button"
              disabled={disabled || uploading}
              onClick={handleSend}
              aria-label={t.send}
              className="min-h-[40px] sm:min-h-[44px] px-3 sm:px-4 rounded-xl text-sm font-medium text-white flex items-center justify-center gap-1.5 transition-opacity shrink-0 cursor-pointer disabled:opacity-40"
              style={{ backgroundColor: theme.accentBg }}
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">{t.send}</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
}
