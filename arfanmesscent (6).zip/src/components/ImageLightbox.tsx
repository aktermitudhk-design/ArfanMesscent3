import React from 'react';
import { Download, X } from 'lucide-react';
import { COPY, type Lang } from '../utils/i18n';

interface ImageLightboxProps {
  image: { src: string; senderName: string } | null;
  lang: Lang;
  onClose: () => void;
}

export function ImageLightbox({ image, lang, onClose }: ImageLightboxProps) {
  if (!image) return null;
  const t = COPY[lang];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Image preview"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl flex items-center justify-between mb-3 text-white"
        onClick={(e) => e.stopPropagation()}
      >
        <span className="text-sm font-medium">{image.senderName}</span>
        <div className="flex items-center gap-2">
          <a
            href={image.src}
            download={`arfanmesscent-${Date.now()}.jpg`}
            className="min-h-[40px] px-3 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>{t.download}</span>
          </a>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[40px] min-w-[40px] rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <img
        src={image.src}
        alt={`Shared by ${image.senderName}`}
        referrerPolicy="no-referrer"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[82dvh] max-w-full rounded-2xl object-contain"
      />
    </div>
  );
}
