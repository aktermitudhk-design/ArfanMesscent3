import 'dotenv/config';
import express from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import zlib from 'zlib';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import type {
  BlockedUser,
  ChatMessage,
  ClientEvent,
  GifItem,
  OnlineUser,
  PinnedMessageSummary,
  ServerEvent,
  ThemeId,
} from './src/shared/types.ts';
import {
  canDeleteForEveryone,
  canSendUnderSlowMode,
  dedupeAppendMessage,
  isUserBlocked,
  isValidThemeId,
  normalizeNicknameKey,
  sanitizeNickname,
  togglePollVote,
  toggleReactionMap,
  validateMessagePayload,
} from './src/shared/chatRules.ts';

interface PersistedRoomState {
  messages: ChatMessage[];
  blockedUsers: BlockedUser[];
  theme: ThemeId;
  roomLocked: boolean;
  roomTitle: string;
  slowModeSec: number;
  guestAllowed: boolean;
  pinnedMessage: PinnedMessageSummary | null;
  adminPassword: string;
}

interface ClientSession {
  ws: WebSocket;
  clientId: string;
  nickname: string;
  avatarColor: string;
  isAdmin: boolean;
  isGuest: boolean;
  connectedAt: number;
  lastSentAt: number;
}

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const STATE_FILE = path.join(DATA_DIR, 'room-state.json');
const ADMIN_SECRET_FILE = path.join(DATA_DIR, '.admin-secret');

const HOST_ADMIN_PASSWORD = 'arfan9899';

function getOrCreateHmacSecret(): string {
  if (process.env.ADMIN_TOKEN_SECRET) return process.env.ADMIN_TOKEN_SECRET;
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(ADMIN_SECRET_FILE)) {
      const existing = fs.readFileSync(ADMIN_SECRET_FILE, 'utf-8').trim();
      if (existing.length >= 32) return existing;
    }
    const generated = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(ADMIN_SECRET_FILE, generated, 'utf-8');
    return generated;
  } catch {
    return crypto.randomBytes(32).toString('hex');
  }
}

const HMAC_SECRET = getOrCreateHmacSecret();

function timingSafeMatch(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function issueSignedAdminToken(): { token: string; expiresAt: number } {
  const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
  const nonce = crypto.randomBytes(12).toString('hex');
  const payload = `${expiresAt}.${nonce}`;
  const sig = crypto
    .createHmac('sha256', HMAC_SECRET)
    .update(payload)
    .digest('hex');
  return { token: `${payload}.${sig}`, expiresAt };
}

function verifySignedAdminToken(token: string): boolean {
  if (!token || typeof token !== 'string') return false;
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [expStr, nonce, sig] = parts;
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || exp < Date.now() || !nonce || !sig) return false;
  const expected = crypto
    .createHmac('sha256', HMAC_SECRET)
    .update(`${expStr}.${nonce}`)
    .digest('hex');
  return timingSafeMatch(sig, expected);
}

interface BuiltinGifDef {
  id: string;
  title: string;
  tags: string[];
  emoji: string;
  bg1: string;
  bg2: string;
  subtitle: string;
}

const BUILTIN_GIFS: BuiltinGifDef[] = [
  { id: 'happy-dance', title: 'Happy Dance', tags: ['happy', 'dance', 'party', 'yay', 'excited'], emoji: '💃', bg1: '#7C3AED', bg2: '#EC4899', subtitle: 'YAY!!' },
  { id: 'laugh-cry', title: 'LOL Laughing', tags: ['lol', 'haha', 'laugh', 'funny', 'comedy'], emoji: '🤣', bg1: '#F59E0B', bg2: '#EF4444', subtitle: 'HAHAHA' },
  { id: 'heart-eyes', title: 'Sending Love', tags: ['love', 'heart', 'hug', 'cute', 'kiss'], emoji: '😍', bg1: '#EC4899', bg2: '#E11D48', subtitle: 'LOVE U' },
  { id: 'fire-hype', title: 'Pure Fire', tags: ['fire', 'lit', 'wow', 'awesome', 'hot'], emoji: '🔥', bg1: '#EA580C', bg2: '#DC2626', subtitle: 'ON FIRE!' },
  { id: 'thumbs-cool', title: 'Approved', tags: ['ok', 'yes', 'good', 'agree', 'thumbs', 'cool'], emoji: '👍', bg1: '#059669', bg2: '#0EA5E9', subtitle: 'NICE!' },
  { id: 'clap-bravo', title: 'Bravo Clap', tags: ['clap', 'bravo', 'congrats', 'win', 'success'], emoji: '👏', bg1: '#4F46E5', bg2: '#7C3AED', subtitle: 'BRAVO!' },
  { id: 'mind-blown', title: 'Mind Blown', tags: ['wow', 'omg', 'shock', 'surprised', 'mind'], emoji: '🤯', bg1: '#9333EA', bg2: '#2563EB', subtitle: 'WHOA!' },
  { id: 'wave-hello', title: 'Hey There', tags: ['hi', 'hello', 'hey', 'wave', 'welcome'], emoji: '👋', bg1: '#0284C7', bg2: '#10B981', subtitle: 'HEY!' },
  { id: 'party-confetti', title: 'Celebrate', tags: ['party', 'birthday', 'celebrate', 'eid', 'win'], emoji: '🎉', bg1: '#8B5CF6', bg2: '#F59E0B', subtitle: 'PARTY!' },
  { id: 'sleepy-night', title: 'Good Night', tags: ['sleep', 'night', 'tired', 'bye', 'gn'], emoji: '😴', bg1: '#1E1B4B', bg2: '#4338CA', subtitle: 'ZZZZ...' },
  { id: 'coffee-vibes', title: 'Cha & Chill', tags: ['tea', 'coffee', 'chai', 'chill', 'morning'], emoji: '☕', bg1: '#78350F', bg2: '#D97706', subtitle: 'CHILL' },
  { id: 'sad-rain', title: 'Oh No', tags: ['sad', 'cry', 'sorry', 'miss', 'oops'], emoji: '🥺', bg1: '#334155', bg2: '#6366F1', subtitle: 'OOPS...' },
];

function renderAnimatedSvgGif(def: BuiltinGifDef): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="160" viewBox="0 0 240 160">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${def.bg1}"/>
      <stop offset="100%" stop-color="${def.bg2}"/>
    </linearGradient>
  </defs>
  <rect width="240" height="160" rx="18" fill="url(#g)"/>
  <circle cx="40" cy="34" r="14" fill="rgba(255,255,255,0.14)">
    <animate attributeName="cy" values="34;26;34" dur="1.8s" repeatCount="indefinite"/>
  </circle>
  <circle cx="204" cy="126" r="18" fill="rgba(255,255,255,0.12)">
    <animate attributeName="cx" values="204;194;204" dur="2.1s" repeatCount="indefinite"/>
  </circle>
  <text x="120" y="84" text-anchor="middle" font-size="56" font-family="Apple Color Emoji, Segoe UI Emoji, Noto Color Emoji, sans-serif">
    ${def.emoji}
    <animateTransform attributeName="transform" type="scale" additive="sum" values="1 1;1.12 1.12;1 1" dur="1.1s" repeatCount="indefinite"/>
  </text>
  <rect x="64" y="114" width="112" height="28" rx="10" fill="rgba(0,0,0,0.34)"/>
  <text x="120" y="133" text-anchor="middle" fill="#FFFFFF" font-size="14" font-weight="800" font-family="system-ui, -apple-system, sans-serif" letter-spacing="1.5">${def.subtitle}</text>
</svg>`;
}

function loadInitialState(): PersistedRoomState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const raw = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PersistedRoomState>;
      return {
        messages: Array.isArray(parsed.messages) ? parsed.messages.slice(-300) : [],
        blockedUsers: Array.isArray(parsed.blockedUsers) ? parsed.blockedUsers : [],
        theme: parsed.theme && isValidThemeId(parsed.theme) ? parsed.theme : 'midnight-violet',
        roomLocked: Boolean(parsed.roomLocked),
        roomTitle:
          typeof parsed.roomTitle === 'string' && parsed.roomTitle.trim()
            ? parsed.roomTitle.trim()
            : 'ARFANMesscent Lounge',
        slowModeSec: typeof parsed.slowModeSec === 'number' ? parsed.slowModeSec : 0,
        guestAllowed: parsed.guestAllowed !== undefined ? Boolean(parsed.guestAllowed) : true,
        pinnedMessage: parsed.pinnedMessage ?? null,
        adminPassword:
          typeof parsed.adminPassword === 'string' && parsed.adminPassword.length >= 4
            ? parsed.adminPassword
            : HOST_ADMIN_PASSWORD,
      };
    }
  } catch (err) {
    console.error('Failed to load room state, starting fresh:', err);
  }

  return {
    messages: [
      {
        id: `sys-welcome-${Date.now()}`,
        type: 'system',
        senderId: 'system',
        senderName: 'ARFANMesscent',
        senderColor: '#7C3AED',
        text: 'Welcome to ARFANMesscent! Share the invite link — friends can join as Guests or pick a nickname.',
        reactions: {},
        createdAt: Date.now(),
      },
    ],
    blockedUsers: [],
    theme: 'midnight-violet',
    roomLocked: false,
    roomTitle: 'ARFANMesscent Lounge',
    slowModeSec: 0,
    guestAllowed: true,
    pinnedMessage: null,
    adminPassword: HOST_ADMIN_PASSWORD,
  };
}

const roomState: PersistedRoomState = loadInitialState();
const adminTokens = new Set<string>();
const sessions = new Map<WebSocket, ClientSession>();
const recentJoins = new Map<string, number>();

let saveTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(STATE_FILE, JSON.stringify(roomState, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save room state:', err);
    }
  }, 150);
}

function sendEvent(ws: WebSocket, event: ServerEvent) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(event));
  }
}

function broadcast(event: ServerEvent, excludeWs?: WebSocket) {
  const data = JSON.stringify(event);
  for (const [clientWs] of sessions.entries()) {
    if (clientWs !== excludeWs && clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(data);
    }
  }
}

function getOnlineUsers(): OnlineUser[] {
  const byId = new Map<string, OnlineUser>();
  for (const session of sessions.values()) {
    const existing = byId.get(session.clientId);
    if (!existing || session.isAdmin) {
      byId.set(session.clientId, {
        clientId: session.clientId,
        nickname: session.nickname,
        avatarColor: session.avatarColor,
        isAdmin: session.isAdmin,
        isGuest: session.isGuest,
        connectedAt: session.connectedAt,
      });
    }
  }
  return Array.from(byId.values()).sort((a, b) => {
    if (a.isAdmin !== b.isAdmin) return a.isAdmin ? -1 : 1;
    return a.connectedAt - b.connectedAt;
  });
}

function broadcastBlockedListToAdmins() {
  for (const [clientWs, session] of sessions.entries()) {
    if (session.isAdmin && clientWs.readyState === WebSocket.OPEN) {
      sendEvent(clientWs, {
        type: 'admin:blocked_list',
        payload: { blockedUsers: roomState.blockedUsers },
      });
    }
  }
}

const SAFE_UPLOAD_EXT_MAP: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/svg+xml': 'svg',
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/quicktime': 'mov',
  'audio/webm': 'webm',
  'audio/ogg': 'ogg',
  'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a',
  'audio/wav': 'wav',
  'application/pdf': 'pdf',
  'text/plain': 'txt',
  'application/zip': 'zip',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
};

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      onlineCount: getOnlineUsers().length,
      theme: roomState.theme,
      roomTitle: roomState.roomTitle,
    });
  });

  // Server-side Host Admin Password Verification (password never leaves backend)
  app.post('/api/admin/login', (req, res) => {
    const supplied = typeof req.body?.password === 'string' ? req.body.password.trim() : '';
    const matches =
      timingSafeMatch(supplied, HOST_ADMIN_PASSWORD) ||
      timingSafeMatch(supplied, roomState.adminPassword);

    if (!matches) {
      res.status(401).json({ success: false, error: 'wrongPassword' });
      return;
    }

    const issued = issueSignedAdminToken();
    res.json({ success: true, token: issued.token, expiresAt: issued.expiresAt });
  });

  app.post('/api/admin/verify', (req, res) => {
    const token = typeof req.body?.token === 'string' ? req.body.token.trim() : '';
    res.json({ valid: verifySignedAdminToken(token) });
  });

  // Server-side GIF search & trending (proxies Tenor/Giphy if API key set, otherwise rich local SVG reaction catalog)
  app.get('/api/gifs/trending', async (req, res) => {
    const limit = Math.min(24, Math.max(1, Number(req.query.limit) || 12));
    const tenorKey = process.env.TENOR_API_KEY;
    if (tenorKey) {
      try {
        const r = await fetch(
          `https://tenor.googleapis.com/v2/featured?key=${encodeURIComponent(tenorKey)}&limit=${limit}&media_filter=gif,tinygif`
        );
        if (r.ok) {
          const json = (await r.json()) as {
            results?: Array<{
              id: string;
              content_description?: string;
              media_formats?: {
                gif?: { url: string; dims?: number[] };
                tinygif?: { url: string };
              };
            }>;
          };
          const items: GifItem[] = (json.results || [])
            .filter((x) => x.media_formats?.gif?.url)
            .map((x) => ({
              id: x.id,
              title: x.content_description || 'GIF',
              url: x.media_formats!.gif!.url,
              previewUrl: x.media_formats?.tinygif?.url || x.media_formats!.gif!.url,
              width: x.media_formats?.gif?.dims?.[0],
              height: x.media_formats?.gif?.dims?.[1],
            }));
          if (items.length > 0) {
            res.json({ items });
            return;
          }
        }
      } catch {
        // Fallback to curated catalog
      }
    }

    const items: GifItem[] = BUILTIN_GIFS.slice(0, limit).map((g) => ({
      id: g.id,
      title: g.title,
      url: `/api/gifs/asset/${g.id}`,
      previewUrl: `/api/gifs/asset/${g.id}`,
      width: 240,
      height: 160,
    }));
    res.json({ items });
  });

  app.get('/api/gifs/search', async (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    const limit = Math.min(24, Math.max(1, Number(req.query.limit) || 12));
    const tenorKey = process.env.TENOR_API_KEY;

    if (tenorKey && q) {
      try {
        const r = await fetch(
          `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(q)}&key=${encodeURIComponent(tenorKey)}&limit=${limit}&media_filter=gif,tinygif`
        );
        if (r.ok) {
          const json = (await r.json()) as {
            results?: Array<{
              id: string;
              content_description?: string;
              media_formats?: {
                gif?: { url: string; dims?: number[] };
                tinygif?: { url: string };
              };
            }>;
          };
          const items: GifItem[] = (json.results || [])
            .filter((x) => x.media_formats?.gif?.url)
            .map((x) => ({
              id: x.id,
              title: x.content_description || q,
              url: x.media_formats!.gif!.url,
              previewUrl: x.media_formats?.tinygif?.url || x.media_formats!.gif!.url,
              width: x.media_formats?.gif?.dims?.[0],
              height: x.media_formats?.gif?.dims?.[1],
            }));
          if (items.length > 0) {
            res.json({ items });
            return;
          }
        }
      } catch {
        // Fallback to curated catalog
      }
    }

    const qLower = q.toLowerCase();
    const matched = qLower
      ? BUILTIN_GIFS.filter(
          (g) =>
            g.title.toLowerCase().includes(qLower) ||
            g.subtitle.toLowerCase().includes(qLower) ||
            g.tags.some((tag) => tag.includes(qLower) || qLower.includes(tag))
        )
      : BUILTIN_GIFS;

    const list = matched.length > 0 ? matched : BUILTIN_GIFS;
    const items: GifItem[] = list.slice(0, limit).map((g) => ({
      id: g.id,
      title: g.title,
      url: `/api/gifs/asset/${g.id}`,
      previewUrl: `/api/gifs/asset/${g.id}`,
      width: 240,
      height: 160,
    }));
    res.json({ items });
  });

  app.get('/api/gifs/asset/:id', (req, res) => {
    const def = BUILTIN_GIFS.find((g) => g.id === req.params.id);
    if (!def) {
      res.status(404).send('GIF not found');
      return;
    }
    res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(renderAnimatedSvgGif(def));
  });

  // Fallback binary media storage when Firebase Storage bucket is not provisioned yet in Console
  app.post(
    '/api/media/upload',
    express.raw({ type: '*/*', limit: '25mb' }),
    (req, res) => {
      if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
        res.status(400).json({ error: 'Empty upload body' });
        return;
      }

      const contentType = String(req.headers['content-type'] || 'application/octet-stream')
        .split(';')[0]
        .trim()
        .toLowerCase();
      const rawName = String(req.headers['x-file-name'] || 'file');
      const extFromMime = SAFE_UPLOAD_EXT_MAP[contentType];
      const extFromName = rawName
        .split('.')
        .pop()
        ?.replace(/[^a-zA-Z0-9]/g, '')
        .toLowerCase();
      const ext = extFromMime || extFromName || 'bin';

      const fileId = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}.${ext}`;
      if (!fs.existsSync(UPLOADS_DIR)) {
        fs.mkdirSync(UPLOADS_DIR, { recursive: true });
      }
      fs.writeFileSync(path.join(UPLOADS_DIR, fileId), req.body);
      res.json({
        url: `/api/media/${fileId}`,
        size: req.body.length,
        mime: contentType,
      });
    }
  );

  app.get('/api/media/:fileId', (req, res) => {
    const safeName = path.basename(req.params.fileId || '');
    if (!/^[a-zA-Z0-9._-]+$/.test(safeName)) {
      res.status(400).send('Invalid file identifier');
      return;
    }
    const targetPath = path.join(UPLOADS_DIR, safeName);
    if (!fs.existsSync(targetPath)) {
      res.status(404).send('Media not found');
      return;
    }
    res.sendFile(targetPath);
  });

  const crc32Buffer = (buf: Buffer): number => {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i += 1) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j += 1) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  };

  const toDosDateTime = (date: Date): { dosTime: number; dosDate: number } => {
    const year = Math.max(1980, date.getFullYear());
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = Math.floor(date.getSeconds() / 2);
    const dosTime = ((hours & 0x1f) << 11) | ((minutes & 0x3f) << 5) | (seconds & 0x1f);
    const dosDate = (((year - 1980) & 0x7f) << 9) | ((month & 0x0f) << 5) | (day & 0x1f);
    return { dosTime, dosDate };
  };

  const buildDeflateZip = (
    entries: Array<{ name: string; data: Buffer }>
  ): Buffer => {
    const localParts: Buffer[] = [];
    const centralParts: Buffer[] = [];
    const { dosTime, dosDate } = toDosDateTime(new Date());
    let offset = 0;

    for (const entry of entries) {
      const nameBuf = Buffer.from(entry.name, 'utf8');
      const crc = crc32Buffer(entry.data);
      const uncompressedSize = entry.data.length;
      const compressedData = zlib.deflateRawSync(entry.data, { level: 6 });
      const compressedSize = compressedData.length;

      const localHeader = Buffer.alloc(30);
      localHeader.writeUInt32LE(0x04034b50, 0);
      localHeader.writeUInt16LE(20, 4); // version needed 2.0
      localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
      localHeader.writeUInt16LE(8, 8); // compression method 8 = DEFLATE
      localHeader.writeUInt16LE(dosTime, 10);
      localHeader.writeUInt16LE(dosDate, 12);
      localHeader.writeUInt32LE(crc, 14);
      localHeader.writeUInt32LE(compressedSize, 18);
      localHeader.writeUInt32LE(uncompressedSize, 22);
      localHeader.writeUInt16LE(nameBuf.length, 26);
      localHeader.writeUInt16LE(0, 28);

      localParts.push(localHeader, nameBuf, compressedData);

      const centralHeader = Buffer.alloc(46);
      centralHeader.writeUInt32LE(0x02014b50, 0);
      centralHeader.writeUInt16LE((3 << 8) | 20, 4); // UNIX + PKZIP 2.0
      centralHeader.writeUInt16LE(20, 6);
      centralHeader.writeUInt16LE(0x0800, 8);
      centralHeader.writeUInt16LE(8, 10); // DEFLATE
      centralHeader.writeUInt16LE(dosTime, 12);
      centralHeader.writeUInt16LE(dosDate, 14);
      centralHeader.writeUInt32LE(crc, 16);
      centralHeader.writeUInt32LE(compressedSize, 20);
      centralHeader.writeUInt32LE(uncompressedSize, 24);
      centralHeader.writeUInt16LE(nameBuf.length, 28);
      centralHeader.writeUInt16LE(0, 30);
      centralHeader.writeUInt16LE(0, 32);
      centralHeader.writeUInt16LE(0, 34);
      centralHeader.writeUInt16LE(0, 36);
      centralHeader.writeUInt32LE((0o100644 << 16) >>> 0, 38); // rw-r--r-- regular file
      centralHeader.writeUInt32LE(offset, 42);

      centralParts.push(centralHeader, nameBuf);
      offset += localHeader.length + nameBuf.length + compressedSize;
    }

    const centralDirSize = centralParts.reduce((sum, b) => sum + b.length, 0);
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(entries.length, 8);
    eocd.writeUInt16LE(entries.length, 10);
    eocd.writeUInt32LE(centralDirSize, 12);
    eocd.writeUInt32LE(offset, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...localParts, ...centralParts, eocd]);
  };

  app.get('/api/download/single-html', (_req, res) => {
    const singleFile = path.resolve(process.cwd(), 'netlify-drop', 'index.html');
    if (!fs.existsSync(singleFile)) {
      res.status(404).send('Single HTML bundle not built yet.');
      return;
    }
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.download(singleFile, 'index.html');
  });

  app.get('/api/download/netlify-pack', (_req, res) => {
    const singleFile = path.resolve(process.cwd(), 'netlify-drop', 'index.html');
    if (!fs.existsSync(singleFile)) {
      res.status(404).send('Single HTML bundle not built yet.');
      return;
    }
    const entries: Array<{ name: string; data: Buffer }> = [
      { name: 'index.html', data: fs.readFileSync(singleFile) },
    ];
    for (const staticName of ['robots.txt', 'sitemap.xml', 'og-image.svg']) {
      const p = path.resolve(process.cwd(), 'public', staticName);
      if (fs.existsSync(p)) {
        entries.push({ name: staticName, data: fs.readFileSync(p) });
      }
    }
    const zipBuffer = buildDeflateZip(entries);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="arfanmesscent-free-site.zip"'
    );
    res.setHeader('Content-Length', String(zipBuffer.length));
    res.send(zipBuffer);
  });

  const DEFAULT_PUBLIC_URL =
    'https://ais-pre-ninkkcapv3lnbh7ktm5ame-417594258398.asia-southeast1.run.app';

  const resolvePublicBaseUrl = (req: express.Request): string => {
    const configured = (process.env.PUBLIC_URL || '').trim().replace(/\/+$/, '');
    if (configured) return configured;

    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '').trim();
    const cleanHost = rawHost.split(',')[0].trim();
    if (
      cleanHost &&
      !cleanHost.startsWith('localhost') &&
      !cleanHost.startsWith('127.0.0.1') &&
      !cleanHost.startsWith('ais-dev-')
    ) {
      const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https')
        .split(',')[0]
        .trim();
      return `${proto}://${cleanHost}`;
    }

    const appUrl = (process.env.APP_URL || '').trim().replace(/\/+$/, '');
    if (appUrl) {
      return appUrl.replace('://ais-dev-', '://ais-pre-');
    }

    return DEFAULT_PUBLIC_URL;
  };

  app.get('/robots.txt', (req, res) => {
    const baseUrl = resolvePublicBaseUrl(req);
    res.type('text/plain; charset=utf-8');
    res.send(
      `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${baseUrl}/sitemap.xml\n`
    );
  });

  app.get('/sitemap.xml', (req, res) => {
    const baseUrl = resolvePublicBaseUrl(req);
    res.type('application/xml; charset=utf-8');
    res.send(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url>\n    <loc>${baseUrl}/</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n</urlset>\n`
    );
  });

  const server = http.createServer(app);

  const wss = new WebSocketServer({
    server,
    path: '/ws',
    maxPayload: 8 * 1024 * 1024,
  });

  wss.on('connection', (ws) => {
    ws.on('message', (raw) => {
      let event: ClientEvent;
      try {
        event = JSON.parse(raw.toString()) as ClientEvent;
      } catch {
        sendEvent(ws, { type: 'error', payload: { message: 'Invalid message payload.' } });
        return;
      }

      if (event.type === 'room:join') {
        const { clientId, nickname, avatarColor, isGuest, adminToken } = event.payload;
        const nickCheck = sanitizeNickname(nickname || '');
        if (!nickCheck.valid || !clientId) {
          sendEvent(ws, {
            type: 'error',
            payload: { message: nickCheck.error || 'Invalid join details.' },
          });
          return;
        }

        const isAdmin = Boolean(
          adminToken && (adminTokens.has(adminToken) || verifySignedAdminToken(adminToken))
        );
        const guestAccount = Boolean(isGuest) && !isAdmin;

        if (guestAccount && !roomState.guestAllowed) {
          sendEvent(ws, {
            type: 'room:init',
            payload: {
              messages: [],
              onlineUsers: [],
              theme: roomState.theme,
              roomLocked: roomState.roomLocked,
              roomTitle: roomState.roomTitle,
              slowModeSec: roomState.slowModeSec,
              guestAllowed: roomState.guestAllowed,
              pinnedMessage: null,
              isAdmin: false,
              isBlocked: true,
              blockReason: 'Guest access is currently paused by Admin. Please enter a nickname.',
            },
          });
          return;
        }

        const blocked =
          !isAdmin && isUserBlocked(roomState.blockedUsers, clientId, nickCheck.nickname);

        if (blocked) {
          sendEvent(ws, {
            type: 'room:init',
            payload: {
              messages: [],
              onlineUsers: [],
              theme: roomState.theme,
              roomLocked: roomState.roomLocked,
              roomTitle: roomState.roomTitle,
              slowModeSec: roomState.slowModeSec,
              guestAllowed: roomState.guestAllowed,
              pinnedMessage: null,
              isAdmin: false,
              isBlocked: true,
            },
          });
          return;
        }

        const prevSession = sessions.get(ws);
        const isFirstJoinForClient = !Array.from(sessions.values()).some(
          (s) => s.clientId === clientId
        );

        const session: ClientSession = {
          ws,
          clientId,
          nickname: nickCheck.nickname,
          avatarColor: avatarColor || '#7C3AED',
          isAdmin,
          isGuest: guestAccount,
          connectedAt: prevSession?.connectedAt ?? Date.now(),
          lastSentAt: prevSession?.lastSentAt ?? 0,
        };
        sessions.set(ws, session);

        sendEvent(ws, {
          type: 'room:init',
          payload: {
            messages: roomState.messages,
            onlineUsers: getOnlineUsers(),
            theme: roomState.theme,
            roomLocked: roomState.roomLocked,
            roomTitle: roomState.roomTitle,
            slowModeSec: roomState.slowModeSec,
            guestAllowed: roomState.guestAllowed,
            pinnedMessage: roomState.pinnedMessage,
            isAdmin,
            isBlocked: false,
            blockedUsers: isAdmin ? roomState.blockedUsers : undefined,
          },
        });

        broadcast({
          type: 'room:users',
          payload: { onlineUsers: getOnlineUsers() },
        });

        const now = Date.now();
        const lastJoinAt = recentJoins.get(clientId) ?? 0;
        const shouldAnnounceJoin =
          isFirstJoinForClient && !prevSession && now - lastJoinAt > 5 * 60 * 1000;

        if (shouldAnnounceJoin) {
          recentJoins.set(clientId, now);
          const joinNotice: ChatMessage = {
            id: `sys-join-${clientId}-${now}`,
            type: 'system',
            senderId: 'system',
            senderName: 'ARFANMesscent',
            senderColor: '#7C3AED',
            text: guestAccount
              ? `${nickCheck.nickname} joined as a Guest`
              : `${nickCheck.nickname} joined the chat`,
            reactions: {},
            createdAt: now,
          };
          roomState.messages = dedupeAppendMessage(roomState.messages, joinNotice);
          scheduleSave();
          broadcast({
            type: 'message:created',
            payload: { message: joinNotice },
          });
        }
        return;
      }

      const session = sessions.get(ws);
      if (!session) {
        sendEvent(ws, { type: 'error', payload: { message: 'Please join the room first.' } });
        return;
      }

      if (
        !session.isAdmin &&
        isUserBlocked(roomState.blockedUsers, session.clientId, session.nickname)
      ) {
        sendEvent(ws, {
          type: 'user:kicked',
          payload: { reason: 'You have been blocked by the Admin.' },
        });
        ws.close();
        return;
      }

      switch (event.type) {
        case 'message:send': {
          if (roomState.roomLocked && !session.isAdmin) {
            sendEvent(ws, {
              type: 'error',
              payload: { message: 'Chat is currently paused by Admin.' },
            });
            return;
          }

          const now = Date.now();
          const slowCheck = canSendUnderSlowMode(
            session.lastSentAt,
            now,
            roomState.slowModeSec,
            session.isAdmin
          );
          if (!slowCheck.allowed) {
            sendEvent(ws, {
              type: 'error',
              payload: {
                message: `Slow mode active. Wait ${slowCheck.waitSec}s before sending again.`,
              },
            });
            return;
          }

          const check = validateMessagePayload(
            event.payload.text,
            event.payload.imageDataUrl,
            event.payload.audioDataUrl,
            event.payload.poll
          );
          if (!check.valid) {
            sendEvent(ws, {
              type: 'error',
              payload: { message: check.error || 'Invalid message.' },
            });
            return;
          }

          session.lastSentAt = now;

          const message: ChatMessage = {
            id:
              event.payload.id ||
              `msg-${now}-${Math.random().toString(36).slice(2, 8)}`,
            type: 'user',
            senderId: session.clientId,
            senderName: session.nickname,
            senderColor: session.avatarColor,
            isAdmin: session.isAdmin,
            isGuest: session.isGuest,
            text: check.text,
            imageDataUrl: check.imageDataUrl,
            audioDataUrl: check.audioDataUrl,
            audioDurationSec: event.payload.audioDurationSec,
            poll: check.poll,
            replyTo: event.payload.replyTo,
            reactions: {},
            createdAt: now,
          };

          const beforeLen = roomState.messages.length;
          roomState.messages = dedupeAppendMessage(roomState.messages, message);
          if (
            roomState.messages.length !== beforeLen ||
            roomState.messages.some((m) => m.id === message.id)
          ) {
            scheduleSave();
            broadcast({
              type: 'message:created',
              payload: { message },
            });
          }
          break;
        }

        case 'message:react': {
          const { messageId, emoji } = event.payload;
          const idx = roomState.messages.findIndex((m) => m.id === messageId);
          if (idx === -1) return;
          const target = roomState.messages[idx];
          const updated: ChatMessage = {
            ...target,
            reactions: toggleReactionMap(target.reactions, emoji, session.clientId),
          };
          roomState.messages[idx] = updated;
          scheduleSave();
          broadcast({
            type: 'message:updated',
            payload: { message: updated },
          });
          break;
        }

        case 'poll:vote': {
          const { messageId, optionId } = event.payload;
          const idx = roomState.messages.findIndex((m) => m.id === messageId);
          if (idx === -1) return;
          const target = roomState.messages[idx];
          if (!target.poll) return;

          const updated: ChatMessage = {
            ...target,
            poll: togglePollVote(target.poll, optionId, session.clientId),
          };
          roomState.messages[idx] = updated;
          scheduleSave();
          broadcast({
            type: 'message:updated',
            payload: { message: updated },
          });
          break;
        }

        case 'user:typing': {
          broadcast(
            {
              type: 'user:typing',
              payload: {
                clientId: session.clientId,
                nickname: session.nickname,
                isTyping: Boolean(event.payload.isTyping),
              },
            },
            ws
          );
          break;
        }

        case 'admin:auth': {
          const supplied = (event.payload.password || '').trim();
          if (
            !timingSafeMatch(supplied, roomState.adminPassword) &&
            !timingSafeMatch(supplied, HOST_ADMIN_PASSWORD)
          ) {
            sendEvent(ws, {
              type: 'admin:auth_result',
              payload: { success: false, error: 'Incorrect admin password.' },
            });
            return;
          }
          const token = crypto.randomBytes(24).toString('hex');
          adminTokens.add(token);
          session.isAdmin = true;
          session.isGuest = false;
          sendEvent(ws, {
            type: 'admin:auth_result',
            payload: {
              success: true,
              adminToken: token,
              blockedUsers: roomState.blockedUsers,
            },
          });
          broadcast({
            type: 'room:users',
            payload: { onlineUsers: getOnlineUsers() },
          });
          break;
        }

        case 'admin:logout': {
          session.isAdmin = false;
          broadcast({
            type: 'room:users',
            payload: { onlineUsers: getOnlineUsers() },
          });
          break;
        }

        case 'admin:block': {
          if (!session.isAdmin) return;
          const targetNick = (event.payload.targetNickname || '').trim();
          const targetId = (event.payload.targetClientId || '').trim();
          if (!targetNick && !targetId) return;
          if (targetId && targetId === session.clientId) return;
          const normalizedTarget = normalizeNicknameKey(targetNick);
          if (normalizedTarget && normalizedTarget === normalizeNicknameKey(session.nickname)) {
            return;
          }
          const targetsActiveHost = Array.from(sessions.values()).some(
            (s) =>
              s.isAdmin &&
              ((targetId && s.clientId === targetId) ||
                (normalizedTarget && normalizeNicknameKey(s.nickname) === normalizedTarget))
          );
          if (targetsActiveHost) return;

          const already = isUserBlocked(roomState.blockedUsers, targetId, targetNick);
          if (!already) {
            roomState.blockedUsers.push({
              clientId: targetId,
              nickname: targetNick || targetId,
              blockedAt: Date.now(),
            });
            scheduleSave();
          }
          for (const [clientWs, clientSession] of sessions.entries()) {
            if (clientSession.isAdmin) continue;
            const matchesId = targetId && clientSession.clientId === targetId;
            const matchesName =
              normalizedTarget &&
              normalizeNicknameKey(clientSession.nickname) === normalizedTarget;
            if (matchesId || matchesName) {
              sendEvent(clientWs, {
                type: 'user:kicked',
                payload: { reason: 'You have been blocked from this room by Admin.' },
              });
              sessions.delete(clientWs);
              clientWs.close();
            }
          }

          broadcast({
            type: 'room:users',
            payload: { onlineUsers: getOnlineUsers() },
          });
          broadcastBlockedListToAdmins();
          break;
        }

        case 'admin:unblock': {
          if (!session.isAdmin) return;
          const targetKey = normalizeNicknameKey(event.payload.targetNickname || '');
          roomState.blockedUsers = roomState.blockedUsers.filter(
            (u) =>
              normalizeNicknameKey(u.nickname) !== targetKey &&
              u.clientId !== event.payload.targetNickname
          );
          scheduleSave();
          broadcastBlockedListToAdmins();
          break;
        }

        case 'message:delete':
        case 'admin:delete_message': {
          const { messageId } = event.payload;
          const target = roomState.messages.find((m) => m.id === messageId);
          if (!target) return;
          const authorized =
            event.type === 'admin:delete_message'
              ? session.isAdmin
              : canDeleteForEveryone(target, session.clientId, session.isAdmin);
          if (!authorized) {
            sendEvent(ws, {
              type: 'error',
              payload: { message: 'You can only delete your own messages for everyone.' },
            });
            return;
          }
          roomState.messages = roomState.messages.filter((m) => m.id !== messageId);
          if (roomState.pinnedMessage?.messageId === messageId) {
            roomState.pinnedMessage = null;
            broadcast({ type: 'room:pinned', payload: { pinnedMessage: null } });
          }
          scheduleSave();
          broadcast({
            type: 'message:deleted',
            payload: { messageId },
          });
          break;
        }

        case 'admin:pin_message': {
          if (!session.isAdmin) return;
          const { messageId } = event.payload;
          if (!messageId) {
            roomState.pinnedMessage = null;
            scheduleSave();
            broadcast({ type: 'room:pinned', payload: { pinnedMessage: null } });
            return;
          }
          const target = roomState.messages.find((m) => m.id === messageId);
          if (!target) return;
          const preview =
            target.text ||
            (target.poll ? `Poll: ${target.poll.question}` : '') ||
            (target.audioDataUrl ? 'Voice message' : '') ||
            (target.imageDataUrl ? 'Photo' : '');

          roomState.pinnedMessage = {
            messageId: target.id,
            senderName: target.senderName,
            previewText: preview.slice(0, 140),
            pinnedAt: Date.now(),
          };
          scheduleSave();
          broadcast({
            type: 'room:pinned',
            payload: { pinnedMessage: roomState.pinnedMessage },
          });
          break;
        }

        case 'admin:clear_chat': {
          if (!session.isAdmin) return;
          roomState.pinnedMessage = null;
          roomState.messages = [
            {
              id: `sys-cleared-${Date.now()}`,
              type: 'system',
              senderId: 'system',
              senderName: 'ARFANMesscent',
              senderColor: '#7C3AED',
              text: 'Chat history was cleared by Admin.',
              reactions: {},
              createdAt: Date.now(),
            },
          ];
          scheduleSave();
          broadcast({ type: 'room:cleared', payload: {} });
          broadcast({ type: 'room:pinned', payload: { pinnedMessage: null } });
          broadcast({
            type: 'message:created',
            payload: { message: roomState.messages[0] },
          });
          break;
        }

        case 'admin:set_theme': {
          if (!session.isAdmin) return;
          if (!isValidThemeId(event.payload.theme)) return;
          roomState.theme = event.payload.theme;
          scheduleSave();
          broadcast({
            type: 'room:theme',
            payload: { theme: roomState.theme },
          });
          break;
        }

        case 'admin:toggle_lock': {
          if (!session.isAdmin) return;
          roomState.roomLocked = Boolean(event.payload.locked);
          scheduleSave();
          broadcast({
            type: 'room:settings',
            payload: {
              roomLocked: roomState.roomLocked,
              roomTitle: roomState.roomTitle,
              slowModeSec: roomState.slowModeSec,
              guestAllowed: roomState.guestAllowed,
            },
          });
          break;
        }

        case 'admin:update_room': {
          if (!session.isAdmin) return;
          if (typeof event.payload.roomTitle === 'string') {
            const nextTitle = event.payload.roomTitle.trim().slice(0, 40);
            if (nextTitle) roomState.roomTitle = nextTitle;
          }
          if (typeof event.payload.slowModeSec === 'number') {
            roomState.slowModeSec = Math.max(0, Math.min(60, event.payload.slowModeSec));
          }
          if (typeof event.payload.guestAllowed === 'boolean') {
            roomState.guestAllowed = event.payload.guestAllowed;
          }
          scheduleSave();
          broadcast({
            type: 'room:settings',
            payload: {
              roomLocked: roomState.roomLocked,
              roomTitle: roomState.roomTitle,
              slowModeSec: roomState.slowModeSec,
              guestAllowed: roomState.guestAllowed,
            },
          });
          break;
        }

        case 'admin:change_password': {
          if (!session.isAdmin) return;
          const nextPwd = (event.payload.newPassword || '').trim();
          if (nextPwd.length < 4) {
            sendEvent(ws, {
              type: 'admin:password_changed',
              payload: { success: false, error: 'Password must be at least 4 characters.' },
            });
            return;
          }
          roomState.adminPassword = nextPwd;
          scheduleSave();
          sendEvent(ws, {
            type: 'admin:password_changed',
            payload: { success: true },
          });
          break;
        }
      }
    });

    ws.on('close', () => {
      const removed = sessions.get(ws);
      if (removed) {
        sessions.delete(ws);
        broadcast({
          type: 'room:users',
          payload: { onlineUsers: getOnlineUsers() },
        });
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`ARFANMesscent server listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
